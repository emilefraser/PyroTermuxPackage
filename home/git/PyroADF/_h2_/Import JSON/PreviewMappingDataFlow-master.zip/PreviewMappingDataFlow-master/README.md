# PreviewMappingDataFlow
A quick demo of the Data Factory mapping data flow functionality currently in preview

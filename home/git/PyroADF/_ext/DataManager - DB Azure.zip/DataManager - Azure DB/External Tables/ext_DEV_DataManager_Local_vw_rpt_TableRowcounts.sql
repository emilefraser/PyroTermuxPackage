﻿CREATE EXTERNAL TABLE [dbo].[ext_DEV_DataManager_Local_vw_rpt_TableRowcounts] (
    [DatabaseName] VARCHAR (50) NULL,
    [SchemaName] NVARCHAR (200) NULL,
    [name] NVARCHAR (200) NULL,
    [TBLRowCount] BIGINT NULL
)
    WITH (
    DATA_SOURCE = [ExtDsrc_DEV_DataManager_Local],
    SCHEMA_NAME = N'dbo',
    OBJECT_NAME = N'vw_rpt_TableRowcounts'
    );


﻿CREATE TABLE [DC].[Field] (
    [FieldID]                            INT             IDENTITY (1, 1) NOT NULL,
    [FieldName]                          VARCHAR (1000)  NOT NULL,
    [DataType]                           VARCHAR (500)   NULL,
    [MaxLength]                          INT             NULL,
    [Precision]                          INT             NULL,
    [Scale]                              INT             NULL,
    [StringLength]                       INT             NULL,
    [Description]                        VARCHAR (1000)  NULL,
    [IsPrimaryKey]                       BIT             NULL,
    [IsForeignKey]                       BIT             NULL,
    [DefaultValue]                       VARCHAR (1000)  NULL,
    [SystemGenerated]                    BIT             NULL,
    [DataQualityScore]                   VARCHAR (50)    NULL,
    [dpNullCount]                        DECIMAL (18, 2) NULL,
    [dpNullCountPerc]                    DECIMAL (18, 2) NULL,
    [dpDistinctCount]                    DECIMAL (18, 2) NULL,
    [dpDuplicateCount]                   DECIMAL (18, 2) NULL,
    [dpDuplicatCountPerc]                DECIMAL (18, 2) NULL,
    [dpOrphanedChildrenCount]            DECIMAL (18, 2) NULL,
    [dpOrphanedChildrenCountPerc]        DECIMAL (18, 2) NULL,
    [dpMinimum]                          DECIMAL (18, 2) NULL,
    [dpMaximum]                          DECIMAL (18, 2) NULL,
    [dpAverage]                          DECIMAL (18, 2) NULL,
    [dpMedian]                           DECIMAL (18, 2) NULL,
    [dpStandardDeviation]                NCHAR (10)      NULL,
    [DataEntityID]                       INT             NULL,
    [SystemEntityID]                     INT             NULL,
    [IsSystemEntityDefinedAtRecordLevel] BIT             NULL,
    [DQScore]                            DECIMAL (18, 2) NULL,
    [DBColumnID]                         INT             NULL,
    [CreatedDT]                          DATETIME2 (7)   NULL,
    [UpdatedDT]                          DATETIME2 (7)   NULL,
    [DataEntitySize]                     DECIMAL (18, 3) NULL,
    [DatabaseSize]                       DECIMAL (18, 3) NULL,
    [IsActive]                           BIT             NULL,
    [FieldSortOrder]                     INT             NULL,
    [FriendlyName]                       VARCHAR (100)   NULL,
    [LastSeenDT]                         DATETIME2 (7)   NULL,
    CONSTRAINT [PK_Field] PRIMARY KEY CLUSTERED ([FieldID] ASC)
);


GO
CREATE NONCLUSTERED INDEX [nc_idx_Field_1]
    ON [DC].[Field]([DataEntityID] ASC, [FieldName] ASC);


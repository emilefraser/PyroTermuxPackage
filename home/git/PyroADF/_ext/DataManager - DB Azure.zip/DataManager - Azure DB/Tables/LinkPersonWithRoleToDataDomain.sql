﻿CREATE TABLE [GOV].[LinkPersonWithRoleToDataDomain] (
    [LinkPersonWithRoleToDataDomainID] INT           IDENTITY (1, 1) NOT NULL,
    [PersonAccessControlListID]        INT           NULL,
    [RoleID]                           INT           NULL,
    [DataDomainID]                     INT           NULL,
    [CreatedDT]                        DATETIME2 (7) NULL,
    [UpdatedDT]                        DATETIME2 (7) NULL,
    [IsActive]                         BIT           NULL,
    PRIMARY KEY CLUSTERED ([LinkPersonWithRoleToDataDomainID] ASC)
);


﻿CREATE TABLE [ACCESS].[LinkReportRoleToReportRegister] (
    [LinkID]           INT IDENTITY (1, 1) NOT NULL,
    [ReportRoleID]     INT NOT NULL,
    [ReportRegisterID] INT NOT NULL,
    CONSTRAINT [PK_LinkReportRoleToReportRegister] PRIMARY KEY CLUSTERED ([LinkID] ASC)
);


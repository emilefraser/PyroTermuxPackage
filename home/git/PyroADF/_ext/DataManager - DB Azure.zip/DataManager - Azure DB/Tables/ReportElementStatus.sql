﻿CREATE TABLE [REPREG].[ReportElementStatus] (
    [ReportElementStatusID] INT           NOT NULL,
    [ReportElementID]       INT           NOT NULL,
    [ReportStatusTypeID]    INT           NOT NULL,
    [CreatedDT]             DATETIME2 (7) NOT NULL,
    [ModifiedDT]            DATETIME2 (7) NULL
);


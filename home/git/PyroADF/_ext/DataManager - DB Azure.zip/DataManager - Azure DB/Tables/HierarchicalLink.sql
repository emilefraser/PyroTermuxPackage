﻿CREATE TABLE [DMOD].[HierarchicalLink] (
    [HierarchicalLinkID]   INT           IDENTITY (1, 1) NOT NULL,
    [HubID]                INT           NOT NULL,
    [HierarchicalLinkName] VARCHAR (150) NOT NULL,
    [PKFieldID]            INT           NOT NULL,
    [ParentFieldID]        INT           NOT NULL,
    [CreatedDT]            DATETIME2 (7) NULL,
    [UpdatedDT]            DATETIME2 (7) NULL,
    [IsActive]             BIT           NULL,
    PRIMARY KEY CLUSTERED ([HierarchicalLinkID] ASC)
);


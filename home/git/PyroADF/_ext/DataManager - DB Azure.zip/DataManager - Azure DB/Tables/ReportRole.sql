﻿CREATE TABLE [ACCESS].[ReportRole] (
    [ReportRoleID]          INT           IDENTITY (1, 1) NOT NULL,
    [ReportRoleName]        VARCHAR (100) NOT NULL,
    [ReportRoleDescription] VARCHAR (500) NULL,
    [ReportRegisterID]      INT           NULL,
    CONSTRAINT [PK_ReportRole] PRIMARY KEY CLUSTERED ([ReportRoleID] ASC)
);


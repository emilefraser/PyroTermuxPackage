﻿CREATE TABLE [DC].[DataEntityType] (
    [DataEntityTypeID]       INT           IDENTITY (1, 1) NOT NULL,
    [DataEntityTypeName]     VARCHAR (200) NOT NULL,
    [DataEntityTypeCode]     VARCHAR (20)  NULL,
    [DatabasePurposeID]      INT           NULL,
    [IsAllowedInRawVault]    BIT           NOT NULL,
    [IsAllowedInBizVault]    BIT           NOT NULL,
    [DataEntityNamingPrefix] VARCHAR (20)  NULL,
    CONSTRAINT [PK_DataEntityType] PRIMARY KEY CLUSTERED ([DataEntityTypeID] ASC)
);


﻿CREATE TABLE [ETL].[LoadGroupControlDetail] (
    [LoadGroupControlDetailID]     INT           IDENTITY (1, 1) NOT NULL,
    [LoadGroupControlID]           INT           NULL,
    [LoadPriority]                 INT           NULL,
    [ParentLoadControlID]          INT           NULL,
    [SourceDataEntityID]           INT           NULL,
    [TargetDataEntityID]           INT           NULL,
    [NewRecordDDL]                 VARCHAR (MAX) NULL,
    [UpdatedRecordsDDL]            VARCHAR (MAX) NULL,
    [UpdateStatementDDL]           VARCHAR (MAX) NULL,
    [DeleteStatementDDL]           VARCHAR (MAX) NULL,
    [IsStoredProc]                 BIT           NULL,
    [StoredProcedureDDL]           VARCHAR (MAX) NULL,
    [CreateTempTableDDL]           VARCHAR (MAX) NULL,
    [TempTableName]                VARCHAR (MAX) NULL,
    [GetLastProcessingKeyValueDDL] VARCHAR (MAX) NULL,
    [LastProcessingValue]          VARCHAR (100) NULL,
    [ProcessingStartDT]            DATETIME2 (7) NULL,
    [ProcessingFinishedDT]         DATETIME2 (7) NULL,
    [IsLastRunFailed]              BIT           NULL,
    [ProcessingState]              VARCHAR (50)  NULL,
    [NextScheduledRunDT]           DATETIME2 (7) NULL
);


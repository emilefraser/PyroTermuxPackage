﻿CREATE TABLE [MASTER].[PublicHolidays] (
    [HolidayDate] DATETIME     NOT NULL,
    [HolidayName] VARCHAR (30) NULL
);


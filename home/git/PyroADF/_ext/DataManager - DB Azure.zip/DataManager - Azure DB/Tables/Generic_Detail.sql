﻿CREATE TABLE [TYPE].[Generic_Detail] (
    [DetailID]              INT           IDENTITY (1, 1) NOT NULL,
    [HeaderID]              INT           NOT NULL,
    [DetailTypeCode]        VARCHAR (50)  NULL,
    [DetailTypeDescription] VARCHAR (500) NULL,
    [CreatedDT]             DATETIME2 (7) CONSTRAINT [DF_Generic_Detail_CreatedDT] DEFAULT (getdate()) NULL,
    [ModifiedDT]            DATETIME2 (7) NULL,
    [IsActive]              BIT           NULL
);


﻿CREATE TABLE [MASTER].[LinkBKCombination] (
    [LinkBKCombinationID] INT           IDENTITY (1, 1) NOT NULL,
    [LinkID]              INT           NOT NULL,
    [DataCatalogFieldID]  INT           NOT NULL,
    [BusinessKey]         VARCHAR (50)  NOT NULL,
    [CreatedDT]           DATETIME2 (7) NULL,
    [UpdatedDT]           DATETIME2 (7) NULL,
    [IsActive]            BIT           NULL,
    CONSTRAINT [PK_LinkBKCombination] PRIMARY KEY CLUSTERED ([LinkBKCombinationID] ASC, [LinkID] ASC, [DataCatalogFieldID] ASC, [BusinessKey] ASC)
);


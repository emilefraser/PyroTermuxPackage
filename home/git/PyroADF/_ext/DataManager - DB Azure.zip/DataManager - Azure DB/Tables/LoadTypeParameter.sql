﻿CREATE TABLE [DMOD].[LoadTypeParameter] (
    [LoadTypeParameterID]              INT            IDENTITY (1, 1) NOT NULL,
    [ParameterDescription]             VARCHAR (500)  NULL,
    [ParameterName]                    VARCHAR (100)  NOT NULL,
    [ParameterSearchValue]             VARCHAR (100)  NULL,
    [ParameterValueReplacementSQLCode] VARCHAR (1000) NULL,
    [IsStaticReplacementValue]         BIT            NULL,
    [CreatedDT]                        DATETIME2 (7)  NULL,
    [ModifiedDT]                       DATETIME2 (7)  NULL,
    [IsActive]                         BIT            NULL,
    CONSTRAINT [PK_LoadTypeParameter] PRIMARY KEY CLUSTERED ([LoadTypeParameterID] ASC)
);


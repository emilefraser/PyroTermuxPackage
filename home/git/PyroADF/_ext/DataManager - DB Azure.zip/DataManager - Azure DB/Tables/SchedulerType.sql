﻿CREATE TABLE [SCHEDULER].[SchedulerType] (
    [SchedulerTypeID]          INT           IDENTITY (1, 1) NOT NULL,
    [SchedulerTypeCode]        VARCHAR (50)  NULL,
    [SchedulerTypeDescription] VARCHAR (500) NULL,
    [SchedulerTypeName]        VARCHAR (50)  NULL,
    [CreatedDT]                DATETIME2 (7) NULL,
    [UpdatedDT]                DATETIME2 (7) NULL,
    [IsActive]                 BIT           NULL
);


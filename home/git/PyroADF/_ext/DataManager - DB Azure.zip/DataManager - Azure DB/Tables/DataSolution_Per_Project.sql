﻿CREATE TABLE [SDEL].[DataSolution_Per_Project] (
    [DataSolutionID] INT NOT NULL,
    [ProjectID]      INT NOT NULL,
    CONSTRAINT [PK__DataSolution_Per_Project] PRIMARY KEY CLUSTERED ([DataSolutionID] ASC, [ProjectID] ASC)
);


﻿CREATE TABLE [REPREG].[Report] (
    [ReportID]           INT            IDENTITY (1, 1) NOT NULL,
    [ReportName]         VARCHAR (200)  NULL,
    [Description]        VARCHAR (5000) NULL,
    [KeyObservations]    VARCHAR (5000) NULL,
    [Location]           VARCHAR (1000) NULL,
    [ReportOwnerID]      INT            NULL,
    [ReportType]         INT            NULL,
    [ReportPackID]       INT            NULL,
    [ReportTechnologyID] INT            NULL,
    [IsDynamicReport]    BIT            NOT NULL,
    [CreatedDT]          DATETIME2 (7)  NULL,
    [IsActive]           BIT            NULL
);


﻿CREATE TABLE [dbo].[SEI_ALLPJCProjectTransactionsUpdateDoc] (
    [Manager] VARCHAR (50) NULL,
    [Company] VARCHAR (10) NULL
);


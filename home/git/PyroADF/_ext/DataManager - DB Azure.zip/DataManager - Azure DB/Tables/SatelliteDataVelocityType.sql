﻿CREATE TABLE [DMOD].[SatelliteDataVelocityType] (
    [SatelliteDataVelocityTypeID]   SMALLINT     IDENTITY (1, 1) NOT NULL,
    [SatelliteDataVelocityTypeCode] VARCHAR (3)  NOT NULL,
    [SatelliteDataVelocityTypeName] VARCHAR (50) NOT NULL,
    CONSTRAINT [PK_FieldDataVelocityType] PRIMARY KEY CLUSTERED ([SatelliteDataVelocityTypeID] ASC)
);


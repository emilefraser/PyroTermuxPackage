﻿CREATE TABLE [DMOD].[SatelliteField] (
    [SatelliteFieldID] INT           IDENTITY (1, 1) NOT NULL,
    [FieldID]          INT           NOT NULL,
    [SatelliteID]      INT           NULL,
    [CreatedDT]        DATETIME2 (7) NULL,
    [UpdatedDT]        DATETIME2 (7) NULL,
    [IsActive]         BIT           NULL,
    CONSTRAINT [PK__FieldDat__74B4C2E15119535A] PRIMARY KEY CLUSTERED ([SatelliteFieldID] ASC)
);


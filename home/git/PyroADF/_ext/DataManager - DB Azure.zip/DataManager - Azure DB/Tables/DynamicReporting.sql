﻿CREATE TABLE [UPLOAD].[DynamicReporting] (
    [ReportID]   UNIQUEIDENTIFIER NOT NULL,
    [FieldID1]   INT              NOT NULL,
    [DataValue1] VARCHAR (1000)   NOT NULL,
    [FieldID2]   INT              NULL,
    [DataValue2] VARCHAR (1000)   NULL,
    [FieldID3]   INT              NULL,
    [DataValue3] VARCHAR (1000)   NULL
);


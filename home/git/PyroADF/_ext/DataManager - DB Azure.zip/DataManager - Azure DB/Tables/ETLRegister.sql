﻿CREATE TABLE [ETL].[ETLRegister] (
    [ETL_ID]         INT           IDENTITY (1, 1) NOT NULL,
    [ETLDescription] VARCHAR (150) NULL,
    [CurrentStatus]  VARCHAR (50)  NULL,
    [LastRunDate]    DATETIME      NULL,
    [LastRunStatus]  VARCHAR (50)  NULL,
    CONSTRAINT [PK_ETLRegister] PRIMARY KEY CLUSTERED ([ETL_ID] ASC)
);


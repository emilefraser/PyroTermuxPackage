﻿CREATE TABLE [DC].[DataEntityFileFormat] (
    [DEFileFormatID]          INT           IDENTITY (1, 1) NOT NULL,
    [DEFileFormatCode]        VARCHAR (10)  NOT NULL,
    [DEFileFormatDescription] VARCHAR (255) NOT NULL,
    CONSTRAINT [PK_DataEntityFileFormat] PRIMARY KEY CLUSTERED ([DEFileFormatID] ASC)
);


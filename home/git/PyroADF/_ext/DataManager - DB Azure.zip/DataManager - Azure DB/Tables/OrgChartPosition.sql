﻿CREATE TABLE [GOV].[OrgChartPosition] (
    [OrgChartPositionID]          INT           IDENTITY (1, 1) NOT NULL,
    [PositionCode]                VARCHAR (50)  NOT NULL,
    [PositionDescription]         VARCHAR (100) NOT NULL,
    [ReportsToOrgChartPositionID] INT           NULL,
    [IsTopNode]                   BIT           NOT NULL,
    [CompanyID]                   INT           NULL,
    [PersonEmployeeID]            INT           NULL,
    [CreatedDT]                   DATETIME2 (7) NULL,
    [UpdatedDT]                   DATETIME2 (7) NULL,
    [IsActive]                    BIT           NULL,
    CONSTRAINT [PK_OrgChartPosition] PRIMARY KEY CLUSTERED ([OrgChartPositionID] ASC)
);


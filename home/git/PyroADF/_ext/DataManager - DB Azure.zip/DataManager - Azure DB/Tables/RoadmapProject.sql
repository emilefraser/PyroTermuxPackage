﻿CREATE TABLE [GOV].[RoadmapProject] (
    [RoadmapProjectID]      INT            IDENTITY (1, 1) NOT NULL,
    [ProjectName]           VARCHAR (200)  NOT NULL,
    [ProjectDescription]    VARCHAR (1000) NULL,
    [BusinessArea]          VARCHAR (100)  NOT NULL,
    [BusinessSubArea]       VARCHAR (100)  NOT NULL,
    [ProjectStartDate]      DATE           NULL,
    [EstimatedDurationDays] INT            NOT NULL,
    [BusinessImpactScore]   DECIMAL (4, 2) NOT NULL,
    [FeasibilityScore]      DECIMAL (4, 2) NOT NULL,
    [CompletionPercentage]  DECIMAL (4, 2) NULL,
    [IsFollowPriorityQueue] BIT            NULL,
    CONSTRAINT [PK_RoadmapProject] PRIMARY KEY CLUSTERED ([RoadmapProjectID] ASC)
);


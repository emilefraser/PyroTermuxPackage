﻿CREATE TABLE [DC].[ServerType] (
    [ServerTypeID]          INT           IDENTITY (1, 1) NOT NULL,
    [ServerTypeCode]        VARCHAR (50)  NULL,
    [ServerTypeDescription] VARCHAR (100) NULL,
    [CreatedDT]             DATETIME2 (7) NULL,
    [ModifiedDT]            DATETIME2 (7) NULL
);


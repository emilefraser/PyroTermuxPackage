﻿CREATE TABLE [REPREG].[ReportElement] (
    [ReportElementID]          INT            IDENTITY (1, 1) NOT NULL,
    [ReportElementName]        VARCHAR (200)  NOT NULL,
    [ReportElementDescription] VARCHAR (4000) NOT NULL,
    [ReportID]                 INT            NOT NULL,
    [CreatedDT]                DATETIME2 (7)  NULL,
    [ModifedDT]                DATETIME2 (7)  NULL,
    [IsActive]                 BIT            NULL
);


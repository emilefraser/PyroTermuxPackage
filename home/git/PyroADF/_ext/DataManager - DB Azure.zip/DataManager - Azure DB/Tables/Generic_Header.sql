﻿CREATE TABLE [TYPE].[Generic_Header] (
    [HeaderID]            INT           IDENTITY (1, 1) NOT NULL,
    [HeaderCode]          VARCHAR (50)  NULL,
    [HeaderTypeGroupName] VARCHAR (50)  NULL,
    [CreatedDT]           DATETIME2 (7) CONSTRAINT [DF_Generic_Header_CreatedDT] DEFAULT (getdate()) NULL,
    [Modified]            DATETIME2 (7) NULL,
    [IsActive]            BIT           NULL
);


﻿CREATE TABLE [MASTER].[CompanyLeadPosition] (
    [CompanyLeadPositionID]  INT IDENTITY (1, 1) NOT NULL,
    [CompanyID]              INT NOT NULL,
    [LeadEmployeePositionID] INT NOT NULL,
    CONSTRAINT [PK_CompanyLeadPosition] PRIMARY KEY CLUSTERED ([CompanyLeadPositionID] ASC)
);


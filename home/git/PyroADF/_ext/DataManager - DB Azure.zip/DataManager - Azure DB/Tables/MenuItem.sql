﻿CREATE TABLE [APP].[MenuItem] (
    [MenuItemID]       INT           IDENTITY (1, 1) NOT NULL,
    [MenuItemNavTo]    VARCHAR (MAX) NULL,
    [MenuItemParentID] INT           NULL,
    [IsHeaderItem]     BIT           NULL,
    [SortOrder]        INT           NULL,
    [HasChildren]      BIT           NULL,
    [ModuleID]         INT           NULL,
    [MenuItemName]     VARCHAR (100) NULL,
    [CreatedDT]        DATETIME2 (7) NULL,
    [UpdatedDT]        DATETIME2 (7) NULL,
    [IsActive]         BIT           NULL,
    PRIMARY KEY CLUSTERED ([MenuItemID] ASC)
);


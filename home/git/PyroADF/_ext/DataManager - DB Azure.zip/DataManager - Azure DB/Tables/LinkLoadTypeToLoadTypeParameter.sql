﻿CREATE TABLE [DMOD].[LinkLoadTypeToLoadTypeParameter] (
    [LinkLoadTypeToLoadTypeParameterID] INT IDENTITY (1, 1) NOT NULL,
    [LoadTypeID]                        INT NOT NULL,
    [LoadTypeParameterID]               INT NOT NULL,
    CONSTRAINT [PK_LinkLoadTypeToLoadTypeParameter] PRIMARY KEY CLUSTERED ([LinkLoadTypeToLoadTypeParameterID] ASC)
);


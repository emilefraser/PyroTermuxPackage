﻿CREATE TABLE [DC].[Schema] (
    [SchemaID]   INT           IDENTITY (1, 1) NOT NULL,
    [SchemaName] VARCHAR (100) NOT NULL,
    [DatabaseID] INT           NOT NULL,
    [DBSchemaID] INT           NULL,
    [SystemID]   INT           NULL,
    [CreatedDT]  DATETIME2 (7) NULL,
    [UpdatedDT]  DATETIME2 (7) NULL,
    [IsActive]   BIT           CONSTRAINT [DF_Schema_IsActive] DEFAULT ((1)) NULL,
    [LastSeenDT] DATETIME2 (7) NULL,
    CONSTRAINT [PK_Schema] PRIMARY KEY CLUSTERED ([SchemaID] ASC)
);


﻿CREATE TABLE [DMOD].[SatelliteFieldDataVelocity_RESTORE] (
    [SatelliteFieldDataVelocityID]     INT          IDENTITY (1, 1) NOT NULL,
    [HubID]                            INT          NULL,
    [TransactionLinkID]                INT          NULL,
    [IsDetailTransactionLinkSat]       BIT          NOT NULL,
    [FieldID]                          INT          NOT NULL,
    [SatelliteColumnName]              VARCHAR (75) NULL,
    [SatelliteFieldDataVelocityTypeID] INT          NOT NULL,
    [SessionID]                        INT          NULL,
    CONSTRAINT [PK__FieldData_RESTORE] PRIMARY KEY CLUSTERED ([SatelliteFieldDataVelocityID] ASC)
);


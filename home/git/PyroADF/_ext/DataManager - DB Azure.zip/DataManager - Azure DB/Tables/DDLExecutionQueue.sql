﻿CREATE TABLE [EXECUTION].[DDLExecutionQueue] (
    [DDLExecutionQueueID]      INT            IDENTITY (1, 1) NOT NULL,
    [DDLQueryText]             VARCHAR (MAX)  NOT NULL,
    [DDLQueryDescription]      VARCHAR (1000) NOT NULL,
    [TargetDatabaseInstanceID] INT            NOT NULL,
    [Result]                   VARCHAR (100)  NOT NULL,
    [CreatedDT]                DATETIME2 (7)  NULL,
    [ErrorMessage]             VARCHAR (1000) NULL,
    [ErrorID]                  INT            NULL,
    [ExecutedDT]               DATETIME2 (7)  NULL,
    [DDLHashCheck]             VARCHAR (40)   NULL,
    CONSTRAINT [PK_DDLExecutionQueue] PRIMARY KEY CLUSTERED ([DDLExecutionQueueID] ASC)
);


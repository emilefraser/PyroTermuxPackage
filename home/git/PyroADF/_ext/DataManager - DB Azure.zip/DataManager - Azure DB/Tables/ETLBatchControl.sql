﻿CREATE TABLE [ETL].[ETLBatchControl] (
    [BatchID]             INT          IDENTITY (1, 1) NOT NULL,
    [ETLStepID]           INT          NULL,
    [DataEntityID]        INT          NULL,
    [LastTransactionDate] DATETIME     NULL,
    [ExecutionStartDate]  DATETIME     NULL,
    [ExecutionEndDate]    DATETIME     NULL,
    [ExecutionStatus]     VARCHAR (50) NULL,
    [PackageName]         VARCHAR (50) NULL,
    [TransferRowCount]    INT          NULL
);


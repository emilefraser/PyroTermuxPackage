﻿CREATE TABLE [DMOD].[LinkHubToManyToManyLink] (
    [LinkHubToManyToManyLinkID] INT IDENTITY (1, 1) NOT NULL,
    [ManyToManyLinkID]          INT NOT NULL,
    [HubID]                     INT NOT NULL,
    [HubSortOrder]              INT NOT NULL,
    CONSTRAINT [PK__LinkHubL__33882371416BDB67] PRIMARY KEY CLUSTERED ([LinkHubToManyToManyLinkID] ASC)
);


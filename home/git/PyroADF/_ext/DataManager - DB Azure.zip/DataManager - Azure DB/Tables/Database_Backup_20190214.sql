﻿CREATE TABLE [DC].[Database_Backup_20190214] (
    [DatabaseID]             INT             IDENTITY (1, 1) NOT NULL,
    [DatabaseName]           VARCHAR (100)   NOT NULL,
    [AccessInstructions]     VARCHAR (500)   NULL,
    [Size]                   DECIMAL (19, 6) NULL,
    [DatabaseInstanceID]     INT             NULL,
    [SystemID]               INT             NULL,
    [ExternalDatasourceName] VARCHAR (100)   NULL,
    [DatabasePurposeID]      INT             NULL,
    [DBDatabaseID]           INT             NULL,
    [CreatedDT]              DATETIME2 (7)   NULL,
    [ModifiedDT]             DATETIME2 (7)   NULL,
    [IsActive]               BIT             NULL
);


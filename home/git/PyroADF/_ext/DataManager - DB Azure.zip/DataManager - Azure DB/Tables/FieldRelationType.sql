﻿CREATE TABLE [DC].[FieldRelationType] (
    [FieldRelationTypeID]   INT           IDENTITY (1, 1) NOT NULL,
    [FieldRelationTypeCode] VARCHAR (50)  NULL,
    [FieldRelationTypeName] VARCHAR (100) NULL,
    [CreatedDT]             DATETIME2 (7) NULL,
    [ModifiedDT]            DATETIME2 (7) NULL,
    CONSTRAINT [PK_FieldRelationType] PRIMARY KEY CLUSTERED ([FieldRelationTypeID] ASC)
);


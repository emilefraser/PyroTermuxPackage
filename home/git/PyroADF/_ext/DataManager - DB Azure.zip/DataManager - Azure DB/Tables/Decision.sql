﻿CREATE TABLE [MANAGEMENT].[Decision] (
    [DecisionID]          INT              IDENTITY (1, 1) NOT NULL,
    [DecisionArea]        VARCHAR (50)     NULL,
    [DecisionName]        VARCHAR (50)     NULL,
    [DecisionDescription] VARBINARY (1000) NULL
);


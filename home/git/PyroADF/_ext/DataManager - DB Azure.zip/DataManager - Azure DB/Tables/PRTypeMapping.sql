﻿CREATE TABLE [GOV].[PRTypeMapping] (
    [PRTypeMappingID]       INT IDENTITY (1, 1) NOT NULL,
    [DetailID]              INT NULL,
    [IsUniquePRTypeMapping] BIT NULL,
    PRIMARY KEY CLUSTERED ([PRTypeMappingID] ASC)
);


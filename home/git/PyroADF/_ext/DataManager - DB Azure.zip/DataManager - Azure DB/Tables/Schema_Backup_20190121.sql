﻿CREATE TABLE [DC].[Schema_Backup_20190121] (
    [SchemaID]   INT           IDENTITY (1, 1) NOT NULL,
    [SchemaName] VARCHAR (100) NOT NULL,
    [DatabaseID] INT           NOT NULL,
    [DBSchemaID] INT           NULL,
    [CreatedDT]  DATETIME2 (7) NULL,
    [ModifiedDT] DATETIME2 (7) NULL,
    [IsActive]   BIT           NULL
);


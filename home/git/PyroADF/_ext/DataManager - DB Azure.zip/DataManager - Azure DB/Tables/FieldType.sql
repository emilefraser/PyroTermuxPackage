﻿CREATE TABLE [DC].[FieldType] (
    [FieldTypeID]   INT           IDENTITY (1, 1) NOT NULL,
    [FieldTypeCode] VARCHAR (50)  NULL,
    [FieldTypeName] VARCHAR (150) NULL,
    PRIMARY KEY CLUSTERED ([FieldTypeID] ASC)
);


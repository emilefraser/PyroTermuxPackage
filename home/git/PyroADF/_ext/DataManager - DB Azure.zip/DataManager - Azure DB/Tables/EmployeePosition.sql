﻿CREATE TABLE [SOURCELINK].[EmployeePosition] (
    [EmployeePositionID]          INT           IDENTITY (1, 1) NOT NULL,
    [EmployeePositionCode]        VARCHAR (50)  NOT NULL,
    [EmployeePositionDescription] VARCHAR (200) NOT NULL,
    [ReportsToPositionID]         INT           NULL,
    [EmployeeID]                  INT           NULL,
    [CompanyID]                   INT           NOT NULL,
    [IsActive]                    BIT           NOT NULL,
    [CreatedDT]                   DATETIME2 (7) NULL,
    CONSTRAINT [PK_EmployeePosition] PRIMARY KEY CLUSTERED ([EmployeePositionID] ASC)
);


﻿CREATE TABLE [DMOD].[ParameterScriptTest] (
    [PScript] VARCHAR (MAX) NULL
);


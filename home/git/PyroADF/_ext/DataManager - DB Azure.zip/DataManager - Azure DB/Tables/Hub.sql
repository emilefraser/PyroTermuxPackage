﻿CREATE TABLE [DMOD].[Hub] (
    [HubID]           INT           IDENTITY (1, 1) NOT NULL,
    [HubName]         VARCHAR (150) NOT NULL,
    [HubDataEntityID] INT           NULL,
    [EnsembleStatus]  INT           NULL,
    [CreatedDT]       DATETIME2 (7) NULL,
    [UpdatedDT]       DATETIME2 (7) NULL,
    [IsActive]        BIT           NULL,
    CONSTRAINT [PK__HUB_Work__9F4FFECF60035275] PRIMARY KEY CLUSTERED ([HubID] ASC)
);


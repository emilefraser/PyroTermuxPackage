﻿CREATE TABLE [DC].[DatabaseInstance] (
    [DatabaseInstanceID]           INT           IDENTITY (1, 1) NOT NULL,
    [DatabaseInstanceName]         VARCHAR (50)  NULL,
    [ServerID]                     INT           NOT NULL,
    [DatabaseAuthenticationTypeID] INT           NOT NULL,
    [AuthUsername]                 VARCHAR (50)  NULL,
    [AuthPassword]                 VARCHAR (50)  NULL,
    [IsDefaultInstance]            BIT           NULL,
    [NetworkPort]                  INT           NULL,
    [CreatedDT]                    DATETIME2 (7) NULL,
    [UpdatedDT]                    DATETIME2 (7) NULL,
    [IsActive]                     BIT           CONSTRAINT [DF_DatabaseInstance_IsActive] DEFAULT ((1)) NULL,
    CONSTRAINT [PK_DatabaseInstance] PRIMARY KEY CLUSTERED ([DatabaseInstanceID] ASC)
);


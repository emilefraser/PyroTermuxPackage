﻿CREATE TABLE [GOV].[DataDomain] (
    [DataDomainID]          INT           IDENTITY (1, 1) NOT NULL,
    [DataDomainCode]        VARCHAR (50)  NULL,
    [DataDomainDescription] VARCHAR (200) NULL,
    [DataDomainParentID]    INT           NULL,
    [CreatedDT]             DATETIME2 (7) NULL,
    [UpdatedDT]             DATETIME2 (7) NULL,
    [IsActive]              BIT           NULL,
    PRIMARY KEY CLUSTERED ([DataDomainID] ASC)
);


﻿CREATE TABLE [DMOD].[Parameter] (
    [ParameterID]          INT           IDENTITY (1, 1) NOT NULL,
    [ParameterCode]        VARCHAR (50)  NOT NULL,
    [ParameterDescription] VARCHAR (200) NOT NULL,
    [ParameterValueType]   VARCHAR (10)  NOT NULL,
    [CreatedDT]            DATETIME2 (7) NOT NULL,
    [UpdatedDT]            DATETIME2 (7) NULL,
    [IsActive]             BIT           NOT NULL,
    CONSTRAINT [PK_Parameter] PRIMARY KEY CLUSTERED ([ParameterID] ASC)
);


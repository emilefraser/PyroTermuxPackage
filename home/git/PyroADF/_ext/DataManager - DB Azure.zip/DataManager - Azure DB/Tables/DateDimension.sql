﻿CREATE TABLE [MASTER].[DateDimension] (
    [CalendarDate]          DATE         NOT NULL,
    [IsWeekend]             BIT          NULL,
    [Year]                  SMALLINT     NULL,
    [QuarterNo]             TINYINT      NULL,
    [MonthNumber]           VARCHAR (2)  NULL,
    [DayofYear]             SMALLINT     NULL,
    [Day]                   TINYINT      NULL,
    [Week]                  TINYINT      NULL,
    [DayofWeekNo]           TINYINT      NULL,
    [DayofWeek]             VARCHAR (9)  NULL,
    [DayofWeekAbbreviation] VARCHAR (3)  NULL,
    [Month]                 VARCHAR (20) NULL,
    [MonthAbbreviation]     VARCHAR (5)  NULL,
    [MonthBeginDate]        DATE         NULL,
    [MonthEndDate]          DATE         NULL,
    [WeekBeginDate]         DATE         NULL,
    [WeekEndDate]           DATE         NULL,
    [PreviousYear]          INT          NULL,
    [PreviousYearDate]      DATE         NULL,
    PRIMARY KEY CLUSTERED ([CalendarDate] ASC)
);


﻿CREATE TABLE [DC].[DataSourceCredential] (
    [DSCredentialID] INT IDENTITY (1, 1) NOT NULL
);


﻿CREATE TABLE [ACCESS].[ReportUser] (
    [ReportUserID]  INT           IDENTITY (1, 1) NOT NULL,
    [DomainAccount] VARCHAR (200) NOT NULL,
    [IsActive]      BIT           NOT NULL,
    [EmployeeID]    INT           NULL,
    [CreatedDT]     DATETIME2 (7) NULL,
    CONSTRAINT [PK_ReportUser] PRIMARY KEY CLUSTERED ([ReportUserID] ASC)
);


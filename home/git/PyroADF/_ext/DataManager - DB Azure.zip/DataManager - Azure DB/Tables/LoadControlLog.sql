﻿CREATE TABLE [ETL].[LoadControlLog] (
    [LoadControlLogID]       INT            IDENTITY (1, 1) NOT NULL,
    [LoadControlID]          INT            NOT NULL,
    [QueuedForProcessingDT]  DATETIME2 (7)  NOT NULL,
    [ProcessingStartDT]      DATETIME2 (7)  NULL,
    [ProcessingFinishedDT]   DATETIME2 (7)  NULL,
    [LastProcessingKeyValue] VARCHAR (50)   NULL,
    [NewRowCount]            INT            NULL,
    [UpdatedRowCount]        INT            NULL,
    [DeletedRowCount]        INT            NULL,
    [NewRowBytes]            INT            NULL,
    [UpdatedRowBytes]        INT            NULL,
    [IsReload]               BIT            NOT NULL,
    [IsError]                BIT            NOT NULL,
    [ErrorMessage]           VARCHAR (4000) NULL,
    CONSTRAINT [PK_LoadControlLog] PRIMARY KEY CLUSTERED ([LoadControlLogID] ASC, [LoadControlID] ASC, [QueuedForProcessingDT] ASC)
);


﻿CREATE TABLE [DC].[DataType] (
    [DataTypeID] INT           IDENTITY (1, 1) NOT NULL,
    [DataType]   VARCHAR (500) NOT NULL
);


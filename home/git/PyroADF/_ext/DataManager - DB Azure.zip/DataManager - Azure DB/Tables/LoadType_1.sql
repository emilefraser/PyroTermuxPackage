﻿CREATE TABLE [DMOD].[LoadType] (
    [LoadTypeID]                  INT            IDENTITY (1, 1) NOT NULL,
    [LoadTypeCode]                VARCHAR (50)   NULL,
    [LoadTypeName]                VARCHAR (50)   NOT NULL,
    [LoadTypeDescription]         VARCHAR (500)  NULL,
    [ParameterisedTemplateScript] VARCHAR (MAX)  NULL,
    [StaticTemplateScript]        VARCHAR (MAX)  NULL,
    [LoadScriptVersionNo]         DECIMAL (9, 2) NULL,
    [IsStaticTemplateProcessed]   BIT            NULL,
    [CreatedDT]                   DATETIME2 (7)  NOT NULL,
    [ModifiedDT]                  DATETIME2 (7)  NULL,
    [IsActive]                    BIT            NOT NULL,
    [IsValidated]                 BIT            NULL,
    [CreatedBy]                   VARCHAR (100)  NULL,
    [ModifiedBy]                  VARCHAR (100)  NULL,
    [LoadType]                    VARCHAR (100)  NULL,
    [LoadTypeTargetDatabase]      VARCHAR (100)  NULL,
    [isExternalTable]             BIT            NULL,
    [LoadTypeEntity]              VARCHAR (100)  NULL,
    CONSTRAINT [PK_LoadType] PRIMARY KEY CLUSTERED ([LoadTypeID] ASC)
);


GO

CREATE TRIGGER DMOD.[tr_Prevent_Update_StaticTemplateScript]
ON DMOD.LoadType
AFTER UPDATE
AS
BEGIN
    SET ROWCOUNT 0;
    SET NOCOUNT ON;
	DECLARE @isValidated BIT

	IF (UPDATE (StaticTemplateScript) OR  UPDATE (ParameterisedTemplateScript))
    BEGIN

		SET @isValidated = 
		(
			SELECT lt.IsValidated
			from  DMOD.LoadType lt
			inner join inserted i on lt.LoadTypeID=i.LoadTypeID 
		)

		IF @isValidated = 1
		BEGIN
			RAISERROR ('You cannot UDPDATE the StaticTemplateScript or ParameterisedTemplateScript while isValidated is 1', 16, 1)
			ROLLBACK TRANSACTION
			RETURN
		END
	END
END

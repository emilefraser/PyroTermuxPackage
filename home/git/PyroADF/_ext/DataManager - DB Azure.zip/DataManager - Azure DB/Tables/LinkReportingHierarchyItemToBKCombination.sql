﻿CREATE TABLE [MASTER].[LinkReportingHierarchyItemToBKCombination] (
    [LinkID]                   INT IDENTITY (1, 1) NOT NULL,
    [ReportingHierarchyItemID] INT NOT NULL,
    [SortOrder]                INT NULL,
    CONSTRAINT [PK_LinkReportingHierarchyItemToBKCombination] PRIMARY KEY CLUSTERED ([LinkID] ASC, [ReportingHierarchyItemID] ASC)
);


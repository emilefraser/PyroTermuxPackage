﻿CREATE TABLE [DC].[FieldRelation_Backup_PH] (
    [FieldRelationID]      INT           IDENTITY (1, 1) NOT NULL,
    [SourceFieldID]        INT           NULL,
    [TargetFieldID]        INT           NULL,
    [FieldRelationTypeID]  INT           NULL,
    [TransformDescription] VARCHAR (500) NULL,
    [CreatedDT]            DATETIME2 (7) NULL,
    [ModifiedDT]           DATETIME2 (7) NULL,
    [IsActive]             BIT           NULL
);


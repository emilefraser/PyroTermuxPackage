﻿CREATE TABLE [dbo].[HierarchyTree] (
    [ID]       INT          NULL,
    [ParentID] INT          NULL,
    [Level]    INT          NULL,
    [Code]     VARCHAR (5)  NULL,
    [Name]     VARCHAR (13) NULL
);


﻿CREATE TABLE [DMOD].[ManyToManyLink] (
    [ManyToManyLinkID]       INT           IDENTITY (1, 1) NOT NULL,
    [LinkName]               VARCHAR (100) NOT NULL,
    [ManyToManyDataEntityID] INT           NULL,
    [SourceDataEnitityID]    INT           NULL,
    [HubID]                  INT           NULL,
    CONSTRAINT [PK_LinkManyToMany] PRIMARY KEY CLUSTERED ([ManyToManyLinkID] ASC)
);


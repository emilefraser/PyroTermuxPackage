﻿CREATE TABLE [DMOD].[HubBusinessKey] (
    [HubBusinessKeyID] INT           IDENTITY (1, 1) NOT NULL,
    [HubID]            INT           NOT NULL,
    [HubBKFieldID]     INT           NULL,
    [FieldSortOrder]   SMALLINT      NULL,
    [BKFriendlyName]   VARCHAR (50)  NULL,
    [CreatedDT]        DATETIME2 (7) NULL,
    [UpdatedDT]        DATETIME2 (7) NULL,
    [IsActive]         BIT           NULL,
    CONSTRAINT [PK__HubBusin__7DEE621BEC3D2A90] PRIMARY KEY CLUSTERED ([HubBusinessKeyID] ASC)
);


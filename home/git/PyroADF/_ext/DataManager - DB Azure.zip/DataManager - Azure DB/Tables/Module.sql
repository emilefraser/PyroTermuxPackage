﻿CREATE TABLE [APP].[Module] (
    [ModuleID]          INT           IDENTITY (1, 1) NOT NULL,
    [ModuleName]        VARCHAR (50)  NULL,
    [ModuleDescription] VARCHAR (225) NULL,
    [CreatedDT]         DATETIME2 (7) NULL,
    [UpdatedDT]         DATETIME2 (7) NULL,
    [IsActive]          BIT           NULL,
    CONSTRAINT [PK_App] PRIMARY KEY CLUSTERED ([ModuleID] ASC)
);


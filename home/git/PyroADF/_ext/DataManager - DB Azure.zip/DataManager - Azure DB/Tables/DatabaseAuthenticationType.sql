﻿CREATE TABLE [DC].[DatabaseAuthenticationType] (
    [DatabaseAuthenticationTypeID] INT           IDENTITY (1, 1) NOT NULL,
    [DBAuthTypeName]               VARCHAR (50)  NOT NULL,
    [CreatedDT]                    DATETIME2 (7) NULL,
    [ModifiedDT]                   DATETIME2 (7) NULL,
    [IsActive]                     BIT           CONSTRAINT [DF_DatabaseAuthenticationType_IsActive] DEFAULT ((1)) NULL,
    CONSTRAINT [PK_DatabaseAuthenticationType] PRIMARY KEY CLUSTERED ([DatabaseAuthenticationTypeID] ASC)
);


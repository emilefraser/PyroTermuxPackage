﻿CREATE TABLE [ACCESS].[ReportUserEmployeeHierarchyAccess_ToDelete] (
    [ReportUserEmployeeHierarchyAccessID] INT IDENTITY (1, 1) NOT NULL,
    [PersonAccessContolListID]            INT NOT NULL,
    [EmployeePositionID]                  INT NOT NULL,
    [IsDefaultEntryPoint]                 BIT NOT NULL,
    CONSTRAINT [PK_ReportUserEmployeeHierarchyAccess] PRIMARY KEY CLUSTERED ([ReportUserEmployeeHierarchyAccessID] ASC)
);


﻿CREATE TABLE [SDEL].[InfoMartObject] (
    [InfoMartObjectID]   INT           IDENTITY (1, 1) NOT NULL,
    [InfoMartObjectName] VARCHAR (150) NOT NULL,
    [DeliveryStatus]     VARCHAR (150) NOT NULL,
    [Priority]           INT           NOT NULL,
    [CreatedDT]          DATETIME2 (7) NULL,
    [UpdatedDT]          DATETIME2 (7) NULL,
    [IsActive]           BIT           NULL,
    CONSTRAINT [PK__InfoMartObject] PRIMARY KEY CLUSTERED ([InfoMartObjectID] ASC)
);


﻿CREATE TABLE [ETL].[LoadConfig] (
    [LoadConfigID]            INT           IDENTITY (1, 1) NOT NULL,
    [SourceDataEntityID]      INT           NOT NULL,
    [TargetDataEntityID]      INT           NOT NULL,
    [LoadTypeID]              INT           NULL,
    [IsSetForReloadOnNextRun] BIT           NULL,
    [OffsetDays]              INT           NULL,
    [NewDataFilterType]       VARCHAR (50)  NULL,
    [PrimaryKeyField]         VARCHAR (50)  NULL,
    [TransactionNoField]      VARCHAR (50)  NULL,
    [CreatedDTField]          VARCHAR (50)  NULL,
    [UpdatedDTField]          VARCHAR (50)  NULL,
    [IsActive]                BIT           NULL,
    [CreatedDT]               DATETIME2 (7) NULL,
    [UpdatedDT]               DATETIME2 (7) NULL
);


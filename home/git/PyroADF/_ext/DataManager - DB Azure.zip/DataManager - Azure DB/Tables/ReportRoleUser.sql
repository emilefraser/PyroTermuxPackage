﻿CREATE TABLE [ACCESS].[ReportRoleUser] (
    [ReportRoleUserID]          INT IDENTITY (1, 1) NOT NULL,
    [PersonAccessControlListID] INT NOT NULL,
    [ReportRoleID]              INT NOT NULL,
    CONSTRAINT [PK_ReportRoleUser] PRIMARY KEY CLUSTERED ([ReportRoleUserID] ASC)
);


﻿CREATE TABLE [DMOD].[LoadProcExports] (
    [LoadProcID]   INT           IDENTITY (1, 1) NOT NULL,
    [TableName]    VARCHAR (100) NULL,
    [PScript]      VARCHAR (MAX) NULL,
    [Author]       VARCHAR (100) NULL,
    [CreatedDT]    DATETIME2 (7) NULL,
    [Status]       VARCHAR (100) NULL,
    [LoadConfigID] INT           NULL
);


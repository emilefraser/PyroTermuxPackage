﻿CREATE TABLE [DMOD].[LoadConfig] (
    [LoadConfigID]            INT           IDENTITY (1, 1) NOT NULL,
    [LoadTypeID]              INT           NOT NULL,
    [SourceDataEntityID]      INT           NOT NULL,
    [TargetDataEntityID]      INT           NOT NULL,
    [IsSetForReloadOnNextRun] BIT           NOT NULL,
    [OffsetDays]              INT           NULL,
    [CreatedDT]               DATETIME2 (7) NOT NULL,
    [ModifiedDT]              DATETIME2 (7) NULL,
    [IsActive]                BIT           NOT NULL,
    CONSTRAINT [PK_LoadConfig] PRIMARY KEY CLUSTERED ([LoadConfigID] ASC)
);


GO
CREATE UNIQUE NONCLUSTERED INDEX [unci_DMOD_LoadConfig]
    ON [DMOD].[LoadConfig]([SourceDataEntityID] ASC, [TargetDataEntityID] ASC, [LoadTypeID] ASC);


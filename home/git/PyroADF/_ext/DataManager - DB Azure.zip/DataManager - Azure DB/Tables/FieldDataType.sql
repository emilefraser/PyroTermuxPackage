﻿CREATE TABLE [DC].[FieldDataType] (
    [DataTypeID]   INT           IDENTITY (1, 1) NOT NULL,
    [DataType]     VARCHAR (500) NOT NULL,
    [IsConcat]     BIT           NULL,
    [SystemTypeID] INT           NULL,
    [CreatedDT]    DATETIME2 (7) NULL,
    [UpdatedDT]    DATETIME2 (7) NULL
);


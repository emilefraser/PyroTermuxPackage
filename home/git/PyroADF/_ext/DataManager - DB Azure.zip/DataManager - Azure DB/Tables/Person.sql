﻿CREATE TABLE [GOV].[Person] (
    [PersonID]           INT           IDENTITY (1, 1) NOT NULL,
    [FirstName]          VARCHAR (40)  NULL,
    [Surname]            VARCHAR (40)  NULL,
    [DomainAccountName]  VARCHAR (100) NULL,
    [Email]              VARCHAR (50)  NULL,
    [MobileNo]           VARCHAR (20)  NULL,
    [WorkNo]             VARCHAR (20)  NULL,
    [Department]         VARCHAR (100) NULL,
    [SubDepartment]      VARCHAR (100) NULL,
    [Team]               VARCHAR (100) NULL,
    [IsIntegratedRecord] BIT           NULL,
    [PersonUniqueKey]    VARCHAR (40)  NULL,
    [CreatedDT]          DATETIME2 (7) NULL,
    [UpdatedDT]          DATETIME2 (7) NULL,
    [IsActive]           BIT           NULL,
    CONSTRAINT [PK__Person__AA2FFB85FE773D45] PRIMARY KEY CLUSTERED ([PersonID] ASC)
);


﻿CREATE TABLE [CONFIG].[Company] (
    [CompanyID]            INT             IDENTITY (1, 1) NOT NULL,
    [CompanyCode]          VARCHAR (50)    NOT NULL,
    [CompanyName]          VARCHAR (100)   NOT NULL,
    [CompanyLogoOLD]       VARBINARY (MAX) NULL,
    [CompanyLogo]          VARCHAR (200)   NULL,
    [ReportingCompanyLogo] VARCHAR (200)   NULL,
    CONSTRAINT [PK_Company] PRIMARY KEY CLUSTERED ([CompanyID] ASC)
);


﻿CREATE TABLE [REPREG].[ReportStatusType] (
    [ReportStatusTypeID]    INT           NOT NULL,
    [ReportStatusTypeName]  VARCHAR (50)  NOT NULL,
    [DefaultErrorParagraph] VARCHAR (500) NULL,
    [ReportStatusIndicator] VARCHAR (200) NULL,
    [CreatedDT]             DATETIME2 (7) NULL,
    [ModifiedDT]            DATETIME2 (7) NULL,
    [IsActive]              BIT           NULL
);


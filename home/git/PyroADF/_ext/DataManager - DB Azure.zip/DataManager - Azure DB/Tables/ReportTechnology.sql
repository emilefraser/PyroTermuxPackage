﻿CREATE TABLE [REPREG].[ReportTechnology] (
    [ReportTechnologyID]   INT           IDENTITY (1, 1) NOT NULL,
    [ReportTechnologyName] VARCHAR (50)  NOT NULL,
    [IsReportPackCapable]  BIT           NOT NULL,
    [CreatedDT]            DATETIME2 (7) NULL,
    [ModifedDT]            DATETIME2 (7) NULL,
    [IsActive]             BIT           NULL
);


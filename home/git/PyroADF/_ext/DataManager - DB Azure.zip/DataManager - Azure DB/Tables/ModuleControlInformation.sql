﻿CREATE TABLE [APP].[ModuleControlInformation] (
    [ModuleControlInformationID] INT           IDENTITY (1, 1) NOT NULL,
    [ModuleID]                   INT           NULL,
    [ControlName]                VARCHAR (100) NULL,
    [InformationCode]            VARCHAR (60)  NULL,
    [InformationDescription]     VARCHAR (MAX) NULL,
    [CreatedDT]                  DATETIME2 (7) NULL,
    [UpdatedDT]                  DATETIME2 (7) NULL,
    [IsActive]                   BIT           NULL,
    PRIMARY KEY CLUSTERED ([ModuleControlInformationID] ASC)
);


GO
CREATE UNIQUE NONCLUSTERED INDEX [idx_InformationCodeUnique]
    ON [APP].[ModuleControlInformation]([InformationCode] ASC);


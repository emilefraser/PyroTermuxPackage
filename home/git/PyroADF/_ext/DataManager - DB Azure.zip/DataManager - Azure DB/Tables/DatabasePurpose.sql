﻿CREATE TABLE [DC].[DatabasePurpose] (
    [DatabasePurposeID]          INT            IDENTITY (1, 1) NOT NULL,
    [DatabasePurposeCode]        VARCHAR (50)   NULL,
    [DatabasePurposeName]        VARCHAR (100)  NULL,
    [DatabasePurposeDescription] VARCHAR (1000) NULL,
    [CreatedDT]                  DATETIME2 (7)  NULL,
    [ModifiedDT]                 DATETIME2 (7)  NULL,
    [IsActive]                   BIT            CONSTRAINT [DF_DatabasePurpose_IsActive] DEFAULT ((1)) NULL,
    CONSTRAINT [PK_DatabasePurpose] PRIMARY KEY CLUSTERED ([DatabasePurposeID] ASC)
);


﻿CREATE TABLE [APP].[LinkRoleToModuleAction] (
    [LinkRoleToModuleActionID] INT           IDENTITY (1, 1) NOT NULL,
    [RoleID]                   INT           NULL,
    [ModuleActionID]           INT           NULL,
    [CreatedDT]                DATETIME2 (7) NULL,
    [UpdatedDT]                DATETIME2 (7) NULL,
    [IsActive]                 BIT           NULL,
    PRIMARY KEY CLUSTERED ([LinkRoleToModuleActionID] ASC)
);


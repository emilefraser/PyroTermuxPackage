﻿CREATE TABLE [SDEL].[Ensamble_Per_Project] (
    [HubID]            INT NOT NULL,
    [InfoMartObjectID] INT NOT NULL,
    CONSTRAINT [PK__Ensamble_Per_Project] PRIMARY KEY CLUSTERED ([HubID] ASC, [InfoMartObjectID] ASC)
);


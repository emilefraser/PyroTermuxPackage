﻿CREATE TABLE [BG].[BusinessGlossaryLink] (
    [BusinessGlossaryID] INT NOT NULL,
    [DataEntityID]       INT NULL,
    [FieldID]            INT NULL
);


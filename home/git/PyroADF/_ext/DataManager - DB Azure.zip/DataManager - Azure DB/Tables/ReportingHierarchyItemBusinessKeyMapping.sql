﻿CREATE TABLE [UPLOAD].[ReportingHierarchyItemBusinessKeyMapping] (
    [BusinessKey]              VARCHAR (50) NULL,
    [ReportingHierarchyItemID] INT          NULL,
    [DataCatalogFieldID]       INT          NULL
);


﻿CREATE TABLE [DC].[DataEntity_FS] (
    [DataEntityID]      INT             IDENTITY (1, 1) NOT NULL,
    [DataEntityName]    VARCHAR (100)   NOT NULL,
    [FriendlyName]      VARCHAR (100)   NULL,
    [Description]       VARCHAR (100)   NULL,
    [DataEntityTypeID]  INT             NULL,
    [RowsCount]         BIGINT          NULL,
    [ColumnsCount]      VARCHAR (50)    NULL,
    [Size]              VARCHAR (50)    NULL,
    [DataQualityScore2] VARCHAR (10)    NULL,
    [DataQualityScore]  DECIMAL (18, 3) NULL,
    [SchemaID]          INT             NULL,
    [DBObjectID]        INT             NULL,
    [CreatedDT]         DATETIME2 (7)   NULL,
    [ModifiedDT]        DATETIME2 (7)   NULL,
    [IsActive]          BIT             NULL
);


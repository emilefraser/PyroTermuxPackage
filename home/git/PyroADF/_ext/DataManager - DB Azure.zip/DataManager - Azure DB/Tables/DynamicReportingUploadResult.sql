﻿CREATE TABLE [LOG].[DynamicReportingUploadResult] (
    [CreatedDT]   DATETIME2 (7) NOT NULL,
    [InsertTable] VARCHAR (50)  NOT NULL,
    [RecordCount] INT           NOT NULL
);


﻿CREATE TABLE [DYNREP].[FieldDataValue] (
    [FieldDataValueID]      INT            IDENTITY (1, 1) NOT NULL,
    [FieldDataValueGroupID] INT            NOT NULL,
    [LinkReportFieldID]     INT            NOT NULL,
    [DataValue]             VARCHAR (1000) NOT NULL,
    [CreatedDT]             DATETIME2 (7)  NULL,
    [ModifiedDT]            DATETIME2 (7)  NULL,
    [IsActive]              BIT            CONSTRAINT [DF_FieldDataValue_IsActive] DEFAULT ((1)) NULL,
    CONSTRAINT [PK_FieldDataValue] PRIMARY KEY CLUSTERED ([FieldDataValueID] ASC)
);


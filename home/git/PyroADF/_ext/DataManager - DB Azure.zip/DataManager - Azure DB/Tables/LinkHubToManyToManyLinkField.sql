﻿CREATE TABLE [DMOD].[LinkHubToManyToManyLinkField] (
    [LinkHubToManyToManyLinkFieldID] INT IDENTITY (1, 1) NOT NULL,
    [LinkHubToManyToManyLinkID]      INT NOT NULL,
    [HubPKFieldID]                   INT NOT NULL,
    [ManyToManyTableFKFieldID]       INT NOT NULL,
    CONSTRAINT [PK_LinkHubToManyToManyLinkField] PRIMARY KEY CLUSTERED ([LinkHubToManyToManyLinkFieldID] ASC)
);


﻿CREATE TABLE [INTEGRATION].[DataDistributionBatchData] (
    [DataConcat]              VARCHAR (MAX) NOT NULL,
    [DataDistributionBatchID] NCHAR (10)    NOT NULL
);


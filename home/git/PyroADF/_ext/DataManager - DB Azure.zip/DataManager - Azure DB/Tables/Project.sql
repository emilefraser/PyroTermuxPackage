﻿CREATE TABLE [SDEL].[Project] (
    [ProjectID]   INT           IDENTITY (1, 1) NOT NULL,
    [ProjectName] VARCHAR (150) NOT NULL,
    [CreatedDT]   DATETIME2 (7) NULL,
    [UpdatedDT]   DATETIME2 (7) NULL,
    [IsActive]    BIT           NULL,
    CONSTRAINT [PK__Project] PRIMARY KEY CLUSTERED ([ProjectID] ASC)
);


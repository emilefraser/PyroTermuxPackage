﻿CREATE TABLE [DMOD].[LoadTypeTemplateHistory] (
    [LoadTypeID]                  INT            NOT NULL,
    [LoadTypeCode]                VARCHAR (50)   NULL,
    [LoadTypeName]                VARCHAR (50)   NOT NULL,
    [LoadTypeDescription]         VARCHAR (500)  NULL,
    [ParameterisedTemplateScript] VARCHAR (MAX)  NULL,
    [StaticTemplateScript]        VARCHAR (MAX)  NULL,
    [LoadScriptVersionNo]         DECIMAL (9, 2) NULL,
    [CreatedDT]                   DATETIME2 (7)  NOT NULL,
    [ModifiedDT]                  DATETIME2 (7)  NULL,
    [IsActive]                    BIT            NOT NULL,
    [LoadScriptTemplate]          TEXT           NULL
);


﻿CREATE TABLE [ACCESS].[ReportingHierarchyUserAccess] (
    [ReportingHierarchyUserAccessID] INT           IDENTITY (1, 1) NOT NULL,
    [ReportingHierarchyItemID]       INT           NOT NULL,
    [PersonAccessControlListID]      INT           NOT NULL,
    [IsDefaultHierarchyItem]         BIT           NOT NULL,
    [CreatedDT]                      DATETIME2 (7) NULL,
    [UpdatedDT]                      DATETIME2 (7) NULL,
    [IsActive]                       BIT           NULL,
    CONSTRAINT [PK_ReportingHierarchyUserAccess] PRIMARY KEY CLUSTERED ([ReportingHierarchyUserAccessID] ASC)
);


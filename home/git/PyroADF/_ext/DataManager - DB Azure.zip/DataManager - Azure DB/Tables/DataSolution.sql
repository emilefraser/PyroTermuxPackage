﻿CREATE TABLE [SDEL].[DataSolution] (
    [DataSolutionID]   INT           IDENTITY (1, 1) NOT NULL,
    [DataSolutionName] VARCHAR (150) NOT NULL,
    [DeliveryStatus]   VARCHAR (150) NOT NULL,
    [Priority]         INT           NOT NULL,
    [CreatedDT]        DATETIME2 (7) NULL,
    [UpdatedDT]        DATETIME2 (7) NULL,
    [IsActive]         BIT           NULL,
    CONSTRAINT [PK__DataSolution] PRIMARY KEY CLUSTERED ([DataSolutionID] ASC)
);


﻿CREATE TABLE [ACCESS].[PersonAccessControlList] (
    [PersonAccessControlListID] INT           IDENTITY (1, 1) NOT NULL,
    [OrgChartPositionID]        INT           NULL,
    [PersonNonEmployeeID]       INT           NULL,
    [CreatedDT]                 DATETIME2 (7) NULL,
    [UpdatedDT]                 DATETIME2 (7) NULL,
    [IsActive]                  BIT           NULL
);


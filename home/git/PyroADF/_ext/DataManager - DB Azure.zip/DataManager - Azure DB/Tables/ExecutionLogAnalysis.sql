﻿CREATE TABLE [ETL].[ExecutionLogAnalysis] (
    [ExecutionLogID]       INT NOT NULL,
    [DurationSeconds]      INT NULL,
    [QueueSeconds]         INT NULL,
    [TotalExecutionTime]   INT NULL,
    [IsDataIntegrityError] BIT NULL
);


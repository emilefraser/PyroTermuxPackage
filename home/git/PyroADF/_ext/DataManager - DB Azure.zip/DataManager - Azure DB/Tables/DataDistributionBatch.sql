﻿CREATE TABLE [INTEGRATION].[DataDistributionBatch] (
    [DataDistributionBatchID] INT           IDENTITY (1, 1) NOT NULL,
    [DataEntityDDL]           VARCHAR (MAX) NOT NULL,
    [InsertPayload]           VARCHAR (MAX) NULL,
    [DeletePayload]           VARCHAR (MAX) NULL,
    [CreatedDT]               DATETIME2 (7) NOT NULL,
    CONSTRAINT [PK_DataDistributionBatch] PRIMARY KEY CLUSTERED ([DataDistributionBatchID] ASC)
);


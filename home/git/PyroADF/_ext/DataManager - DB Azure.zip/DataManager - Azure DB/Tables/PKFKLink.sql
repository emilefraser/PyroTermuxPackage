﻿CREATE TABLE [DMOD].[PKFKLink] (
    [PKFKLinkID]             INT           IDENTITY (1, 1) NOT NULL,
    [LinkName]               VARCHAR (100) NOT NULL,
    [ParentHubNameVariation] VARCHAR (150) NULL,
    [ParentHubID]            INT           NOT NULL,
    [ChildHubID]             INT           NOT NULL,
    [CreatedDT]              DATETIME2 (7) NULL,
    [UpdatedDT]              DATETIME2 (7) NULL,
    [IsActive]               BIT           NULL,
    CONSTRAINT [PK_LinkPKFK_Working] PRIMARY KEY CLUSTERED ([PKFKLinkID] ASC)
);


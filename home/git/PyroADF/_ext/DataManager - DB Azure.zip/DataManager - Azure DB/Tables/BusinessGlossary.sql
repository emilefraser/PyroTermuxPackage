﻿CREATE TABLE [BG].[BusinessGlossary] (
    [BusinessGlossaryID] INT            IDENTITY (1, 1) NOT NULL,
    [BusinessArea]       VARCHAR (100)  NULL,
    [BusinessTerm]       VARCHAR (100)  NULL,
    [Definition]         VARCHAR (2000) NULL,
    CONSTRAINT [PK_BusinessGlossary] PRIMARY KEY CLUSTERED ([BusinessGlossaryID] ASC)
);


﻿CREATE TABLE [MASTER].[ReportingHierarchyType] (
    [ReportingHierarchyTypeID]      INT            IDENTITY (1, 1) NOT NULL,
    [DataDomainID]                  INT            NULL,
    [ReportingHierarchyTypeCode]    VARCHAR (10)   NULL,
    [ReportingHierarchyTypeName]    VARCHAR (100)  NOT NULL,
    [ReportingHierarchyDescription] VARCHAR (1000) NOT NULL,
    [HierarchyLevelsLimit]          SMALLINT       NOT NULL,
    [IsUniqueBKMapping]             BIT            CONSTRAINT [DF_ReportingHierarchyType_IsUniqueBKMapping] DEFAULT ((1)) NULL,
    [CreatedDT]                     DATETIME2 (7)  NULL,
    [UpdatedDT]                     DATETIME2 (7)  NULL,
    [IsActive]                      BIT            NULL,
    CONSTRAINT [PK_ReportingHierarchyType] PRIMARY KEY CLUSTERED ([ReportingHierarchyTypeID] ASC)
);


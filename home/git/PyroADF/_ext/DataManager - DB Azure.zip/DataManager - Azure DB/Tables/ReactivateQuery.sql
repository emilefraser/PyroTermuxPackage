﻿CREATE TABLE [APP].[ReactivateQuery] (
    [ReactivateQueryID]     INT           IDENTITY (1, 1) NOT NULL,
    [TableName]             VARCHAR (200) NULL,
    [ReactivateQueryString] VARCHAR (MAX) NULL,
    PRIMARY KEY CLUSTERED ([ReactivateQueryID] ASC)
);


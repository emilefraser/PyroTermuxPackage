﻿CREATE TABLE [UPLOAD].[PersonEmployeeReportingHierarchyItemAccess] (
    [EmployeeCode]               VARCHAR (50)  NOT NULL,
    [ReportingHierarchyItemCode] VARCHAR (50)  NOT NULL,
    [ReportingHierarchyTypeCode] VARCHAR (50)  NOT NULL,
    [CreatedDT]                  DATETIME2 (7) NULL
);


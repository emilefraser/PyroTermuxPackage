﻿CREATE TABLE [DC].[LinkSystemServerTypeServer] (
    [LinkSystemServerTypeServerID] INT           IDENTITY (1, 1) NOT NULL,
    [SystemID]                     INT           NOT NULL,
    [ServerID]                     INT           NOT NULL,
    [ServerTypeID]                 INT           NOT NULL,
    [CreatedDT]                    DATETIME2 (7) NULL,
    [ModifiedDT]                   DATETIME2 (7) NULL,
    CONSTRAINT [PK_LinkSystemServerTypeServer] PRIMARY KEY CLUSTERED ([LinkSystemServerTypeServerID] ASC)
);


﻿CREATE TABLE [AUDIT].[AuditTrail] (
    [AuditTrailID]      INT           IDENTITY (1, 1) NOT NULL,
    [AuditData]         VARCHAR (MAX) NULL,
    [MasterEntity]      VARCHAR (50)  NULL,
    [TableName]         VARCHAR (50)  NULL,
    [PrimaryKeyID]      INT           NULL,
    [TransactionAction] NVARCHAR (20) NULL,
    [TransactionDT]     DATETIME2 (7) NULL,
    [TransactionPerson] VARCHAR (80)  NULL,
    PRIMARY KEY CLUSTERED ([AuditTrailID] ASC)
);


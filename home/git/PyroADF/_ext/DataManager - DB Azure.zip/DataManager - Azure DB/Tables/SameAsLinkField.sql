﻿CREATE TABLE [DMOD].[SameAsLinkField] (
    [SameAsLinkFieldID] INT IDENTITY (1, 1) NOT NULL,
    [SameAsLinkID]      INT NOT NULL,
    [MasterFieldID]     INT NOT NULL,
    [SlaveFieldID]      INT NOT NULL,
    [IsActive]          BIT NULL,
    CONSTRAINT [PK_SameAsLinkField] PRIMARY KEY CLUSTERED ([SameAsLinkFieldID] ASC)
);


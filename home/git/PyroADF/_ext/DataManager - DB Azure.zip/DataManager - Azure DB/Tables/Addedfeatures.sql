﻿CREATE TABLE [APP].[Addedfeatures] (
    [AddedfeatureID]      INT           IDENTITY (1, 1) NOT NULL,
    [FeaturesDescription] VARCHAR (225) NULL,
    [CreatedDT]           DATETIME2 (7) NULL,
    [UpdatedDT]           DATETIME2 (7) NULL,
    [IsActive]            BIT           NULL,
    [VersionID]           INT           NULL,
    CONSTRAINT [PK_Addedfeatures] PRIMARY KEY CLUSTERED ([AddedfeatureID] ASC)
);


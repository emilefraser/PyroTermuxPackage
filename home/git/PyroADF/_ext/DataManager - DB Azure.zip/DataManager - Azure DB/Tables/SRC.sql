﻿CREATE TABLE [FS].[SRC] (
    [ID]       INT           IDENTITY (1, 1) NOT NULL,
    [Name]     VARCHAR (50)  NULL,
    [UpdateDT] DATETIME2 (7) NULL
);


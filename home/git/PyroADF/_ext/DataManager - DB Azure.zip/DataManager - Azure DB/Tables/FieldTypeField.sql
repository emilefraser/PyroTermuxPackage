﻿CREATE TABLE [DC].[FieldTypeField] (
    [FieldTypeFieldID] INT           IDENTITY (1, 1) NOT NULL,
    [FieldID]          INT           NULL,
    [FieldTypeID]      INT           NULL,
    [CreatedDT]        DATETIME2 (7) NOT NULL,
    [ModifiedDT]       DATETIME2 (7) NULL,
    [IsActive]         BIT           NOT NULL,
    CONSTRAINT [PK__FieldTyp__4379C7B0CCD48507] PRIMARY KEY CLUSTERED ([FieldTypeFieldID] ASC)
);


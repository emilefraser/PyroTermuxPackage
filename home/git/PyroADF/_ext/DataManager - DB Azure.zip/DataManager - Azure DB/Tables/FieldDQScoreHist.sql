﻿CREATE TABLE [DC].[FieldDQScoreHist] (
    [FieldID]    INT             NOT NULL,
    [DQDate]     SMALLDATETIME   NULL,
    [DQScore]    DECIMAL (18, 2) NULL,
    [CreatedDT]  DATETIME2 (7)   NULL,
    [ModifiedDT] DATETIME2 (7)   NULL
);


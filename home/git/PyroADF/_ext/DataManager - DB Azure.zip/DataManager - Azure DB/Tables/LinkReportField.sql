﻿CREATE TABLE [DYNREP].[LinkReportField] (
    [LinkReportFieldID] INT              IDENTITY (1, 1) NOT NULL,
    [ReportID]          UNIQUEIDENTIFIER NOT NULL,
    [FieldID]           INT              NOT NULL,
    [CreatedDT]         DATETIME2 (7)    NULL,
    [ModifiedDT]        DATETIME2 (7)    NULL,
    [IsActive]          BIT              CONSTRAINT [DF_LinkReportField_IsActive] DEFAULT ((1)) NULL,
    CONSTRAINT [PK_LinkReportField] PRIMARY KEY CLUSTERED ([LinkReportFieldID] ASC)
);


﻿CREATE TABLE [DMOD].[HubBusinessKeyField] (
    [HubBusinessKeyFieldID] INT           IDENTITY (1, 1) NOT NULL,
    [HubBusinessKeyID]      INT           NOT NULL,
    [FieldID]               INT           NOT NULL,
    [IsBaseEntityField]     BIT           NULL,
    [CreatedDT]             DATETIME2 (7) NULL,
    [UpdatedDT]             DATETIME2 (7) NULL,
    [IsActive]              BIT           NULL,
    CONSTRAINT [PK_HubBusinessKeyField] PRIMARY KEY CLUSTERED ([HubBusinessKeyFieldID] ASC)
);


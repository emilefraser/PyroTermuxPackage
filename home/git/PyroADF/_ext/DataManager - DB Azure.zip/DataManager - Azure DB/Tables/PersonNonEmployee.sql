﻿CREATE TABLE [GOV].[PersonNonEmployee] (
    [PersonNonEmployeeID]         INT           IDENTITY (1, 1) NOT NULL,
    [PersonID]                    INT           NOT NULL,
    [SupplierCompany]             VARCHAR (100) NULL,
    [JobTitle]                    VARCHAR (100) NULL,
    [Code]                        VARCHAR (20)  NULL,
    [ReportsToOrgChartPositionID] INT           NULL,
    [CreatedDT]                   DATETIME2 (7) NULL,
    [UpdatedDT]                   DATETIME2 (7) NULL,
    [IsActive]                    BIT           NULL,
    CONSTRAINT [PK_NonEmployee] PRIMARY KEY CLUSTERED ([PersonNonEmployeeID] ASC)
);


﻿CREATE TABLE [GOV].[Sprint] (
    [SprintID]     INT           NOT NULL,
    [SprintNumber] INT           NOT NULL,
    [StartDate]    DATETIME2 (7) NOT NULL,
    [EndDate]      DATETIME2 (7) NULL,
    [IsActive]     BIT           NULL
);


﻿CREATE TABLE [DC].[FieldRelation_Backup_20190126] (
    [FieldRelationID]      INT           IDENTITY (1, 1) NOT NULL,
    [SourceFieldID]        INT           NULL,
    [TargetFieldID]        INT           NULL,
    [FieldRelationTypeID]  INT           NULL,
    [TransformDescription] VARCHAR (500) NULL,
    [CreatedDT]            DATETIME2 (7) NULL,
    [ModifiedDT]           DATETIME2 (7) NULL,
    [IsActive]             BIT           CONSTRAINT [DF_FieldRelation_IsActive_Backup] DEFAULT ((1)) NULL,
    CONSTRAINT [PK_DC.FieldRelation_Backup] PRIMARY KEY CLUSTERED ([FieldRelationID] ASC)
);


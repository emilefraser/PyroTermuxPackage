﻿CREATE TABLE [SDEL].[InfoMartObject_Per_DataSolution] (
    [InfoMartObectID] INT NOT NULL,
    [DataSolutionID]  INT NOT NULL,
    CONSTRAINT [PK__InfoMartObject_Per_DataSolution] PRIMARY KEY CLUSTERED ([InfoMartObectID] ASC, [DataSolutionID] ASC)
);


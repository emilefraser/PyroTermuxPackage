﻿CREATE TABLE [REPREG].[ReportErrorLog_ETL] (
    [ReportErrorLog_ETL_ID] INT           IDENTITY (1, 1) NOT NULL,
    [ReportID]              INT           NOT NULL,
    [ETLStepID]             INT           NULL,
    [ErrorTypeID]           INT           NULL,
    [ErrorDescription]      VARCHAR (500) NULL
);


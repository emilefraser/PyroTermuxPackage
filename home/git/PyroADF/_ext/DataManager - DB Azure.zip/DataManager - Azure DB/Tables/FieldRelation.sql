﻿CREATE TABLE [DC].[FieldRelation] (
    [FieldRelationID]      INT           IDENTITY (1, 1) NOT NULL,
    [SourceFieldID]        INT           NULL,
    [TargetFieldID]        INT           NULL,
    [FieldRelationTypeID]  INT           NULL,
    [TransformDescription] VARCHAR (500) NULL,
    [CreatedDT]            DATETIME2 (7) NULL,
    [ModifiedDT]           DATETIME2 (7) NULL,
    [IsActive]             BIT           CONSTRAINT [DF_FieldRelation_IsActive] DEFAULT ((1)) NULL,
    CONSTRAINT [PK_DC.FieldRelation] PRIMARY KEY CLUSTERED ([FieldRelationID] ASC)
);


GO
CREATE NONCLUSTERED INDEX [nc_idx_FieldRelation_1]
    ON [DC].[FieldRelation]([SourceFieldID] ASC, [TargetFieldID] ASC)
    INCLUDE([FieldRelationTypeID]);


﻿CREATE TABLE [ETL].[ETLSteps] (
    [ETLStepID]          INT           IDENTITY (1, 1) NOT NULL,
    [ETLID]              INT           NULL,
    [StepDescription]    VARCHAR (500) NULL,
    [StepSchedule]       VARCHAR (100) NULL,
    [StepExecutionOrder] INT           NOT NULL,
    [CurrentStatus]      VARCHAR (50)  NULL,
    [LastRunDate]        DATETIME      NULL,
    [LastRunStatus]      VARCHAR (50)  NULL,
    CONSTRAINT [PK_ETLSteps] PRIMARY KEY CLUSTERED ([ETLStepID] ASC)
);


﻿CREATE TABLE [DC].[DatabaseCrawler_ErrorHeader] (
    [DBCrawlErrorID]     INT          IDENTITY (1, 1) NOT NULL,
    [CrawlBatchID]       INT          NULL,
    [DatabaseInstanceID] INT          NULL,
    [DatabaseID]         INT          NULL,
    [ErrorDT]            DATETIME     NULL,
    [ErrorCount]         BIGINT       NULL,
    [CrawlSessionStatus] VARCHAR (50) NULL,
    CONSTRAINT [PK__Database__311E1C4E54591D21] PRIMARY KEY CLUSTERED ([DBCrawlErrorID] ASC)
);


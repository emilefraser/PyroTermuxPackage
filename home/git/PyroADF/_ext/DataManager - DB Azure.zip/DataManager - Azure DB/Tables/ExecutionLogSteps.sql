﻿CREATE TABLE [ETL].[ExecutionLogSteps] (
    [ExecutionLogStepID]     INT            NOT NULL,
    [ExecutionLogID]         INT            NOT NULL,
    [ExecutionStepNo]        INT            NULL,
    [StepDescription]        VARCHAR (1000) NOT NULL,
    [AffectedDatabaseName]   VARCHAR (100)  NOT NULL,
    [AffectedSchemaName]     VARCHAR (100)  NOT NULL,
    [AffectedDataEntityName] VARCHAR (100)  NOT NULL,
    [Action]                 VARCHAR (150)  NOT NULL,
    [StartDT]                DATETIME2 (7)  NOT NULL,
    [FinishDT]               DATETIME2 (7)  NOT NULL,
    [DurationSeconds]        VARCHAR (50)   NOT NULL,
    [AffectedRecordCount]    INT            NOT NULL
);


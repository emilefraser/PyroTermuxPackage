﻿CREATE TABLE [REPREG].[ReportType] (
    [ReportTypeID]          INT           IDENTITY (1, 1) NOT NULL,
    [ReportTypeDescription] VARCHAR (100) NOT NULL,
    [CreatedBy]             VARCHAR (100) NOT NULL,
    [CreatedDT]             DATETIME2 (7) NOT NULL,
    [ModifiedBy]            VARCHAR (100) NULL,
    [ModifedDT]             DATETIME2 (7) NULL,
    [IsActive]              BIT           NULL
);


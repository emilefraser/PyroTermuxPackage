﻿CREATE TABLE [FS].[Logging_Header] (
    [LogID]         INT           IDENTITY (1, 1) NOT NULL,
    [LogTypeID]     INT           NOT NULL,
    [StartDT]       DATETIME2 (7) NULL,
    [FinishDT]      DATETIME2 (7) NULL,
    [Duration]      INT           NULL,
    [Status]        VARCHAR (50)  NULL,
    [Error Message] VARCHAR (500) NULL,
    [Description]   VARCHAR (500) NULL,
    CONSTRAINT [PK_Logging_Header] PRIMARY KEY CLUSTERED ([LogID] ASC)
);


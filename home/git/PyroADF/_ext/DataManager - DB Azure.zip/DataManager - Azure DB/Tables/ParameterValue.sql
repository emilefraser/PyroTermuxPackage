﻿CREATE TABLE [DMOD].[ParameterValue] (
    [ParameterValueID] INT             IDENTITY (1, 1) NOT NULL,
    [ParameterID]      INT             NOT NULL,
    [ValueDecimal]     DECIMAL (28, 4) NULL,
    [ValueInt]         INT             NULL,
    [ValueDate]        DATETIME2 (0)   NULL,
    [ValueVarchar]     VARCHAR (100)   NULL,
    [CreatedDT]        DATETIME2 (7)   NOT NULL,
    [ClosedDT]         DATETIME2 (7)   NULL,
    [IsActive]         BIT             NOT NULL,
    CONSTRAINT [PK_ParameterValue] PRIMARY KEY CLUSTERED ([ParameterValueID] ASC)
);


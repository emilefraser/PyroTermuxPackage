﻿CREATE TABLE [MASTER].[SortOrderGrouping] (
    [SortOrderGroupingID] INT           IDENTITY (1, 1) NOT NULL,
    [SortOrderGroupName]  VARCHAR (100) NOT NULL,
    [SortOrderGroupCode]  VARCHAR (50)  NULL,
    [FieldID]             INT           NULL,
    [CreatedDT]           DATETIME2 (7) NULL,
    [UpdatedDT]           DATETIME2 (7) NULL,
    [IsActive]            BIT           NULL,
    [DataDomainID]        INT           NULL,
    CONSTRAINT [PK_SortOrderGrouping] PRIMARY KEY CLUSTERED ([SortOrderGroupingID] ASC)
);


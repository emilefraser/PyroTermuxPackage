﻿CREATE TABLE [DC].[ReportElementField] (
    [ReportElementFieldID] VARCHAR (20)  NOT NULL,
    [ReportElementID]      INT           NOT NULL,
    [FieldID]              INT           NOT NULL,
    [IsActive]             BIT           NOT NULL,
    [CreatedDT]            DATETIME2 (7) NULL
);


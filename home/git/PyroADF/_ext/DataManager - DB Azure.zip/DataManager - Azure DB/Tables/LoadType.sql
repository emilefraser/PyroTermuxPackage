﻿CREATE TABLE [ETL].[LoadType] (
    [LoadTypeID]                  INT            IDENTITY (1, 1) NOT NULL,
    [LoadTypeCode]                VARCHAR (50)   NULL,
    [LoadTypeDescription]         VARCHAR (500)  NULL,
    [LoadTypeName]                VARCHAR (50)   NULL,
    [ParameterisedTemplateScript] VARCHAR (MAX)  NULL,
    [StaticTemplateScript]        VARCHAR (MAX)  NULL,
    [LoadScriptVersionNo]         DECIMAL (9, 2) NULL,
    [CreatedDT]                   DATETIME2 (7)  NULL,
    [UpdatedDT]                   DATETIME2 (7)  NULL,
    [IsActive]                    BIT            NULL
);


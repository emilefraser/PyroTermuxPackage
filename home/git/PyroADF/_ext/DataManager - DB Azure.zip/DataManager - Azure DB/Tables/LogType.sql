﻿CREATE TABLE [FS].[LogType] (
    [LogTypeID] INT          IDENTITY (1, 1) NOT NULL,
    [LogType]   VARCHAR (50) NULL,
    [LogName]   VARCHAR (50) NULL,
    CONSTRAINT [PK_LogType] PRIMARY KEY CLUSTERED ([LogTypeID] ASC)
);


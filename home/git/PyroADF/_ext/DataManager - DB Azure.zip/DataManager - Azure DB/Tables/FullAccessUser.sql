﻿CREATE TABLE [ACCESS].[FullAccessUser] (
    [FullAccessUserID]     INT           IDENTITY (1, 1) NOT NULL,
    [DomainAccountOrGroup] VARCHAR (200) NOT NULL,
    [IsFullAccessUser]     BIT           NOT NULL,
    [IsDeveloper]          BIT           NOT NULL,
    [CreatedDT]            DATETIME2 (7) NULL,
    [UpdatedDT]            DATETIME2 (7) NULL,
    [IsActive]             BIT           NOT NULL,
    CONSTRAINT [PK_FullAccessUser] PRIMARY KEY CLUSTERED ([FullAccessUserID] ASC)
);


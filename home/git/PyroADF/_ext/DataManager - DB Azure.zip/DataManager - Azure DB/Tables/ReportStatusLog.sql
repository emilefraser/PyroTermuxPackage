﻿CREATE TABLE [REPREG].[ReportStatusLog] (
    [ReportStatusID]     INT           IDENTITY (1, 1) NOT NULL,
    [ReportID]           INT           NULL,
    [ReportStatusTypeID] INT           NULL,
    [ErrorParagraph]     VARCHAR (500) NULL,
    [LogDT]              DATETIME2 (7) NULL
);


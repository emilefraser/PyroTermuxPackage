﻿CREATE TABLE [SOURCELINK].[Employee] (
    [EmployeeID]               INT           IDENTITY (1, 1) NOT NULL,
    [EmployeeCode]             VARCHAR (50)  NOT NULL,
    [FirstName]                VARCHAR (100) NULL,
    [Surname]                  VARCHAR (100) NULL,
    [IsActive]                 BIT           NOT NULL,
    [CreatedDT]                DATETIME2 (7) NULL,
    [UpdatedDT]                DATETIME2 (7) NULL,
    [Department]               VARCHAR (100) NULL,
    [ReportingHierarchyItemID] INT           NULL,
    CONSTRAINT [PK_Employee] PRIMARY KEY CLUSTERED ([EmployeeID] ASC)
);


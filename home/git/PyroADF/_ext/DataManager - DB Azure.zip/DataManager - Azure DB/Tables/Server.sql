﻿CREATE TABLE [DC].[Server] (
    [ServerID]           INT           IDENTITY (1, 1) NOT NULL,
    [ServerName]         VARCHAR (100) NOT NULL,
    [ServerLocation]     VARCHAR (100) NULL,
    [PublicIP]           VARCHAR (100) NULL,
    [LocalIP]            VARCHAR (100) NULL,
    [UserID]             INT           NULL,
    [AccessInstructions] VARCHAR (500) NULL,
    [CreatedDT]          DATETIME2 (7) NULL,
    [UpdatedDT]          DATETIME2 (7) NULL,
    [IsActive]           BIT           CONSTRAINT [DF_Server_IsActive] DEFAULT ((1)) NULL,
    [ServerTypeID]       INT           NULL,
    CONSTRAINT [PK_Server] PRIMARY KEY CLUSTERED ([ServerID] ASC)
);


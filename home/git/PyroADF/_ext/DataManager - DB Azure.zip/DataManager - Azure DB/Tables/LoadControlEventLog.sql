﻿CREATE TABLE [ETL].[LoadControlEventLog] (
    [LoadControlID]    INT            NOT NULL,
    [EventDT]          DATETIME2 (7)  NOT NULL,
    [EventDescription] VARCHAR (50)   NOT NULL,
    [ErrorMessage]     VARCHAR (4000) NULL
);


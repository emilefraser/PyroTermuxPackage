﻿CREATE TABLE [DC].[FieldTypeField_FS] (
    [FieldTypeFieldID] INT           IDENTITY (1, 1) NOT NULL,
    [FieldID]          INT           NULL,
    [FieldTypeID]      INT           NULL,
    [CreatedDT]        DATETIME2 (7) NOT NULL,
    [ModifiedDT]       DATETIME2 (7) NULL,
    [IsActive]         BIT           NOT NULL
);


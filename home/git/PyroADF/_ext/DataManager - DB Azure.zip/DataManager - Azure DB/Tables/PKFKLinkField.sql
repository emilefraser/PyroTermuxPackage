﻿CREATE TABLE [DMOD].[PKFKLinkField] (
    [PKFKLinkFieldID]   INT           IDENTITY (1, 1) NOT NULL,
    [PKFKLinkID]        INT           NOT NULL,
    [PrimaryKeyFieldID] INT           NOT NULL,
    [ForeignKeyFieldID] INT           NOT NULL,
    [CreatedDT]         DATETIME2 (7) NULL,
    [UpdatedDT]         DATETIME2 (7) NULL,
    [IsActive]          BIT           NULL,
    CONSTRAINT [PK_LinkPKFKForeignKeyField_Working] PRIMARY KEY CLUSTERED ([PKFKLinkFieldID] ASC)
);


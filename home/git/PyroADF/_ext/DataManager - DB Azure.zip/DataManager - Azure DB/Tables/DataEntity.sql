﻿CREATE TABLE [DC].[DataEntity] (
    [DataEntityID]         INT             IDENTITY (1, 1) NOT NULL,
    [DataEntityName]       VARCHAR (100)   NOT NULL,
    [FriendlyName]         VARCHAR (100)   NULL,
    [Description]          VARCHAR (100)   NULL,
    [DataEntityTypeID]     INT             NULL,
    [RowsCount]            BIGINT          NULL,
    [ColumnsCount]         VARCHAR (50)    NULL,
    [Size]                 VARCHAR (50)    NULL,
    [DataQualityScore2]    VARCHAR (10)    NULL,
    [DataQualityScore]     DECIMAL (18, 3) NULL,
    [DESourceCredentialID] INT             NULL,
    [DESourceTypeID]       INT             NULL,
    [DEFileFormatID]       INT             NULL,
    [SchemaID]             INT             NULL,
    [DBObjectID]           INT             NULL,
    [CreatedDT]            DATETIME2 (7)   NULL,
    [UpdatedDT]            DATETIME2 (7)   NULL,
    [IsActive]             BIT             NULL,
    [LastSeenDT]           DATETIME2 (7)   NULL,
    CONSTRAINT [PK_DataEntity] PRIMARY KEY CLUSTERED ([DataEntityID] ASC)
);


GO
CREATE NONCLUSTERED INDEX [nc_idx_DataEntity_1]
    ON [DC].[DataEntity]([DataEntityName] ASC)
    INCLUDE([SchemaID]);


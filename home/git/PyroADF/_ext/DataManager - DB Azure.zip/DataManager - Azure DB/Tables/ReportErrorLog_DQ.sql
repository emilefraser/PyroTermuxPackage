﻿CREATE TABLE [REPREG].[ReportErrorLog_DQ] (
    [ReportErrorLogID]   INT           IDENTITY (1, 1) NOT NULL,
    [ReportID]           INT           NOT NULL,
    [DataCatalogFieldID] INT           NULL,
    [BusinessKeyID]      INT           NULL,
    [ErrorTypeID]        INT           NULL,
    [ErrorDescription]   VARCHAR (500) NULL,
    [TransactionPeriod]  VARCHAR (7)   NULL
);


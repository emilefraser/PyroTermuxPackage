﻿CREATE TABLE [REPREG].[ReportPack] (
    [ReportPackID]          INT           IDENTITY (1, 1) NOT NULL,
    [ReportPackTitle]       VARCHAR (100) NOT NULL,
    [ReportPackDescription] VARCHAR (200) NOT NULL,
    [ReportTechnologyID]    INT           NULL,
    [CreatedDT]             DATETIME2 (7) NULL,
    [ModifedDT]             DATETIME2 (7) NULL,
    [IsActive]              BIT           NULL
);


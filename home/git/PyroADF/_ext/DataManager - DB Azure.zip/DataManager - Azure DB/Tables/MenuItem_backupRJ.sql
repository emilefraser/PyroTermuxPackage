﻿CREATE TABLE [APP].[MenuItem_backupRJ] (
    [MenuItemID]       INT           NOT NULL,
    [MenuItemName]     VARCHAR (50)  NOT NULL,
    [MenuItemNavTo]    VARCHAR (200) NULL,
    [MenuItemParentID] INT           NULL,
    [IsHeaderItem]     BIT           NOT NULL,
    [SortOrder]        INT           NULL,
    CONSTRAINT [PK_MenuItem] PRIMARY KEY CLUSTERED ([MenuItemID] ASC)
);


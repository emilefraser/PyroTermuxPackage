﻿CREATE TABLE [MASTER].[ReportingHierarchyItem1] (
    [ReportingHierarchyItemID]    INT           NOT NULL,
    [ItemCode]                    VARCHAR (50)  NOT NULL,
    [ItemName]                    VARCHAR (100) NOT NULL,
    [ReportingHierarchyTypeID]    INT           NULL,
    [ParentItemID]                INT           NULL,
    [CompanyID]                   INT           NULL,
    [ReportingHierarchySortOrder] INT           NULL,
    [CreatedDT]                   DATETIME2 (7) NULL,
    [UpdatedDT]                   DATETIME2 (7) NULL,
    [IsActive]                    BIT           NULL,
    CONSTRAINT [PK_ReportingHierarchyItem1] PRIMARY KEY CLUSTERED ([ReportingHierarchyItemID] ASC)
);


﻿CREATE TABLE [MASTER].[SortOrderValue] (
    [SortOrderValueID]    INT           IDENTITY (1, 1) NOT NULL,
    [SortOrderGroupingID] INT           NOT NULL,
    [SortOrder]           INT           NOT NULL,
    [DataValue]           VARCHAR (100) NULL,
    [CreatedDT]           DATETIME2 (7) NULL,
    [UpdatedDT]           DATETIME2 (7) NULL,
    [IsActive]            BIT           NULL,
    CONSTRAINT [PK_SortOrderValue] PRIMARY KEY CLUSTERED ([SortOrderValueID] ASC)
);


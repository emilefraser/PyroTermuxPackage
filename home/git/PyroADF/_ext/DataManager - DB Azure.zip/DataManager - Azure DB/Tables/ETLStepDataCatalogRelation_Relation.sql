﻿CREATE TABLE [ETL].[ETLStepDataCatalogRelation_Relation] (
    [ETLStepDataCatalogRelationID] INT IDENTITY (1, 1) NOT NULL,
    [ETLStepID]                    INT NOT NULL,
    [DataCatalogRelationID]        INT NOT NULL,
    CONSTRAINT [PK_ETLStepDataCatalogRelation_Relation] PRIMARY KEY CLUSTERED ([ETLStepDataCatalogRelationID] ASC)
);


﻿CREATE TABLE [APP].[ApplicationGeneralSettings] (
    [AppGenSettingID] INT           IDENTITY (1, 1) NOT NULL,
    [ItemName]        VARCHAR (50)  NULL,
    [IsHeaderItem]    BIT           NULL,
    [CreatedDT]       DATETIME2 (7) NULL,
    [UpdatedDT]       DATETIME2 (7) NULL,
    [IsActive]        BIT           NULL,
    [SortOrder]       INT           NULL,
    CONSTRAINT [PK_ApplicationGeneralSettings] PRIMARY KEY CLUSTERED ([AppGenSettingID] ASC)
);


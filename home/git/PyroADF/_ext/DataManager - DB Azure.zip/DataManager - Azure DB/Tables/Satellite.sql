﻿CREATE TABLE [DMOD].[Satellite] (
    [SatelliteID]                 INT           IDENTITY (1, 1) NOT NULL,
    [HubID]                       INT           NOT NULL,
    [TransactionLinkID]           INT           NULL,
    [SatelliteDataEnityID]        INT           NULL,
    [SatelliteName]               VARCHAR (150) NULL,
    [SatelliteDataVelocityTypeID] INT           NOT NULL,
    [IsDetailTransactionLinkSat]  BIT           NULL,
    [CreatedDT]                   DATETIME2 (7) NULL,
    [UpdatedDT]                   DATETIME2 (7) NULL,
    [IsActive]                    BIT           NULL,
    CONSTRAINT [PK_Satellite] PRIMARY KEY CLUSTERED ([SatelliteID] ASC)
);


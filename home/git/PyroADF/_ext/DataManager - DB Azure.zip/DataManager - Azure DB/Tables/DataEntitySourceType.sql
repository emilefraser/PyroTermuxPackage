﻿CREATE TABLE [DC].[DataEntitySourceType] (
    [DESourceTypeID]          INT            IDENTITY (1, 1) NOT NULL,
    [DESourceTypeCode]        NVARCHAR (10)  NULL,
    [DESourceTypeDescription] NVARCHAR (250) NULL,
    [IsFileDataSource]        BIT            NULL,
    CONSTRAINT [PK_DataEntitySourceType] PRIMARY KEY CLUSTERED ([DESourceTypeID] ASC)
);


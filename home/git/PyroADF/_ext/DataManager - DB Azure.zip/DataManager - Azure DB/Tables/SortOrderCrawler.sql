﻿CREATE TABLE [APP].[SortOrderCrawler] (
    [SortOrderCrawlID] INT IDENTITY (1, 1) NOT NULL,
    [FieldID]          INT NOT NULL
);


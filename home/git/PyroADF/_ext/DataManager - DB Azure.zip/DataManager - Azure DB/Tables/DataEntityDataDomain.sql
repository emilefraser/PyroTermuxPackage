﻿CREATE TABLE [DC].[DataEntityDataDomain] (
    [DataEntityDataDomainID] INT           IDENTITY (1, 1) NOT NULL,
    [DataEntityID]           INT           NOT NULL,
    [DataDomainID]           INT           NOT NULL,
    [CreatedDT]              DATETIME2 (7) NULL,
    [UpdatedDT]              DATETIME2 (7) NULL,
    [IsActive]               BIT           NULL
);


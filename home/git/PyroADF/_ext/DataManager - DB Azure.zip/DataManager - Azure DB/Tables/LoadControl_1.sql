﻿CREATE TABLE [ETL].[LoadControl] (
    [LoadControlID]                INT            NOT NULL,
    [LoadConfigID]                 INT            NOT NULL,
    [CreatedDT]                    DATETIME2 (7)  NOT NULL,
    [QueuedForProcessingDT]        DATETIME2 (7)  NULL,
    [ProcessingStartDT]            DATETIME2 (7)  NULL,
    [ProcessingFinishedDT]         DATETIME2 (7)  NULL,
    [LastProcessingPrimaryKey]     VARCHAR (50)   NULL,
    [LastProcessingTransactionNo]  VARCHAR (50)   NULL,
    [NewRecordDDL]                 VARCHAR (MAX)  NULL,
    [UpdatedRecordDDL]             VARCHAR (MAX)  NULL,
    [CreateTempTableDDL]           VARCHAR (MAX)  NULL,
    [TempTableName]                VARCHAR (100)  NULL,
    [UpdateStatementDDL]           VARCHAR (MAX)  NULL,
    [GetLastProcessingKeyValueDDL] VARCHAR (1000) NULL,
    [DeleteStatementDDL]           VARCHAR (MAX)  NULL,
    [IsLastRunFailed]              BIT            NULL,
    [ProcessingState]              VARCHAR (20)   NULL,
    [NextScheduledRunTime]         DATETIME2 (7)  NULL,
    CONSTRAINT [PK__LoadCont__C1BBA01C14C95DD3] PRIMARY KEY CLUSTERED ([LoadControlID] ASC)
);


﻿CREATE TABLE [DC].[ObjectType] (
    [ObjectTypeID]          INT           IDENTITY (1, 1) NOT NULL,
    [ObjectTypeDescription] VARCHAR (100) NOT NULL,
    [IsActive]              BIT           CONSTRAINT [DF_ObjectType_IsActive] DEFAULT ((1)) NULL,
    PRIMARY KEY CLUSTERED ([ObjectTypeID] ASC)
);


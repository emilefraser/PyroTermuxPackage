﻿CREATE TABLE [DMOD].[SameAsLink] (
    [SameAsLinkID]   INT           IDENTITY (1, 1) NOT NULL,
    [SameAsLinkName] VARCHAR (150) NOT NULL,
    [HubID]          INT           NOT NULL,
    [IsActive]       BIT           NULL,
    CONSTRAINT [PK__SameAsLi__3C79D461795C417B] PRIMARY KEY CLUSTERED ([SameAsLinkID] ASC)
);


﻿CREATE TABLE [SCHEDULER].[SchedulerHeader] (
    [SchedulerHeaderID]                INT           IDENTITY (1, 1) NOT NULL,
    [ETLLoadConfigID]                  INT           NULL,
    [ScheduleExecutionIntervalMinutes] INT           NULL,
    [ScheduleExecutionTime]            VARCHAR (5)   NULL,
    [IsActive]                         BIT           NULL,
    [CreatedDT]                        DATETIME2 (7) NULL,
    [UpdatedDT]                        DATETIME2 (7) NULL,
    CONSTRAINT [PK_SchedulerHeader] PRIMARY KEY CLUSTERED ([SchedulerHeaderID] ASC)
);


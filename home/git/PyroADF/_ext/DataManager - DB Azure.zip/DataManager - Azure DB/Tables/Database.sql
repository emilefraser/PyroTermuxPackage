﻿CREATE TABLE [DC].[Database] (
    [DatabaseID]                INT             IDENTITY (1, 1) NOT NULL,
    [DatabaseName]              VARCHAR (100)   NOT NULL,
    [AccessInstructions]        VARCHAR (500)   NULL,
    [Size]                      DECIMAL (19, 6) NULL,
    [DatabaseInstanceID]        INT             NULL,
    [SystemID]                  INT             NULL,
    [ExternalDatasourceName]    VARCHAR (100)   NULL,
    [DatabasePurposeID]         INT             NULL,
    [DBDatabaseID]              INT             NULL,
    [DatabaseEnvironmentTypeID] INT             NULL,
    [CreatedDT]                 DATETIME2 (7)   NULL,
    [UpdatedDT]                 DATETIME2 (7)   NULL,
    [IsActive]                  BIT             CONSTRAINT [DF_Database_IsActive] DEFAULT ((1)) NULL,
    [LastSeenDT]                DATETIME2 (7)   NULL,
    CONSTRAINT [PK_Database] PRIMARY KEY CLUSTERED ([DatabaseID] ASC)
);


﻿CREATE TABLE [REPREG].[ReportRegister] (
    [Name]             VARCHAR (50)  NULL,
    [Description]      VARCHAR (MAX) NULL,
    [ReportRegisterID] INT           IDENTITY (1, 1) NOT NULL
);


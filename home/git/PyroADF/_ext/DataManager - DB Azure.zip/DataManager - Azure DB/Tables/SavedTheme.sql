﻿CREATE TABLE [APP].[SavedTheme] (
    [UserEmail]     VARCHAR (255) NOT NULL,
    [UserName]      VARCHAR (255) NULL,
    [SelectedTheme] VARCHAR (255) NULL,
    PRIMARY KEY CLUSTERED ([UserEmail] ASC)
);


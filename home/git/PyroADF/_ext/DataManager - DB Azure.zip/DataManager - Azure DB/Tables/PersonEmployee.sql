﻿CREATE TABLE [GOV].[PersonEmployee] (
    [PersonEmployeeID]   INT           IDENTITY (1, 1) NOT NULL,
    [PersonID]           INT           NOT NULL,
    [EmployeeNo]         VARCHAR (20)  NOT NULL,
    [CreatedDT]          DATETIME2 (7) NULL,
    [UpdatedDT]          DATETIME2 (7) NULL,
    [IsActive]           BIT           NULL,
    [PersonEmployeeCode] VARCHAR (50)  NULL,
    CONSTRAINT [PK_Employee_1] PRIMARY KEY CLUSTERED ([PersonEmployeeID] ASC)
);


﻿CREATE TABLE [DC].[HistoryTracking_Size] (
    [HistoryID]    INT             IDENTITY (1, 1) NOT NULL,
    [HistoryDT]    DATETIME2 (7)   NOT NULL,
    [ObjectID]     INT             NOT NULL,
    [ObjectTypeID] INT             NOT NULL,
    [Size_MB]      DECIMAL (18, 3) NULL,
    CONSTRAINT [PK__HistoryT__4D7B4ADD4A84B87E] PRIMARY KEY CLUSTERED ([HistoryID] ASC)
);


﻿CREATE TABLE [APP].[ModuleAction] (
    [ModuleActionID]    INT           IDENTITY (1, 1) NOT NULL,
    [ActionCode]        VARCHAR (50)  NOT NULL,
    [ActionDescription] VARCHAR (200) NULL,
    [ModuleID]          INT           NOT NULL,
    [CreatedDT]         DATETIME2 (7) NULL,
    [UpdatedDT]         DATETIME2 (7) NULL,
    [IsActive]          BIT           NULL,
    CONSTRAINT [PK__ModuleAc__135C314D72723D22] PRIMARY KEY CLUSTERED ([ModuleActionID] ASC)
);


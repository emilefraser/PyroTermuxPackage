﻿CREATE TABLE [DMOD].[LinkTransactionLinkToHub] (
    [LinkTransactionLinkToHubID] INT IDENTITY (1, 1) NOT NULL,
    [TransactionLinkID]          INT NOT NULL,
    [HubID]                      INT NOT NULL,
    CONSTRAINT [PK_LinkTransactionLink] PRIMARY KEY CLUSTERED ([LinkTransactionLinkToHubID] ASC)
);


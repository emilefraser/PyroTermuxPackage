﻿CREATE TABLE [GOV].[Role] (
    [RoleID]          INT           IDENTITY (1, 1) NOT NULL,
    [RoleCode]        VARCHAR (80)  NULL,
    [RoleDescription] VARCHAR (200) NULL,
    [CreatedDT]       DATETIME2 (7) NULL,
    [UpdatedDT]       DATETIME2 (7) NULL,
    [IsActive]        BIT           NULL,
    PRIMARY KEY CLUSTERED ([RoleID] ASC)
);


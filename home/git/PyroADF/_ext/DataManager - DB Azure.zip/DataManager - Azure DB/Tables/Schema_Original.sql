﻿CREATE TABLE [DC].[Schema_Original] (
    [SchemaID]   INT           IDENTITY (1, 1) NOT NULL,
    [SchemaName] VARCHAR (100) NOT NULL,
    [DatabaseID] INT           NOT NULL,
    [DBSchemaID] INT           NULL,
    [CreatedDT]  DATETIME2 (7) NULL,
    [ModifiedDT] DATETIME2 (7) NULL,
    [IsActive]   BIT           CONSTRAINT [DF_Schema_IsActive_Original] DEFAULT ((1)) NULL,
    CONSTRAINT [PK_Schema_Original] PRIMARY KEY CLUSTERED ([SchemaID] ASC)
);


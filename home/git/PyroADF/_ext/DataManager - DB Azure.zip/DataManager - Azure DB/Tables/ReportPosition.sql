﻿CREATE TABLE [ACCESS].[ReportPosition] (
    [ReportPositionID]        INT           IDENTITY (1, 1) NOT NULL,
    [EmployeePositionID]      INT           NULL,
    [NonEmployeeReportUserID] INT           NULL,
    [CreatedDT]               DATETIME2 (7) NULL,
    CONSTRAINT [PK_ReportPosition] PRIMARY KEY CLUSTERED ([ReportPositionID] ASC)
);


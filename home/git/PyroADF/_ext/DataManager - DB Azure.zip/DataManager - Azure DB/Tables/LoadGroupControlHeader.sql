﻿CREATE TABLE [ETL].[LoadGroupControlHeader] (
    [LoadGroupControlID] INT           IDENTITY (1, 1) NOT NULL,
    [LoadDescription]    VARCHAR (250) NULL,
    [LoadStatus]         VARCHAR (50)  NULL,
    [LoadScheduleID]     INT           NULL,
    [ActiveStepID]       INT           NULL
);


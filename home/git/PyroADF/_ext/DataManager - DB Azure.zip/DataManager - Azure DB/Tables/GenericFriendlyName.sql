﻿CREATE TABLE [TYPE].[GenericFriendlyName] (
    [FieldName]    VARCHAR (100) NULL,
    [FriendlyName] VARCHAR (100) NULL
);


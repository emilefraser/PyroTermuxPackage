﻿CREATE TABLE [FS].[Logging_Steps] (
    [LogStepID] INT            IDENTITY (1, 1) NOT NULL,
    [LogID]     INT            NULL,
    [StepNo]    INT            NULL,
    [Platform]  VARCHAR (500)  NULL,
    [Action]    VARCHAR (5000) NULL,
    [StartDT]   DATETIME2 (7)  NULL,
    [FinishDT]  DATETIME2 (7)  NULL,
    [Duration]  INT            NULL,
    [IsError]   BIT            NULL,
    CONSTRAINT [PK_Logging_Steps] PRIMARY KEY CLUSTERED ([LogStepID] ASC)
);


﻿-- =============================================
-- Author:      Emile Fraser
-- Create Date: 2019-08-10
-- Description: Get Load Type Name from LoadTypeID
-- =============================================

CREATE FUNCTION [DMOD].[udf_get_LoadTypeName_LoadTypeID]
(
    -- Add the parameters for the function here
    @LoadTypeID INT
)
RETURNS varchar(50)
AS
BEGIN
    -- Declare the return variable here
    DECLARE @LoadTypeName varchar(50)

	SET @LoadTypeName = 
	(
		SELECT
			LoadTypeName
		FROM 
			DMOD.LoadType
		WHERE
			LoadTypeID = @LoadTypeID
	)

    -- Return the result of the function
    RETURN @LoadTypeName
END

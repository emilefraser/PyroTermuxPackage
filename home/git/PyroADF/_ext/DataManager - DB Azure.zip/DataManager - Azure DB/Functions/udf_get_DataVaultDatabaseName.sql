﻿
/*
-- Author:      Emile Fraser
-- Create Date: 6 June 2019

*/

-- Sample Execution Statement
--	Select [DMOD].[udf_get_DataVaultDatabaseName](19)

CREATE FUNCTION [DMOD].[udf_get_DataVaultDatabaseName](
	@LoadConfigID INT
)
RETURNS VARCHAR(MAX)
AS
BEGIN


	--DECLARE @LoadConfigID INT = 23
	DECLARE @DataVaultDatabaseName VARCHAR(MAX)

	DECLARE @SourceDataEntityID INT
	DECLARE @TargetDataEntityID INT
	DECLARE @SourceDatabaseID INT
	DECLARE @TargetDatabaseID INT
	DECLARE @SourceDatabasePurpose VARCHAR(MAX)
	DECLARE @TargetDatabasePurpose VARCHAR(MAX)
	
	--SET @SourceDataEntityID = (SELECT SourceDataEntityID FROM DMOD.LoadConfig WHERE LoadConfigID =92  @LoadConfigID)
	--SET @TargetDataEntityID = (SELECT TargetDataEntityID FROM DMOD.LoadConfig WHERE LoadConfigID =92  @LoadConfigID)
	----SELECT @SourceDataEntityID
	--SET @SourceDatabaseID = (SELECT [DC].[udf_get_DatabaseID_from_DataEntityID](46995) @SourceDataEntityID))
	--SET @TargetDatabaseID = (SELECT [DC].[udf_get_DatabaseID_from_DataEntityID](49204) @TargetDataEntityID))
	----SELECT @SourceDatabaseID
	--SET @SourceDatabasePurpose = (SELECT DC.udf_get_DatabasePurposeCode(4) @SourceDatabaseID))
	--SET @TargetDatabasePurpose = (SELECT DC.udf_get_DatabasePurposeCode(3) @TargetDatabaseID))
	----SELECT @SourceDatabasePurpose
	--SELECT @TargetDatabasePurpose
	SET @DataVaultDatabaseName = 
	(
		select Target_DatabaseName FROM DMOD.vw_LoadConfig
		WHERE LoadConfigID =  @LoadConfigID
	)


	IF(CHARINDEX('DataVault', @DataVaultDatabaseName)<>0)
	BEGIN
			IF(CHARINDEX('DEV_', @DataVaultDatabaseName)>0)
			BEGIN

					SET @DataVaultDatabaseName = 'DEV_DataVault'
			END
			else IF(CHARINDEX('UAT_', @DataVaultDatabaseName)>0)
			BEGIN

					SET @DataVaultDatabaseName = 'UAT_DataVault'
			END
			else IF(CHARINDEX('PROD_', @DataVaultDatabaseName)>0)
			BEGIN

					SET @DataVaultDatabaseName = 'DataVault'
			END
	END
	ELSE
	BEGIN
		SET @DataVaultDatabaseName = 'DataVault'
	END

/*
	IF(@SourceDatabasePurpose = 'DataVault')
	BEGIN
		SET @DataVaultDatabaseName = 
		(
			SELECT db.DatabaseName FROM DC.[Database] AS db WHERE db.DatabaseID = @SourceDatabaseID
		)
	END
	ELSE IF(@TargetDatabasePurpose = 'DataVault')
	BEGIN
	SET @DataVaultDatabaseName = 
		(
			SELECT db.DatabaseName FROM DC.[Database] AS db WHERE db.DatabaseID = @TargetDatabaseID
		)
	END
	ELSE
	BEGIN
		--PRINT 'NNOOOOO'
		DECLARE @Environment VARCHAR(MAX)

		SET @DataVaultDatabaseName = 
		(
				SELECT
					db.DatabaseName
				FROM 
					DC.[Database] AS db
				INNER JOIN 
					DC.[DatabasePurpose] AS dp
					ON db.DatabasePurposeID = dp.DatabasePurposeID
				WHERE 
					dp.DatabasePurposeCode = 'DataVault'
				AND
					db.DatabaseName = @Environment + IIF(@Environment IS NULL, '', '_')  + dp.DatabasePurposeCode
		)
	END

	IF @DataVaultDatabaseName IS NULL 
			SET @DataVaultDatabaseName = 'DataVault'
				SELECT @DataVaultDatabaseName
*/


	RETURN QUOTENAME(@DataVaultDatabaseName)

END


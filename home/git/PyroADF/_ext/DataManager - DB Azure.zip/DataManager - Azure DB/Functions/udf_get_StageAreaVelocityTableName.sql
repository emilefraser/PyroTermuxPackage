﻿
/*
-- Author:      Emile Fraser
-- Create Date: 6 June 2019

-- Sample Execution Statement
--	Select [DMOD].[udf_get_StageAreaVelocityTableName](1)
*/

CREATE   FUNCTION [DMOD].[udf_get_StageAreaVelocityTableName](
	@LoadConfigID INT
)
RETURNS VARCHAR(MAX)
AS
BEGIN
	DECLARE @StageAreaVelocityTableName VARCHAR(MAX)
	DECLARE @LoadEntity AS VARCHAR(100)
	DECLARE @Satellite_Velocities TABLE (Target_DataEntityName VARCHAR(100), Target_SatelliteVelocity VARCHAR(3), Target_SatelliteVelocityRanking INT)
	DECLARE @MaxVelocity AS INT 

	SET @LoadEntity = 
	(
		SELECT 
			lc.LoadTypeEntity
		FROM 
			[DMOD].[vw_LoadConfig] AS lc
		WHERE 
			LoadConfigID = @LoadConfigID
	)

	-- If we are loading KEYS, find the Highest Frequency Satellite
	IF (@LoadEntity = 'KEYS')
	BEGIN
		INSERT INTO @Satellite_Velocities(Target_DataEntityName, Target_SatelliteVelocity, Target_SatelliteVelocityRanking)
		SELECT 
			lcv.Target_DataEntityName
		,	SUBSTRING(lcv.Target_DataEntityName, LEN(lcv.Target_DataEntityName) - 2, 3) AS Target_SatelliteVelocity
		,	sdvt.SatelliteDataVelocityTypeID AS Target_SatelliteVelocityRanking
		FROM 
			[DMOD].[vw_LoadConfig] AS lck
		INNER JOIN 
			[DMOD].[vw_LoadConfig] AS lcv
		ON 
			lck.Source_DataEntityID = lcv.Source_DataEntityID
		AND
			REPLACE(lck.LoadTypeEntity, 'KEYS', 'VELOCITY') = lcv.LoadTypeEntity
		INNER JOIN 
			DMOD.SatelliteDataVelocityType AS sdvt
		ON 
			sdvt.SatelliteDataVelocityTypeCode = SUBSTRING(lcv.Target_DataEntityName, LEN(lcv.Target_DataEntityName) - 2, 3)
		WHERE 
			lck.LoadConfigID = @LoadConfigID
		AND
			lck.LoadTypeEntity = 'KEYS'
		AND
			lcv.LoadTypeEntity = 'VELOCITY'
		AND
			lck.IsActive = 1
		AND
			lcv.IsActive = 1
	END

	-- Only insert the Target Satellites own velocity in TVP
	ELSE IF (@LoadEntity = 'VELOCITY')
	BEGIN
	
	INSERT INTO @Satellite_Velocities(Target_DataEntityName, Target_SatelliteVelocity, Target_SatelliteVelocityRanking)
		SELECT 
			lcv.Target_DataEntityName
		,	SUBSTRING(lcv.Target_DataEntityName, LEN(lcv.Target_DataEntityName) - 2, 3) AS Target_SatelliteVelocity
		,	sdvt.SatelliteDataVelocityTypeID AS Target_SatelliteVelocityRanking
		FROM 
			[DMOD].[vw_LoadConfig] AS lcv
		INNER JOIN 
			DMOD.SatelliteDataVelocityType AS sdvt
		ON 
			sdvt.SatelliteDataVelocityTypeCode = SUBSTRING(lcv.Target_DataEntityName, LEN(lcv.Target_DataEntityName) - 2, 3)
		WHERE
			lcv.LoadConfigID = @LoadConfigID
	END
	ELSE
	BEGIN
		INSERT INTO @Satellite_Velocities(Target_DataEntityName, Target_SatelliteVelocity, Target_SatelliteVelocityRanking)
		SELECT 'TODO: NonStage WHEN COMBINING FUNCTIONS', 'UNK', 0
	END

	-- GET Max Velocity of the TVP
	SET @MaxVelocity = 
	(
		SELECT MAX(Target_SatelliteVelocityRanking) FROM @Satellite_Velocities
	)
	
	-- GET the Finnal table velocity name
	SET  @StageAreaVelocityTableName = 
	 ( 
		SELECT 
			QUOTENAME(sv.Target_DataEntityName)
		FROM 
			@Satellite_Velocities AS sv
		WHERE 
			sv.Target_SatelliteVelocityRanking = @MaxVelocity
	)

	RETURN @StageAreaVelocityTableName;

END;

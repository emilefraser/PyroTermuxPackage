﻿
-- =============================================
-- Author:      Emile Fraser
-- Create Date: 10 June 2019
-- Description: Generate a JOIN LIST for a select statement from the ODS area table with a standard alias prefix

--!~ Hub & Link Hash Key Columns for ODS Select
/*
			--!~ Hub & Link table joins for ODS Select
			 LEFT JOIN [ODS_XT900].[dbo].[TERMINAL] AS StandardAlias2
				 ON StandardAlias2.[TERM_CODEID] = StandardAlias1.[TERM_CODEID]
			 LEFT JOIN [ODS_XT900].[dbo].[TAG] AS StandardAlias3
				 ON StandardAlias3.[TAG_CODE] = StandardAlias1.[TAG_CODE]
			 LEFT JOIN [ODS_XT900].[dbo].[MASTER] AS StandardAlias4
				 ON StandardAlias4.[MST_SQ] = StandardAlias1.[MST_SQ]
			 LEFT JOIN [ODS_XT900].[dbo].[EVENTTYPE] AS StandardAlias5
				 ON StandardAlias5.[ET_CODEID] = StandardAlias1.[ET_CODEID]
			 LEFT JOIN [ODS_XT900].[dbo].[DIRECTION] AS StandardAlias6
				 ON StandardAlias6.[DIR_CODEID] = StandardAlias1.[DIR_CODEID]
			-- End of Hub & Link table joins for ODS Select ~!

	SELECT [DMOD].[udf_get_JoinList_WithAlias_ODS](28)
	*/	
CREATE FUNCTION [DMOD].[udf_get_JoinList_WithAlias_ODS]
(
	@LoadConfigID INT
)  
RETURNS VARCHAR(MAX)
AS
BEGIN

	--DECLARE @LoadConfigID INT = 28
	
   -- Field List Helpers
	DECLARE @FieldList VARCHAR(MAX) = ''
	DECLARE @Seperator VARCHAR(1) = '.'

	-- Stage Fields
	DECLARE @Stage_DataEntityID INT = (SELECT Target_DataEntityID FROM DMOD.vw_LoadConfig WHERE LoadConfigID = @LoadConfigID)
	--SELECT @Stage_DataEntityID -- 9911

	-- ODS Fields
	DECLARE @ODS_DataEntityID INT = (SELECT Source_DataEntityID FROM DMOD.vw_LoadConfig WHERE LoadConfigID = @LoadConfigID)
	--SELECT @ODS_DataEntityID -- 35

	-- Source Fields
	DECLARE @Source_DataEntityID INT = (SELECT DC.udf_get_SourceSystem_DataEntityID(@Stage_DataEntityID))
	--SELECT @Source_DataEntityID -- 631
	
	DECLARE @Source_DatabaseID INT = (SELECT DC.udf_get_DatabaseID_from_DataEntityID(@ODS_DataEntityID))
	DECLARE @Source_DatabaseName VARCHAR(MAX) = (SELECT db.DatabaseName FROM DC.[Database] AS db WHERE db.DatabaseID = @Source_DatabaseID)
	DECLARE @Source_SchemaName VARCHAR(MAX) = (SELECT DC.udf_GetSchemaNameForDataEntityID(@ODS_DataEntityID))

--	DECLARE @Source_SystemID INT = NULL  
--	DECLARE @Source_SchemaID INT = NULL
	
	-- Determine the Stage Sort Order
	DECLARE @SortTable TABLE
	(
		DataEntityID INT, DataEntityName VARCHAR(250), FieldID INT, FieldName VARCHAR(250), LinkName VARCHAR(250), FieldSortOrder INT, FieldSortOrder_Rank INT
	)
	INSERT INTO 
		@SortTable (DataEntityID, DataEntityName, FieldID, FieldName, LinkName, FieldSortOrder, FieldSortOrder_Rank)
	SELECT 
		de.DataEntityID, de.DataEntityName, f.FieldID, f.FieldName, IIF(CHARINDEX('LINKHK_', f.FieldName) > 0, REPLACE(f.FieldName, 'LINKHK_', 'LINK_'),'') AS LinkName, f.FieldSortOrder, 
		RANK() OVER(ORDER BY f.FieldSortOrder ASC)
	FROM 
		DC.Field AS f
	INNER JOIN 
		DC.DataEntity AS de
	ON 
		f.DataEntityID = de.DataEntityID
	WHERE 
		de.DataEntityID = @Stage_DataEntityID
	AND
		CHARINDEX('LINKHK_', f.FieldName) > 0
	ORDER BY 
		f.FieldSortOrder

	--SELECT * FROM @SortTable ORDER BY FieldSortOrder

	DECLARE @JoinTable TABLE 
	(
		  HubName VARCHAR(250), PKFKLinkID INT, PKFKLinkFieldID INT, FieldSortOrder INT, JoinNumber INT, LinkName VARCHAR(250)
		, FieldID_PK INT, FieldName_PK VARCHAR(250), DataEntityID_PK INT, DataEntityName_PK VARCHAR(250), SchemaName_PK VARCHAR(250), DatabaseName_PK VARCHAR(250), DatabasePurposeCode_PK VARCHAR(100)
		, FieldID_FK INT, FieldName_FK VARCHAR(250), DataEntityID_FK INT, DataEntityName_FK VARCHAR(250), SchemaName_FK VARCHAR(250), DatabaseName_FK VARCHAR(250), DatabasePurposeCode_FK VARCHAR(100)
	)
	INSERT INTO @JoinTable
	(
		  HubName, PKFKLinkID, PKFKLinkFieldID, LinkName
		, FieldID_PK, FieldName_PK, DataEntityID_PK, DataEntityName_PK, SchemaName_PK, DatabaseName_PK, DatabasePurposeCode_PK
		, FieldID_FK, FieldName_FK, DataEntityID_FK, DataEntityName_FK, SchemaName_FK, DatabaseName_FK, DatabasePurposeCode_FK
	)

	SELECT  
		  h.HubName, pkfk.PKFKLinkID, pkfkf.PKFKLinkFieldID, pkfk.LinkName
		--, RANK() OVER (ORDER BY fpkfkf_fk.FieldSortOrder ASC) AS FieldSortOrder
		, fpkfkf_pk.FieldID, fpkfkf_pk.FieldName, fpkfkf_pk.DataEntityID, depk.DataEntityName, spk.SchemaName, dpk.DatabaseName, dppk.DatabasePurposeCode
		, fpkfkf_fk.FieldID, fpkfkf_fk.FieldName, fpkfkf_fk.DataEntityID, defk.DataEntityName, sfk.SchemaName, dfk.DatabaseName, dpfk.DatabasePurposeCode
		FROM 
			DMOD.Hub AS h
		INNER JOIN 
			DMOD.PKFKLink AS pkfk
			ON pkfk.ParentHubID = h.HubID
		INNER JOIN 
			DMOD.PKFKLinkField AS pkfkf
			ON pkfkf.PKFKLinkID = pkfk.PKFKLinkID
		INNER JOIN 
			DC.[Field] AS fpkfkf_pk
			ON fpkfkf_pk.FieldID = pkfkf.PrimaryKeyFieldID
		INNER JOIN 
			DC.DataEntity AS depk
			ON depk.DataEntityID = fpkfkf_pk.DataEntityID
		INNER JOIN 
			DC.[Schema] AS spk
			ON spk.SchemaID = depk.SchemaID
		INNER JOIN 
			DC.[Database] AS dpk
			ON dpk.DatabaseID = spk.DatabaseID
		INNER JOIN 
			DC.[DatabasePurpose] AS dppk
		ON 
			dppk.DatabasePurposeID = dpk.DatabasePurposeID
		INNER JOIN 
			DC.[Field] AS fpkfkf_fk
			ON fpkfkf_fk.FieldID = pkfkf.ForeignKeyFieldID
		INNER JOIN 
			DC.DataEntity AS defk
			ON defk.DataEntityID = fpkfkf_fk.DataEntityID
		INNER JOIN 
			DC.[Schema] AS sfk
			ON sfk.SchemaID = defk.SchemaID
		INNER JOIN 
			DC.[Database] AS dfk
			ON dfk.DatabaseID = sfk.DatabaseID
		INNER JOIN 
			DC.[DatabasePurpose] AS dpfk
		ON 
			dpfk.DatabasePurposeID = dfk.DatabasePurposeID
		WHERE 
			fpkfkf_fk.DataEntityID = @Source_DataEntityID
		AND
			h.IsActive = 1
		AND
			pkfk.IsActive = 1
		AND
			pkfkf.IsActive = 1

		--SELECT * FROM @JoinTable ORDER BY FieldSortOrder desc

		-- Updates on PK (Source to ODS)
		UPDATE jt
		SET 
			jt.FieldID_PK = (SELECT DC.udf_get_ODSFieldID_From_SourceFieldID(jt.FieldID_PK))
		,	jt.DataEntityID_PK = (SELECT DC.udf_get_ODSDataEntityID_From_SourceDataEntityID(jt.DataEntityID_PK))
		,	jt.FieldID_FK = (SELECT DC.udf_get_ODSFieldID_From_SourceFieldID(jt.FieldID_FK))
		,	jt.DataEntityID_FK = (SELECT DC.udf_get_ODSDataEntityID_From_SourceDataEntityID(jt.DataEntityID_FK))
		FROM 
			@JoinTable AS jt
		WHERE 
			jt.DatabasePurposeCode_PK = 'Source'
		OR
			jt.DatabasePurposeCode_FK = 'Source'

			

		-- Update Residual (Schema, DB ECT)
		UPDATE jt
		SET 
			jt.FieldName_PK = (SELECT DC.udf_get_FieldName_From_FieldID(jt.FieldID_PK))
		,	jt.DataEntityName_PK = (SELECT DC.udf_GetDataEntityNameForDataEntityID(jt.DataEntityID_PK))
		,	jt.SchemaName_PK = (SELECT DC.udf_GetSchemaNameForDataEntityID(jt.DataEntityID_PK))
		,	jt.DatabaseName_PK = (SELECT DC.udf_get_DatabaseName_from_DataEntityID(jt.DataEntityID_PK))
		,	jt.DatabasePurposeCode_PK = (SELECT DC.udf_get_DatabasePurposeCode_from_DataEntityID(jt.DataEntityID_PK))
		,	jt.FieldName_FK = (SELECT DC.udf_get_FieldName_From_FieldID(jt.FieldID_FK))
		,	jt.DataEntityName_FK = (SELECT DC.udf_GetDataEntityNameForDataEntityID(jt.DataEntityID_FK))
		,	jt.SchemaName_FK = (SELECT DC.udf_GetSchemaNameForDataEntityID(jt.DataEntityID_FK))
		,	jt.DatabaseName_FK = (SELECT DC.udf_get_DatabaseName_from_DataEntityID(jt.DataEntityID_FK))
		,	jt.DatabasePurposeCode_FK = (SELECT DC.udf_get_DatabasePurposeCode_from_DataEntityID(jt.DataEntityID_FK))
		FROM 
			@JoinTable AS jt
		WHERE 
			jt.DatabasePurposeCode_PK = 'Source'
		OR
			jt.DatabasePurposeCode_FK = 'Source'

		--SELECT * FROM @JoinTable ORDER BY FieldSortOrder desc

		-- UPDATE JOINS FOR SORT ORDER
		UPDATE 
			jt
		SET 
			jt.FieldSortOrder = st.FieldSortOrder_Rank
		FROM 
			@JoinTable AS jt
		INNER JOIN
			@SortTable AS st
		ON 
			jt.LinkName = st.LinkName

		--SELECT * FROM @JoinTable ORDER BY FieldSortOrder desc

		UPDATE 
			jt
		SET 
			jt.JoinNumber = js.JoinNmber
		FROM 
			@JoinTable AS jt
		INNER JOIN 
		(
			SELECT 
				DataEntityID_PK, DataEntityID_FK, PKFKLinkID, MIN(FieldSortOrder) AS JoinNmber
			FROM 
				@JoinTable
			GROUP BY
				DataEntityID_PK, DataEntityID_FK, PKFKLinkID
		) AS js
		ON 
			jt.DataEntityID_PK = js.DataEntityID_PK
		AND
			jt.DataEntityID_FK = js.DataEntityID_FK
		AND
			jt.PKFKLinkID = js.PKFKLinkID

		--SELECT * FROM @JoinTable ORDER BY FieldSortOrder desc
		
		-- Count of DISTINCT Data Entitiy
		DECLARE @DataEntityCount INT = (SELECT COUNT(1) FROM @JoinTable)
		DECLARE @DataEntityCount_DISTINCT INT = (SELECT COUNT (DISTINCT PKFKLinkID) FROM @JoinTable)

		--SELECT @FieldList = @FieldList + char(9) + char(9) + char(9) + '--!~ Hub & Link table joins for ODS Select'  + CHAR(13)+CHAR(10) 

		-- No Join Tables
		IF (@DataEntityCount = 0) 
		BEGIN
			SELECT @FieldList = @FieldList + '' + CHAR(13) + CHAR(10)
		END
		  
		ELSE IF @DataEntityCount > 0
		BEGIN 	    	
		
			DECLARE @totalloops INT = (SELECT MAX(JoinNumber) FROM @JoinTable)

			DECLARE @currentloop INT  = 1
				WHILE @currentloop <= @totalloops
				BEGIN
					SELECT @FieldList = @FieldList + char(9) + char(9) + char(9) 
						+ ' LEFT JOIN ' + '[' + @Source_DatabaseName + ']' + @Seperator + '[' + @Source_SchemaName + ']' + @Seperator + '[' + jts.DataEntityName_PK  + ']'
						+ ' AS StandardAlias' + CONVERT(VARCHAR(4), jts.JoinNumber + 1)  
						+ CHAR(13)+CHAR(10) 
						+ char(9) + char(9) + char(9) + char(9)
						+ ' ON ' 
					FROM 
						(
							SELECT DISTINCT DataEntityName_PK, SchemaName_PK, DatabaseName_PK, JoinNumber
							FROM @JoinTable
						) AS jts
					WHERE 
						jts.JoinNumber = @currentloop
					ORDER BY 
						jts.JoinNumber

					SELECT @FieldList = @FieldList
						+ 'StandardAlias' + CONVERT(VARCHAR(4), JoinNumber + 1) 
						+ @Seperator
						+ '['
						+ FieldName_PK
						+ ']'
						+ ' = '
						+ 'StandardAlias' + CONVERT(VARCHAR(4), 1) 
						+ @Seperator
						+ '['
						+  FieldName_FK
						+ ']'						
						+ CHAR(13)+CHAR(10) 
						+ char(9) + char(9) + char(9) + char(9)
						+ ' AND '
					FROM 
						@JoinTable
					WHERE 
						JoinNumber = @currentloop
					ORDER BY 
						FieldSortOrder


					SET @FieldList = LEFT(@FieldList, LEN(@FieldList) - 8)

					SET @currentloop = @currentloop + 1

				   END


				END
	   
		ELSE 
		BEGIN
			   SELECT @FieldList = @FieldList + ''
		END

			SELECT @FieldList = @FieldList + char(9) + char(9) + char(9) + '-- End of Hub & Link table joins for ODS Select ~!'
			
			
		/*
			SELECT @FieldList

	
	*/
			
	
			RETURN @FieldList
		
			
		END
	
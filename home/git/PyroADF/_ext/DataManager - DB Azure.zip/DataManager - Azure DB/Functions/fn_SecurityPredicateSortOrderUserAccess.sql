﻿

CREATE FUNCTION [SEC].[fn_SecurityPredicateSortOrderUserAccess](@DataDomainID varchar(200), @IsFullAccessUserHierarchy bit)
RETURNS TABLE
AS
RETURN 

SELECT 1 AS fn_SecurityPredicate_ReportingHierarchyUserAccess
WHERE EXISTS (
				--SELECT	1
			 --   WHERE EXISTS 
				--(SELECT 1 
				--	FROM [GOV].LinkPersonToDataDomain
				--	INNER JOIN ACCESS.ReportUser RU
				--	ON RU.DomainAccount = SUSER_NAME()
				--)
				/*
				SELECT 1 WHERE exists(
					SELECT 1 FROM
					ACCESS.ReportUser RU
					inner join GOV.LinkPersonWithRoleToDataDomain LP
					ON LP.PersonAccessControlListID = RU.ReportUserID
					inner join GOV.LinkPersonWithRoleToDataDomain LP2
					ON LP2.PersonAccessControlListID = RU.ReportUserID
					WHERE DomainAccount = SUSER_NAME()
					AND LP.DataDomainID = @DataDomainID
				)
				UNION ALL
			  
				SELECT	1
			    FROM	[DataManager_DEV].[ACCESS].[FullAccessUser]
				WHERE	DomainAccountOrGroup = SUSER_NAME()
					--and IsFullAccessUser = 1
					and @IsFullAccessUserHierarchy = 1
					and IsDeveloper = 0

				UNION ALL
			  
				SELECT	1
			    FROM	[DataManager_DEV].[ACCESS].[FullAccessUser]
				WHERE	DomainAccountOrGroup = SUSER_NAME()
					and IsFullAccessUser = 0
					and IsDeveloper = 1
					*/
				SELECT 1 WHERE exists(
					SELECT 1 FROM
					GOV.Person P
					inner join GOV.LinkPersonWithRoleToDataDomain LP
					ON LP.PersonAccessControlListID = P.PersonID
					inner join GOV.LinkPersonWithRoleToDataDomain LP2
					ON LP2.PersonAccessControlListID = P.PersonID
					WHERE DomainAccountName = SUSER_NAME()
					AND LP.DataDomainID = @DataDomainID
				)
				UNION ALL
			  
				SELECT	1
			    FROM	
				--[DataManager_DEV].
				[ACCESS].[FullAccessUser]
				WHERE	DomainAccountOrGroup = SUSER_NAME()
					--and IsFullAccessUser = 1
					and @IsFullAccessUserHierarchy = 1
					and IsDeveloper = 0

				UNION ALL
			  
				SELECT	1
			    FROM	
				--[DataManager_DEV].
				[ACCESS].[FullAccessUser]
				WHERE	DomainAccountOrGroup = SUSER_NAME()
					and IsFullAccessUser = 0
					and IsDeveloper = 1
				)

﻿

--SELECT [dbo].[udf_get_XML_Stage_StaticLoadTemplate]()

CREATE FUNCTION  [dbo].[udf_get_XML_Stage_StaticLoadTemplate]
(
)
RETURNS XML
AS
BEGIN
	
	DECLARE @XMLReturnValue XML

	SET @XMLReturnValue =
		(SELECT [SQLTEXT] FROM DMOD.[Stage_StaticLoadTemplate]
			FOR XML PATH(''))

	RETURN @XMLReturnValue
END


﻿/*
-- =============================================
-- Author:      Emile Fraser
-- Create Date: 6 June 2019
-- Description: Generate a Field list for a select statement from the ODS area table with a standard alias prefix

--!~ Hub & Link Hash Key Columns for ODS Select
				CONVERT	(VARCHAR(40),
					HASHBYTES	('SHA1',
							CONVERT	(VARCHAR(MAX),
									COALESCE(UPPER(LTRIM(RTRIM(StandardAlias2.[DPT_CODE]))),'')
									)
								)
							,2) AS [HK_DEPARTMENT]
				,CONVERT	(VARCHAR(40),
					HASHBYTES	('SHA1',
							CONVERT	(VARCHAR(MAX),
									COALESCE(UPPER(LTRIM(RTRIM(StandardAlias2.[DPT_CODE]))),'') + '|' +
									COALESCE(UPPER(LTRIM(RTRIM(StandardAlias.EMP_EMPNO))),'')
									)
								)
							,2) AS [LINK_DEPARTMENT_EMPLOYEE][HK_DEPARTMENT]
-- End of Hub & Link Hash Key Columns for ODS Select ~!
SELECT [DMOD].[udf_get_FieldList_WithAlias_HashKeys_ODS](1)
SELECT [DMOD].[udf_get_FieldList_WithAlias_HashKeys_ODS](12)
SELECT [DMOD].[udf_get_FieldList_WithAlias_HashKeys_ODS](31)

SELECT * FROM DC.Field WHERE FieldName LIKE '%LINKHK_Site_TNA%'




*/


CREATE   FUNCTION [DMOD].[udf_get_FieldList_WithAlias_HashKeys_ODS](
    @LoadConfigID INT)
RETURNS VARCHAR(MAX)
AS
BEGIN

	--declare @LoadConfigID INT = 1
	DECLARE @ODS_DataEntityID INT
	DECLARE @Stage_DataEntityID INT
	DECLARE @ODS_DataEntityName VARCHAR(250)
	,		@ODS_DatabaseID INT
	,		@ODS_SchemaID INT
	,		@ODS_SystemID INT
	DECLARE @Source_DataEntityName VARCHAR(250)
	,		@Source_DatabaseID INT
    ,		@Source_DataEntityID INT
	,		@Source_SchemaID INT
	,		@Source_SystemID INT
	DECLARE @FieldList AS VARCHAR(MAX) = ''
	DECLARE @Seperator VARCHAR(1) = '.'
	DECLARE @HubID INT
	DECLARE @CountAdder INT = 0
	
	--SELECT * FROM DMOD.VW_LoadConfig WHERE LoadConfigID = 12

	SET @ODS_DataEntityID = (SELECT SourceDataEntityID FROM DMOD.LoadConfig WHERE LoadConfigID = @LoadConfigID)
	SET @Stage_DataEntityID = (SELECT TargetDataEntityID FROM DMOD.LoadConfig WHERE LoadConfigID = @LoadConfigID)
	SET @Source_DataEntityID = (SELECT DC.udf_get_SourceSystem_DataEntityID(@Stage_DataEntityID))
	--SELECT @Source_DataEntityID

	SET @HubID =
	(
		SELECT DISTINCT
			h.HubID
		FROM 
				DMOD.Hub AS h
		INNER JOIN 
			DMOD.HubBusinessKey AS hbk
			ON hbk.HubID = h.HubID
		INNER JOIN 
			DMOD.HubBusinessKeyField AS hbkf
			ON hbkf.HubBusinessKeyID = hbk.HubBusinessKeyID
		INNER JOIN 
			DC.[Field] AS f
			ON f.FieldID = hbkf.FieldID
		WHERE
			f.DataEntityID = @Source_DataEntityID
		and
			h.IsActive = 1
		AND
			hbk.IsActive = 1
		AND
			hbkf.IsActive = 1
		AND
			hbkf.IsBaseEntityField = 1
	)

	--SELECT @HubID

	SET @Source_SystemID = (SELECT DC.udf_GetSourceSystemIDForDataEntityID(@Source_DataEntityID))
	SET @ODS_DataEntityName = (SELECT DataEntityName FROM DC.DataEntity WHERE DataEntityID = @Source_DataEntityID /*@ODS_DataEntityID*/)

	--SELECT @ODS_SystemID,@ODS_DataEntityName

	DECLARE @LinkTableSort TABLE (FieldID VARCHAR(255), FieldName VARCHAR(250), FieldSortOrder INT)
	INSERT INTO @LinkTableSort(FieldID, FieldName, FieldSortOrder)
	SELECT f.FieldID, f.FieldName, f.FieldSortOrder
	FROM DC.Field AS f
	WHERE f.dataentityid = @Stage_DataEntityID
	order by f.fieldSortorder
	

	--SELECT * FROM @LinkTableSort

	DECLARE @LinkTable TABLE (HubName VARCHAR(255), PKFKLinkID INT, PKFKLinkFieldID INT,
									LinkName VARCHAR(255), ChildHubID INT, SortOrder INT, TableAliasNumber INT, 
										FieldID INT, FieldName VARCHAR(255), SystemID INT, HK_Name VARCHAR(255))
	INSERT INTO @LinkTable  (HubName , PKFKLinkID , PKFKLinkFieldID ,
									LinkName , ChildHubID , SortOrder, TableAliasNumber , 
										FieldID , FieldName, SystemID, HK_Name)
		
		

	SELECT 
			h.HubName
			, pkfk.PKFKLinkID
			, pkfkf.PKFKLinkFieldID
			, pkfk.LinkName
			, pkfk.ChildHubID
			, RANK() OVER (ORDER BY ss.FieldSortOrder ASC) AS SortOrder
			, RANK() OVER (ORDER BY ss.FieldSortOrder ASC)+1 AS TableAliasNumber
			, fpkfkf_pk.FieldID AS FieldID_pk
			, fpkfkf_pk.FieldName AS FieldName_pk
			, DC.udf_GetSourceSystemIDForDataEntityID(fpkfkf_pk.DataEntityID) AS SystemID_pk
			, REPLACE(h.HubName, 'HUB_', 'HK_') AS HK_Name
				FROM 
				DMOD.Hub AS h
			INNER JOIN 
				DMOD.PKFKLink AS pkfk
				ON pkfk.ParentHubID = h.HubID
			INNER JOIN 
				DMOD.PKFKLinkField AS pkfkf
				ON pkfkf.PKFKLinkID = pkfk.PKFKLinkID
			INNER JOIN 
				DC.[Field] AS fpkfkf_pk
				ON fpkfkf_pk.FieldID = pkfkf.PrimaryKeyFieldID
			INNER JOIN 
				DC.[Field] AS fpkfkf_fk
				ON fpkfkf_fk.FieldID = pkfkf.ForeignKeyFieldID
			INNER JOIN
				@LinkTableSort AS ss
			ON 
				REPLACE(pkfk.LinkName, 'LINK_', 'LINKHK_') = ss.FieldName
			WHERE 
				fpkfkf_fk.DataEntityID = @Source_DataEntityID
			AND
				h.IsActive = 1
			AND
				pkfk.IsActive = 1
			AND
				pkfkf.IsActive = 1

	--SELECT * FROM @LinkTable

	--DECLARE @HubID INT = (SELECT DISTINCT ChildHubID FROM @LinkTable)

	DECLARE @BKTable TABLE (HubID INT, HubName VARCHAR(255), FieldSortOrder INT, FieldID INT, FieldName VARCHAR(255), SystemID INT)
	INSERT INTO @BKTable  
	(
		HubID 
		, HubName 
		, FieldSortOrder 
		, FieldID 
		, FieldName
		, SystemID  
	)
	SELECT 
		h.HubID
	,	h.HubName
	,	RANK() OVER (ORDER BY hbk.FieldSortOrder ASC) AS FieldSortOrder
	,	hbkf.FieldID
	,	f.FieldName
	,	DC.udf_GetSourceSystemIDForDataEntityID(f.DataEntityID) AS SystemID_pk
	FROM 
			DMOD.Hub AS h
	INNER JOIN 
		DMOD.HubBusinessKey AS hbk
		ON hbk.HubID = h.HubID
	INNER JOIN 
		DMOD.HubBusinessKeyField AS hbkf
		ON hbkf.HubBusinessKeyID = hbk.HubBusinessKeyID
	INNER JOIN 
		DC.[Field] AS f
		ON f.FieldID = hbkf.FieldID
	WHERE 
		h.HubID = @HubID
	AND
		h.IsActive = 1
	AND
		hbk.IsActive = 1
	AND
		hbkf.IsActive = 1

	SELECT @FieldList = @FieldList + '--!~ Hub & Link Hash Key Columns for ODS Select' + CHAR(13)

	--SELECT * FROM @LinkTable
	--SELECT @Source_SystemID


	DECLARE @totalloops INT = (SELECT MAX(SortOrder) FROM @LinkTable) 

	DECLARE @currentloop INT  = 1
	IF(@totalloops <> 0)
	BEGIN
		WHILE @currentloop <= @totalloops
		BEGIN

			SELECT @FieldList = @FieldList + ',' + ' CONVERT(VARCHAR(40),' + CHAR(13)
			+ REPLICATE(CHAR(9),5) + ' HASHBYTES (''SHA1'',' + CHAR(13)
						
			SELECT @FieldList = @FieldList + REPLICATE(CHAR(9),6) + '  CONVERT	(VARCHAR(MAX),' + CHAR(13)
			+ REPLICATE(CHAR(9),7) + '  COALESCE(UPPER(LTRIM(RTRIM(' + QUOTENAME('StandardAlias' + CONVERT(VARCHAR(4), h.[TableAliasNumber])) + @Seperator + QUOTENAME(h.[FieldName]) + '))),''NA''))  + ''|'' +' + CHAR(13)
			FROM @LinkTable AS h
			WHERE h.SortOrder = @currentloop

			SET @FieldList = LEFT(@FieldList, LEN(@FieldList) - 9) + CHAR(13)
					
			SELECT TOP 1 @FieldList = @FieldList + REPLICATE(CHAR(9),6) + ' )' + CHAR(13)
			+ REPLICATE(CHAR(9),5) + ' ,2) AS ' + QUOTENAME(h.HK_Name) + CHAR(13)
			FROM @LinkTable AS h
			WHERE /* h.SystemID = @Source_SystemID
			AND */ h.SortOrder = @currentloop


			SELECT @FieldList = @FieldList + ',' +  ' CONVERT(VARCHAR(40),' + CHAR(13)
			+ REPLICATE(CHAR(9),5) + ' HASHBYTES (''SHA1'',' + CHAR(13)

			SELECT @FieldList = @FieldList + REPLICATE(CHAR(9),6) + '  CONVERT	(VARCHAR(MAX),' + CHAR(13)
			+ REPLICATE(CHAR(9),7) + '  COALESCE(UPPER(LTRIM(RTRIM(' + QUOTENAME('StandardAlias' + CONVERT(VARCHAR(4), h.[TableAliasNumber])) + @Seperator + QUOTENAME(h.[FieldName]) + '))),''NA'')) + ''|'' +' + CHAR(13)
			FROM @LinkTable AS h
			WHERE h.SortOrder = @currentloop



			SELECT @FieldList = @FieldList + REPLICATE(CHAR(9),6) + '  CONVERT	(VARCHAR(MAX),' + CHAR(13)
			+ REPLICATE(CHAR(9),7) + '  COALESCE(UPPER(LTRIM(RTRIM(' + QUOTENAME('StandardAlias' + CONVERT(VARCHAR(4), 1)) + @Seperator + QUOTENAME(b.[FieldName]) + '))),'''')) + ''|'' +' + CHAR(13)
			FROM @BKTable AS b
			/*WHERE b.SystemID = @Source_SystemID*/
			ORDER BY b.FieldSortOrder

			SET @FieldList = LEFT(@FieldList, LEN(@FieldList) - 9)
			
			SELECT TOP 1 @FieldList = @FieldList  + CHAR(13)	 
			+ REPLICATE(CHAR(9),6) + ' )' + CHAR(13)
			+ REPLICATE(CHAR(9),5) + ' ,2) AS ' + QUOTENAME(REPLACE(h.LinkName, 'LINK_','LINKHK_')) + CHAR(13)
			FROM @LinkTable AS h
			WHERE h.SortOrder = @currentloop

			set @CountAdder	= 
			(
				SELECT COUNT(1) FROM @LinkTable AS h
				WHERE h.SortOrder = @currentloop
			)
			
			SET @currentloop = @currentloop + @CountAdder


		END


	END

	--SET @FieldList = LEFT(@FieldList, LEN(@FieldList) - 1) + CHAR(13)

	SELECT @FieldList = @FieldList + '-- End of Hub & Link Hash Key Columns for ODS Select ~!' + CHAR(13)

	
	
	
	



	/*
PRINT @FieldList
*/


RETURN @FieldList
END



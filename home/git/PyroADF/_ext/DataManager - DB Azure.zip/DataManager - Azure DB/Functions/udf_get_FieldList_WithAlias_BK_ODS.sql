﻿/*
 Author:      Emile Fraser
 Create Date: 6 June 2019
 Description: Generate a Field list for a select statement from the ODS area table with a standard alias prefix

--!~ StageArea BK Hash Column Calculation from ODS
				BKHash = CONVERT	(VARCHAR(40),
							HASHBYTES	('SHA1',
									CONVERT	(VARCHAR(MAX),
											COALESCE(UPPER(LTRIM(RTRIM(StandardAlias.EMP_EMPNO))),'')
											)
										)
								,2)
-- End of StageArea BK Hash Column Calculation from ODS ~!

SELECT DMOD.[udf_get_FieldList_WithAlias_BK_ODS](11)
SELECT DMOD.[udf_get_FieldList_WithAlias_BK_ODS](37)
SELECT DMOD.[udf_get_FieldList_WithAlias_BK_ODS](31)
*/
CREATE   FUNCTION [DMOD].[udf_get_FieldList_WithAlias_BK_ODS]
(
    @LoadConfigID INT
)
RETURNS VARCHAR(MAX)
AS
BEGIN

	--DECLARE @LoadConfigID INT = 11

	  -- Field List Helpers
	DECLARE @FieldList VARCHAR(MAX) = ''

	-- Stage Fields
	DECLARE @Stage_DataEntityID INT = (SELECT Target_DataEntityID FROM DMOD.vw_LoadConfig WHERE LoadConfigID = @LoadConfigID)
	--SELECT @Stage_DataEntityID AS Stage_DataEntityID -- 9911  -- DEBUG

	-- ODS Fields
	DECLARE @ODS_DataEntityID INT = (SELECT Source_DataEntityID FROM DMOD.vw_LoadConfig WHERE LoadConfigID = @LoadConfigID)
	--SELECT @ODS_DataEntityID AS ODS_DataEntityID -- 35  -- DEBUG

	-- Source Fields
	DECLARE @Source_DataEntityID INT = (SELECT DC.udf_get_SourceSystem_DataEntityID(@Stage_DataEntityID))
	--SELECT @Source_DataEntityID AS Source_DataEntityID -- 631  -- DEBUG

	-- HUB_ID
	DECLARE @HubID INT = 
	(
		SELECT DISTINCT 
			h.HubID
		FROM
			 [DMOD].[Hub] AS [h]
		INNER JOIN
			[DMOD].[HubBusinessKey] AS [hbk]
			ON [hbk].[HubID] = [h].[HubID]
		INNER JOIN
			[DMOD].[HubBusinessKeyField] AS [hbkf]
			ON [hbkf].[HubBusinessKeyID] = [hbk].[HubBusinessKeyID]
		INNER JOIN
			[DC].[Field] AS [fhbkf]
			ON [fhbkf].[FieldID] = [hbkf].[FieldID]
		INNER JOIN
			[DC].[DataEntity] AS [de]
			ON [fhbkf].[DataEntityID] = [de].[DataEntityID]
		WHERE 
			[fhbkf].[DataEntityID] = @Source_DataEntityID
		AND
			h.IsActive = 1
		AND
			hbk.IsActive = 1
		AND
			hbkf.IsActive = 1
		AND
			hbkf.IsBaseEntityField = 1
	)

	--SELECT @HubID AS HubID -- DEBUG

	-- SELECT DC.udf_get_ODSDataEntityID_From_SourceDataEntityID(291)

	DECLARE @BKHashTable TABLE 
	(
		HubID INT
	,	BK_DataEntityID INT
	,	BK_DataEntityName VARCHAR(250)
	,	BK_FieldID INT
	,   BK_FriendlyName VARCHAR(250)
	,	BK_FieldName VARCHAR(250)
	,	FieldSortOrder INT
	,	StandardAliasNumber INT
	)
	INSERT INTO @BKHashTable
	(
		   [HubID]
		 , [BK_DataEntityID]
		 , [BK_DataEntityName]
		 , [BK_FieldID]
		 , [BK_FriendlyName]
		 , [BK_FieldName]
		 , [FieldSortOrder]
		 , [StandardAliasNumber]
	)
	SELECT
		   [h].[HubID]
		 , [fhbkf].[DataEntityID]
		 , [de].[DataEntityName]
		 , [fhbkf].[FieldID]
		 , hbk.BKFriendlyName
		 , fhbkf.FieldName
		 , [hbk].[FieldSortOrder]
		 , [DMOD].[udf_get_StandardAliasPerDataEntityID_from_LoadConfigID](@LoadConfigID, @ODS_DataEntityID)
	FROM
		 [DMOD].[Hub] AS [h]
	INNER JOIN
		[DMOD].[HubBusinessKey] AS [hbk]
		ON [hbk].[HubID] = [h].[HubID]
	INNER JOIN
		[DMOD].[HubBusinessKeyField] AS [hbkf]
		ON [hbkf].[HubBusinessKeyID] = [hbk].[HubBusinessKeyID]
	INNER JOIN
		[DC].[Field] AS [fhbkf]
		ON [fhbkf].[FieldID] = [hbkf].[FieldID]
	INNER JOIN
		[DC].[DataEntity] AS [de]
		ON [fhbkf].[DataEntityID] = [de].[DataEntityID]
	WHERE 
		h.HubID = @HubID
		--[fhbkf].[DataEntityID] = @Source_DataEntityID
	AND
		h.IsActive = 1
	AND
		hbk.IsActive = 1
	AND
		hbkf.IsActive = 1

	--SELECT * FROM @BKHashTable

	-- DETERMINE WHAT TO DO
	DECLARE @DataEntityCount INT, @DataEntityCount_DISTINCT INT
	SELECT @DataEntityCount =  COUNT(DISTINCT BK_DataEntityID) FROM @BKHashTable
    SELECT @DataEntityCount_DISTINCT =  COUNT(DISTINCT BK_FieldID) FROM @BKHashTable

	SELECT @FieldList = @FieldList + '--!~ StageArea BK Hash Column Calculation from ODS' + CHAR(13)

	-- COLUMNS FROM THE SAME TABLE
	IF (@DataEntityCount_DISTINCT = 1) 
	BEGIN
		IF (@DataEntityCount = 1) 
		BEGIN
	 
			SELECT @FieldList = @FieldList + ' CONVERT(VARCHAR(40),' + CHAR(13)
			+ REPLICATE(CHAR(9),5) + ' HASHBYTES (''SHA1'',' + CHAR(13)
			+ REPLICATE(CHAR(9),6) + ' CONVERT	(VARCHAR(MAX),' + CHAR(13)
			+ REPLICATE(CHAR(9),7) + ' COALESCE(UPPER(LTRIM(RTRIM(' + QUOTENAME('StandardAlias' + CONVERT(VARCHAR(4), bk.StandardAliasNumber)) + '.' + QUOTENAME(bk.BK_FieldName) + '))),''''))' + CHAR(13)
			+ REPLICATE(CHAR(9),6) + ' )' + CHAR(13)
			+ REPLICATE(CHAR(9),5) + ' ,2)' + CHAR(13)
			FROM
				@BKHashTable AS bk	
			ORDER BY 
				bk.[FieldSortOrder]
    
		END
		  
		ELSE IF (@DataEntityCount > 1)
		BEGIN 
	   			
			SELECT @FieldList = @FieldList + ' CONVERT(VARCHAR(40),' + CHAR(13) + REPLICATE(CHAR(9),5) + ' HASHBYTES (''SHA1'',' + CHAR(13)

			SELECT @FieldList = @FieldList +
	  		+ REPLICATE(CHAR(9),6) + '  CONVERT	(VARCHAR(MAX),' + CHAR(13)
			+ REPLICATE(CHAR(9),7) + '  COALESCE(UPPER(LTRIM(RTRIM(' + QUOTENAME('StandardAlias' + CONVERT(VARCHAR(4), bk.StandardAliasNumber)) + '.' + QUOTENAME(bk.BK_FieldName) + '))),'''')) + ''|'' +' + CHAR(13)
			FROM
				@BKHashTable AS bk
			ORDER BY 
				bk.[FieldSortOrder]

		   IF (@FieldList != '')
			  SET @FieldList = LEFT(@FieldList, LEN(@FieldList) - 9)

			SELECT @FieldList = @FieldList + CHAR(13)
			+ REPLICATE(CHAR(9),6) + ' )' + CHAR(13)
			+ REPLICATE(CHAR(9),5)+ ' ,2) AS BKHash' + CHAR(13)

		END	

	END

	ELSE IF (@DataEntityCount_DISTINCT > 1) 
	BEGIN

	   DECLARE @DataEntityID AS INT
	   DECLARE @StandardAlias_Number AS INT

		SELECT @FieldList = @FieldList + ' CONVERT(VARCHAR(40),' + CHAR(13) + REPLICATE(CHAR(9),5) + ' HASHBYTES (''SHA1'',' + CHAR(13)

		SELECT @FieldList = @FieldList + CHAR(13)
		+ REPLICATE(CHAR(9),6) + '  CONVERT	(VARCHAR(MAX),' + CHAR(13)
		+ REPLICATE(CHAR(9),7)+ '  COALESCE(UPPER(LTRIM(RTRIM(' + QUOTENAME('StandardAlias' + CONVERT(VARCHAR(4), bk.StandardAliasNumber)) + '.' + QUOTENAME(bk.BK_FieldName) + '))),'''')) + ''|'' +' + CHAR(13)  
		FROM
		@BKHashTable AS bk
		/*
		INNER JOIN 
		(   
			SELECT 
				bkd.BK_DataEntityID, ROW_NUMBER() OVER( ORDER BY bkd.ODS_DataEntityName ASC) AS StandardAlias_Number
			FROM (
					SELECT DISTINCT bk.BK_DataEntityID, bk.BK_DataEntityName
					FROM @BKHashTable AS bk
				) AS bkd
		) bkdr
		ON bkdr.BK_DataEntityID = bk.BK_DataEntityID
		*/
		ORDER BY 
			bk.[FieldSortOrder]

		  IF @FieldList != ''
			   SET @FieldList = LEFT(@FieldList, LEN(@FieldList) - 9)


			SELECT @FieldList = @FieldList + CHAR(13)
			+ REPLICATE(CHAR(9),6) + ' )' + CHAR(13)
			+ REPLICATE(CHAR(9),5)+ ' ,2) AS BKHash' + CHAR(13)

	END

	ELSE 
	BEGIN
		SELECT @FieldList = @FieldList + ''
	END

	SELECT @FieldList = @FieldList + '-- End of StageArea BK Hash Column Calculation from ODS ~!'

--SELECT @FieldList AS ReturnValue

RETURN @FieldList

END

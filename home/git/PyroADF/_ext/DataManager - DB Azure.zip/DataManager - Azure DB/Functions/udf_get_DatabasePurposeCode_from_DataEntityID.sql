﻿-- =============================================
-- Author:      Frans Germishuizen
-- Create Date: 2019-06-20
-- Description: Get the Database Purpose Code for a DatabaseID
-- =============================================

CREATE FUNCTION [DC].[udf_get_DatabasePurposeCode_from_DataEntityID]
(
    -- Add the parameters for the function here
    @DataEntityID int
)
RETURNS varchar(250)
AS
BEGIN
 -- Declare the return variable here
    DECLARE @Result varchar(250)

 -- Add the T-SQL statements to compute the return value here
    SELECT	
		@Result = dbp.DatabasePurposeCode
	FROM	
		DC.[Database] db
	INNER JOIN 
		DC.DatabasePurpose dbp 
		ON dbp.DatabasePurposeID = db.DatabasePurposeID
	WHERE db.DatabaseID = 
		(
			SELECT	
				db.DatabaseID
			FROM	
				DC.[DataEntity]  AS de
			INNER JOIN 
				DC.[Schema] AS s
				ON s.SchemaID = de.SchemaID
			INNER JOIN 
				DC.[Database] AS db
				ON s.[DatabaseID] = db.[DatabaseID]
			WHERE
				de.DataEntityID = @DataEntityID
		)

    -- Return the result of the function
    RETURN @Result
END



	

﻿
/*
-- Author:      Emile Fraser
-- Create Date: 6 June 2019

-- Sample Execution Statement
--	Select [DMOD].[udf_get_StageAreaVelocityHistoryTableName](1)
*/

CREATE   FUNCTION [DMOD].[udf_get_StageAreaVelocityHistoryTableName](
	@LoadConfigID INT
)
RETURNS VARCHAR(MAX)
AS
BEGIN
	DECLARE @StageAreaVelocityHistoryTableName VARCHAR(MAX)
	DECLARE @History_Extension AS VARCHAR(5) = '_Hist'

	-- Uses the Base Velocity Function to determine the Velocity_History Table
	SET @StageAreaVelocityHistoryTableName = (
		SELECT QUOTENAME(PARSENAME([DMOD].[udf_get_StageAreaVelocityTableName](@LoadConfigID),1) + @History_Extension)
	)

	RETURN @StageAreaVelocityHistoryTableName;
END;

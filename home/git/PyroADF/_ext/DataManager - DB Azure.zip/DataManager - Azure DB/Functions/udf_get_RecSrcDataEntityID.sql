﻿
/*
Author:      Emile Fraser
Create Date: 6 June 2019
Description: Generate a record SourceDataEntityID

--!~ RecSrcDataEntityID
				, 123 AS [RecSrcDataEntityID],
-- End of RecSrcDataEntityID ~!

*/
CREATE FUNCTION [DMOD].[udf_get_RecSrcDataEntityID](
	@LoadConfigID INT
)
RETURNS VARCHAR(MAX)
AS
BEGIN
	DECLARE @RecSrcDataEntityID INT
	DECLARE @RecSrcDataEntityID_Return VARCHAR(MAX) = ''
	DECLARE @TargetDataEntityID INT


	SET @TargetDataEntityID = 
	(
		SELECT lc.TargetDataEntityID
		FROM [DMOD].[LoadConfig] AS lc
		WHERE LoadConfigID = @LoadConfigID
	)

	SET @RecSrcDataEntityID = (SELECT [DC].[udf_get_SourceSystem_DataEntityID](@TargetDataEntityID))

	SELECT @RecSrcDataEntityID_Return = @RecSrcDataEntityID_Return + '--!~ RecSrcDataEntityID' + CHAR(13)
	SELECT @RecSrcDataEntityID_Return = @RecSrcDataEntityID_Return + CHAR(9) + CHAR(9) + CHAR(9) + CHAR(9) +' , ' + CONVERT(VARCHAR(10), @RecSrcDataEntityID) + ' AS [RecSrcDataEntityID] , '  + CHAR(13)
	SELECT @RecSrcDataEntityID_Return = @RecSrcDataEntityID_Return + '-- End of RecSrcDataEntityID ~!' + CHAR(13)

	RETURN @RecSrcDataEntityID_Return;
END;

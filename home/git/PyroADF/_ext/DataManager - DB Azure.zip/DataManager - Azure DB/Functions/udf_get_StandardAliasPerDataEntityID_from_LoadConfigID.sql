﻿--SELECT @Stage_DataEntityID -- 9911
/*
FROM [ODS_XT900].[dbo].[CLOCKHIST] AS StandardAlias1
			--!~ Hub & Link table joins for ODS Select
			 LEFT JOIN [ODS_XT900].[dbo].[TERMINAL] AS StandardAlias2
				 ON StandardAlias2.[TERM_CODEID] = StandardAlias1.[TERM_CODEID]
			 LEFT JOIN [ODS_XT900].[dbo].[TAG] AS StandardAlias3
				 ON StandardAlias3.[TAG_CODE] = StandardAlias1.[TAG_CODE]
			 LEFT JOIN [ODS_XT900].[dbo].[MASTER] AS StandardAlias4
				 ON StandardAlias4.[MST_SQ] = StandardAlias1.[MST_SQ]
			 LEFT JOIN [ODS_XT900].[dbo].[EVENTTYPE] AS StandardAlias5
				 ON StandardAlias5.[ET_CODEID] = StandardAlias1.[ET_CODEID]
			 LEFT JOIN [ODS_XT900].[dbo].[DIRECTION] AS StandardAlias6
				 ON StandardAlias6.[DIR_CODEID] = StandardAlias1.[DIR_CODEID]
			-- End of Hub & Link table joins for ODS Select ~!


			CLOCKHIST 1

			TERMINAL 2
			TAG 3
			MASTER 4
			EVENTTYPE 5
			DIRECTION 6

	*/
CREATE FUNCTION [DMOD].[udf_get_StandardAliasPerDataEntityID_from_LoadConfigID]
(
    @LoadConfigID INT
,	@DataEntityID INT
)
RETURNS INT
AS
BEGIN
	
	--DECLARE @LoadConfigID INT = 1
	DECLARE @StandardAliasNumber INT

	DECLARE @TargetEntityID INT = (SELECT Target_DataEntityID FROM DMOD.vw_LoadConfig WHERE LoadConfigID = @LoadConfigID) 
	DECLARE @LoadDataEntityID INT = (SELECT Source_DataEntityID FROM DMOD.vw_LoadConfig WHERE LoadConfigID = @LoadConfigID) 

	SET @StandardAliasNumber =
	(
		SELECT StandardAlias_Ref
		FROM 
		(
			SELECT DISTINCT
				f.DataEntityID AS Target_DataEntityID
			,	odsf.DataEntityID AS Source_DataEntityID
			,	de.DataEntityName
			,	1 AS SortOrderRef_Ref
			,	1 AS StandardAlias_Ref
			FROM DC.Field AS f
			INNER JOIN DC.FieldRelation AS fr
			ON fr.TargetFieldID = f.FieldID
			INNER JOIN 
			DC.Field AS odsf
			ON odsf.FieldID = fr.SourceFieldID
			INNER JOIN DC.DataEntity AS de
			ON de.DataEntityID = odsf.DataEntityID
			WHERE f.DataEntityID = @TargetEntityID
			AND f.IsActive = 1
			AND f.FieldName NOT IN ('BKHash')
			AND odsf.DataEntityID = @LoadDataEntityID


			UNION ALL 


			SELECT *, RANK() OVER (ORDER BY sq.FieldSortOrder_Ref ASC) + 1 AS StandardAlias_Ref
			FROM
			(
				SELECT		
					f.DataEntityID AS Target_DataEntityID
				,	odsf.DataEntityID AS Source_DataEntityID
				,	de.DataEntityName
				,	MIN(f.FieldSortOrder) AS FieldSortOrder_Ref
				FROM DC.Field AS f
				INNER JOIN DC.FieldRelation AS fr
				ON fr.TargetFieldID = f.FieldID
				INNER JOIN 
				DC.Field AS odsf
				ON odsf.FieldID = fr.SourceFieldID
				INNER JOIN DC.DataEntity AS de
				ON de.DataEntityID = odsf.DataEntityID
				WHERE f.DataEntityID = @TargetEntityID
				AND f.IsActive = 1
				AND f.FieldName NOT IN ('BKHash')
				AND f.FieldName LIKE '%LinkHK%'
				AND odsf.DataEntityID != @LoadDataEntityID
				group by f.DataEntityID, odsf.DataEntityID, de.DataEntityName
			) AS sq
		) AS mq
		WHERE mq.Source_DataEntityID = @DataEntityID
	)

	RETURN @StandardAliasNumber

END

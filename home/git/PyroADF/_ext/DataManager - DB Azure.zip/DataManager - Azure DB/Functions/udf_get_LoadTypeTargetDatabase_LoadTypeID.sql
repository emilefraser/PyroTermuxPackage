﻿-- =============================================
-- Author:      Emile Fraser
-- Create Date: 2019-08-10
-- Description: Get Load Type Name from LoadTypeID
-- =============================================

CREATE FUNCTION [DMOD].[udf_get_LoadTypeTargetDatabase_LoadTypeID]
(
    -- Add the parameters for the function here
    @LoadTypeID INT
)
RETURNS varchar(50)
AS
BEGIN
    -- Declare the return variable here
    DECLARE @LoadTypeTargetDatabase varchar(100)

	SET @LoadTypeTargetDatabase = 
	(
		SELECT
			LoadTypeTargetDatabase
		FROM 
			DMOD.LoadType
		WHERE
			LoadTypeID = @LoadTypeID
	)

    -- Return the result of the function
    RETURN @LoadTypeTargetDatabase
END

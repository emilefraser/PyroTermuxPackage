﻿
-- =============================================
-- Author:      Karl Dinkelmann
-- Create Date: 16 Oct 2018
-- Description: Returns a field list from the Data Catalog for an INSERT or		`
-- =============================================
-- Sample Execution: select [DMOD].[udf_get_SatelliteCreateDT_Last](46704)

CREATE   FUNCTION [DMOD].[udf_get_SatelliteCreateDT_Last_Field]
(
    @Stage_DataEntityID INT
)
RETURNS VARCHAR(MAX)
AS
BEGIN

	DECLARE @FieldList varchar(MAX)

	SET @FieldList = '[Database].[Schema].[Table].[SatelliteCreateDT_Last_FIELD_TOUPDATE]'

	RETURN @FieldList
END




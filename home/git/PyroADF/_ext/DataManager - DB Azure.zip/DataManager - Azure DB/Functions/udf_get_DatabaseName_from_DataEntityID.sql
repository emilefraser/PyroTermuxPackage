﻿
-- Emile Fraser
-- Select [DC].[udf_get_DatabaseID_from_DataEntityID](63)
CREATE FUNCTION [DC].[udf_get_DatabaseName_from_DataEntityID]
(
    @DataEntityID int
)
RETURNS VARCHAR(250)
AS
BEGIN
	
	DECLARE @DatabaseName VARCHAR(250)

	SELECT	
		@DatabaseName = db.DatabaseName
	FROM	
		DC.[DataEntity]  AS de
	INNER JOIN 
		DC.[Schema] AS s
		ON s.SchemaID = de.SchemaID
	INNER JOIN 
		DC.[Database] AS db
		ON s.[DatabaseID] = db.[DatabaseID]
	WHERE
		de.DataEntityID = @DataEntityID

	RETURN @DatabaseName

END

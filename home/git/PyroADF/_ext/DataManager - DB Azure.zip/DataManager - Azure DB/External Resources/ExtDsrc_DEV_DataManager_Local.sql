﻿CREATE EXTERNAL DATA SOURCE [ExtDsrc_DEV_DataManager_Local]
    WITH (
    TYPE = RDBMS,
    LOCATION = N'TSABISQLDEV01\STAGSSIS',
    DATABASE_NAME = N'DataManager_Local',
    CREDENTIAL = [dsc_DEV_DataManager_Local]
    );


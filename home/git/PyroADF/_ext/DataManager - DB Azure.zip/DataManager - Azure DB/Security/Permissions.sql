﻿GRANT CONNECT TO [fsenekal@tharisa.com];


GO
GRANT CONNECT TO [abosch@tharisa.com];


GO
GRANT CONNECT TO [petrosp@tharisa.com];


GO
GRANT CONNECT TO [roosthuizen@tharisa.com];


GO
GRANT CONNECT TO [tmokwetli@tharisa.com];


GO
GRANT CONNECT TO [BI Developers];


GO
GRANT CONNECT TO [BI Admins];


GO
GRANT CONNECT TO [Emile.fraser];


GO
GRANT CONNECT TO [PowerAppsTest];


﻿CREATE USER [PowerAppsTest] FOR LOGIN [PowerAppsTest];


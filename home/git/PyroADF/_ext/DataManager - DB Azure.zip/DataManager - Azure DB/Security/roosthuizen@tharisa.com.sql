﻿CREATE USER [roosthuizen@tharisa.com] FOR EXTERNAL PROVIDER;


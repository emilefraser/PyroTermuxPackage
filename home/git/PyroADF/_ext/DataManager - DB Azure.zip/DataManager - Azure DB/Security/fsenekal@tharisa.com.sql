﻿CREATE USER [fsenekal@tharisa.com] FOR EXTERNAL PROVIDER;


﻿CREATE SCHEMA [TYPE]
    AUTHORIZATION [fsenekal@tharisa.com];


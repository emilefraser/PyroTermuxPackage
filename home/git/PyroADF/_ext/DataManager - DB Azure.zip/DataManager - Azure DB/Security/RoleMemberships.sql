﻿ALTER ROLE [db_owner] ADD MEMBER [fsenekal@tharisa.com];


GO
ALTER ROLE [db_owner] ADD MEMBER [roosthuizen@tharisa.com];


GO
ALTER ROLE [db_owner] ADD MEMBER [tmokwetli@tharisa.com];


GO
ALTER ROLE [db_owner] ADD MEMBER [BI Developers];


GO
ALTER ROLE [db_owner] ADD MEMBER [BI Admins];


GO
ALTER ROLE [db_owner] ADD MEMBER [Emile.fraser];


GO
ALTER ROLE [db_owner] ADD MEMBER [PowerAppsTest];


GO
ALTER ROLE [db_datareader] ADD MEMBER [petrosp@tharisa.com];


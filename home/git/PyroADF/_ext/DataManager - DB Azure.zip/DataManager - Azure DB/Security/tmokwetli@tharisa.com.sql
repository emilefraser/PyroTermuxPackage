﻿CREATE USER [tmokwetli@tharisa.com] FOR EXTERNAL PROVIDER;


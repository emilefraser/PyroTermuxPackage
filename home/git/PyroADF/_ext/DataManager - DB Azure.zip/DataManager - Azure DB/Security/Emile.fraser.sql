﻿CREATE USER [Emile.fraser] FOR LOGIN [Emile.fraser];


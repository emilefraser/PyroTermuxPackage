﻿CREATE USER [petrosp@tharisa.com] FOR EXTERNAL PROVIDER;


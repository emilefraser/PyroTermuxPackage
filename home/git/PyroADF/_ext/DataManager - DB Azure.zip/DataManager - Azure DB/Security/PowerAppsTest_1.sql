﻿CREATE LOGIN [PowerAppsTest]
    WITH PASSWORD = N'?9|%lieieg4zgr{vIjxtm$fpmsFT7_&#$!~<wl,lu.|K1JzM';


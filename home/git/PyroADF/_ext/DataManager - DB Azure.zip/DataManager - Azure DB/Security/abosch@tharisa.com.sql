﻿CREATE USER [abosch@tharisa.com] FOR EXTERNAL PROVIDER;


﻿CREATE LOGIN [Emile.fraser]
    WITH PASSWORD = N'|ieSJigrvjw4t#`fpwKluzqsmsFT7_&#$!~<hIazwnjkI{l;';


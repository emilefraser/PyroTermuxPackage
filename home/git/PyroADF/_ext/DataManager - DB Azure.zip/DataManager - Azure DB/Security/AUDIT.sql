﻿CREATE SCHEMA [AUDIT]
    AUTHORIZATION [roosthuizen@tharisa.com];


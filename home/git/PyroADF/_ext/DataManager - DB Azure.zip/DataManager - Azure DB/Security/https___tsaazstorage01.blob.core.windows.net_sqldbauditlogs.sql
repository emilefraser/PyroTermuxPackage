﻿CREATE DATABASE SCOPED CREDENTIAL [https://tsaazstorage01.blob.core.windows.net/sqldbauditlogs]
    WITH IDENTITY = N'SHARED ACCESS SIGNATURE';


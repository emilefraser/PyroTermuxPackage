﻿

--By Wium Swart 21 may 2019

CREATE PROCEDURE [INTEGRATION].[sp_load_Executionlog]
AS

INSERT INTO ETL.Executionlog ([ExecutionLogID]
      ,[LoadConfigID]
      ,[DatabaseName]
      ,[SchemaName]
      ,[DataEntityName]
      ,[StartDT]
      ,[FinishDT]
      ,[LastProcessingKeyValue]
      ,[IsReload]
      ,[Result]
      ,[ErrorMessage]
      ,[IsError]
      ,[IsDataIntegrityError]
      ,[SourceRowCount]
      ,[SourceTableSizeBytes]
      ,[InitialTargetRowCount]
      ,[InitialTargetTableSizeBytes]
      ,[RowsTransferred]
      ,[DeletedRowCount]
      ,[UpdatedRowCount]
      ,[UpdatedRowBytes]
      ,[TargetRowCount]
      ,[TargetTableSizeBytes]
      ,[NewRowCount]
      ,[NewRowsBytes])
select * from INTEGRATION.ingress_Executionlog



﻿



CREATE PROCEDURE [REPREG].[sp_ins_ReportRegister]
	@ReportName varchar(200),
	@ReportDescription varchar(5000),
	@ReportType int
AS
BEGIN
	
	--================================================================================
	-- Variable workbench
	--================================================================================
	/*

	declare @ReportName varchar(200),
	declare @ReportDescription varchar(5000),
	declare @ReportType int

	set		@ReportName = 'Frans Test Report'
	set @ReportDescription = 'Frans Test Report Description'
	set @ReportType = 1
	--*/

	--================================================================================
	-- Procedure internal variables
	--================================================================================
	declare @newrptguid uniqueidentifier = newid()

	--================================================================================
	--Insert Report Register Entry
	--================================================================================
	INSERT INTO [REPREG].[ReportRegister]
		([ReportID]
		,[Name]
		,[Description]
		,[Location]
		,[ReportOwnerID])
     VALUES
		(
			@newrptguid
			, @ReportName
			, @ReportDescription
			, 'SSRS'
			, 1
		)

	--================================================================================
	--Insert Report Register Log Entry
	--================================================================================
	INSERT INTO [REPREG].[ReportStatusLog]
		([ReportID]
		,[ReportStatusID]
		,[ErrorParagraph])
     VALUES
		(
			@newrptguid
			,@ReportType
			,NULL
		)


END


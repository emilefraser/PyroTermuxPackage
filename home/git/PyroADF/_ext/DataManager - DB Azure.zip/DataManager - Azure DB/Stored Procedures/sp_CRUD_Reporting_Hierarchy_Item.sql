﻿
CREATE PROCEDURE [APP].[sp_CRUD_Reporting_Hierarchy_Item](

--all table fields, remove the ones you dont need

@CompanyID int,
@ItemCode varchar(50),
@ItemName varchar(100),
@ParentItemID  int,
@ReportingHierarchySortOrder int,
@ReportingHierarchyTypeID int,

-- required params, please do not remove

@TransactionPerson varchar(80), -- who actioned
@MasterEntity varchar(50), -- from where actioned
@TransactionAction nvarchar(20) = null -- type of transaction, "Create", "Update", "Delete"
)

AS

BEGIN

DECLARE @TransactionDT datetime2(7) = getDate() -- date of transaction
DECLARE @isActive bit -- indicate soft delete
DECLARE @JSONData varchar(max) = null -- to store in audit table
DECLARE @PrimaryKeyID int = null -- primary key value for the table
DECLARE @TableName VARCHAR(50) = 'MASTER.ReportingHierarchyItem' -- table name

--For testing 
DECLARE @count int = (SELECT Count(*) 
					  FROM [MASTER].[ReportingHierarchyItem]
					  WHERE ReportingHierarchyTypeID = @ReportingHierarchyTypeID)

--create record
IF @TransactionAction = 'Create'
	BEGIN
		--check if record exists
		IF EXISTS (SELECT 1 FROM MASTER.ReportingHierarchyItem WHERE  @ItemCode = ItemCode)
			BEGIN
				SELECT 'Already Exist'
			END
		ELSE
			BEGIN
				--Insert new record
				--remove fields not needed, keep CreatedDT and IsActive
				--if parent = 0 then top parent
				IF(@ParentItemID = 0)
					BEGIN
						INSERT INTO MASTER.ReportingHierarchyItem (CompanyID, CreatedDT, ItemCode, ItemName, ReportingHierarchySortOrder, ReportingHierarchyTypeID,  IsActive)
						VALUES(@CompanyID, @TransactionDT, @ItemCode, @ItemName, @ReportingHierarchySortOrder, @ReportingHierarchyTypeID,  1)
					END
				--if parent not null then add to parent above
				ELSE
					BEGIN
						INSERT INTO MASTER.ReportingHierarchyItem (CompanyID, CreatedDT, ItemCode, ItemName, ParentItemID, ReportingHierarchySortOrder, ReportingHierarchyTypeID,  IsActive)
						VALUES(@CompanyID, @TransactionDT, @ItemCode, @ItemName, @ParentItemID, @ReportingHierarchySortOrder, @ReportingHierarchyTypeID,  1)
					END
				--create link entry
				INSERT INTO [MASTER].[LinkReportingHierarchyItemToBKCombination] (ReportingHierarchyItemID)
				VALUES (@@IDENTITY)
			END
	END

--update record
IF @TransactionAction = 'Update'
	BEGIN
		--check if record exists
		IF EXISTS (SELECT 1 FROM MASTER.ReportingHierarchyItem WHERE  @ItemCode = ItemCode)
			BEGIN
				--update existing record
				UPDATE MASTER.ReportingHierarchyItem 
				--remove fields not needed, keep UpdatedDT
				SET
				ReportingHierarchySortOrder = @ReportingHierarchySortOrder,
				UpdatedDT = @TransactionDT
				WHERE ItemCode = @ItemCode
			END
	END

--delete record
IF @TransactionAction = 'Delete'
	BEGIN
		--set record status inactive = 0 (soft delete record)
		Update MASTER.ReportingHierarchyItem 
		SET IsActive = 0, 
		UpdatedDT = @TransactionDT
		WHERE ItemCode = @ItemCode
	END

--capture json data (get primary key value to store in audit table)
SET @PrimaryKeyID = (SELECT ReportingHierarchyItemID FROM MASTER.ReportingHierarchyItem WHERE ItemCode = @ItemCode)
SET @JSONData = (SELECT RHI.ItemCode,
						RHI.ItemName,
						RHI.ReportingHierarchySortOrder,
						RHT.ReportingHierarchyTypeName AS [Reporting Hierarchy Type Name],
						C.CompanyName AS [Company Name],
						RHI.CreatedDT,
						RHI.UpdatedDT,
						RHI.IsActive 
FROM MASTER.ReportingHierarchyItem RHI
LEFT JOIN
MASTER.ReportingHierarchyType RHT
ON 
RHI.ReportingHierarchyTypeID = RHT.ReportingHierarchyTypeID
LEFT JOIN 
[CONFIG].[Company] C
ON
RHI.CompanyID = C.CompanyID
WHERE ItemCode = @ItemCode
FOR JSON PATH, WITHOUT_ARRAY_WRAPPER )

--call sp to store json audit data in table
EXEC [APP].sp_Audit_Trail_Insert @TransactionPerson = @TransactionPerson,
@TransactionAction = @TransactionAction,
@MasterEntity = @MasterEntity,
@JSONData = @JSONData,
@TransactionDT = @TransactionDT,
@PrimaryKeyID = @PrimaryKeyID,
@TableName = @TableName

END

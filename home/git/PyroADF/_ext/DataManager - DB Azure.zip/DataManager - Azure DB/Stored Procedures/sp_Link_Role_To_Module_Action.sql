﻿-- =============================================
-- Author:      <Matthew Falcao Pereira>
-- Create Date: <2019/06/26>
-- Description: <Stored Proc for the assigning and unassigning of Module_Roles >
-- =============================================
CREATE PROCEDURE [APP].[sp_Link_Role_To_Module_Action]
(
   -- Add the parameters for the stored procedure here
   @LinkRoleToModuleActionID int, --primary key of the table
   @ModuleActionID int,
   @RoleIDString varchar(max),
   --Generic Parameters
   @TransactionAction nvarchar(100),
   @TransactionPerson varchar(100),
   @MasterEntity varchar(50)
)
AS
BEGIN
----testing
 --declare @ModuleActionID int = 1
 --  declare @RoleIDString varchar(max) = '13,5,7' 

 Declare @TransactionDT datetime2(7) = getdate()
  --Declare @JSONData varchar(max)

 --Declare temp table for the selected roles from powerapps
 DECLARE @RolesToLink Table 
 (
   RoleID int,
   ModuleActionID int
 )
 --insert into @RolesToLink the roles sent from powerapps
 INSERT INTO @RolesToLink (RoleID, ModuleActionID)
	SELECT value, --value is the split up role id's
	@ModuleActionID --the node to which to assign to
	FROM  DC.tvf_Split_StringWithDelimiter(@RoleIDString, ',') -- call split function

--delete role id 0 created by split function
 DELETE FROM @RolesToLink 
 WHERE RoleID = 0

--select * from @RolesToLink



 If @TransactionAction = 'Assign'
 BEGIN

 --NEW ROLES
 --Declare temp table for the selected roles from powerapps that do not exist in the table yet
 DECLARE @NewRolesToLink Table 
 (
   RoleID int,
   ModuleActionID int,
   CreatedDT datetime2(7),
   IsActive bit
 )
 --populate @NewRolesToLink with the new roles to be added to the table
 INSERT INTO @NewRolesToLink(RoleID, ModuleActionID, CreatedDT, IsActive)
 SELECT rtl.RoleID, rtl.ModuleActionID, @TransactionDT, 1 
 FROM @RolesToLink rtl
 WHERE NOT EXISTS (SELECT * FROM [APP].[LinkRoleToModuleAction] lrtma
					WHERE rtl.RoleID = lrtma.RoleId
					AND rtl.ModuleActionID = lrtma.ModuleActionID) 

--select * from @NewRolesToLink

--insert new roles into linking table
INSERT INTO [APP].[LinkRoleToModuleAction](RoleId, ModuleActionID, CreatedDT, IsActive)
SELECT RoleID, ModuleActionID, @TransactionDT, 1
FROM @NewRolesToLink 


 --UPDATE ROLES
 --Declare temp table for the selected roles from powerapps that already exist in the table and must be updated to isactive 1
 DECLARE @UpdateRolesToLink Table 
 (
   LinkRoleToModuleActionID int,
   RoleID int,
   ModuleActionID int,
   UpdatedDT datetime2(7),
   IsActive bit
 )
 --populate @NewRolesToLink with the new roles to be added to the table
 INSERT INTO @UpdateRolesToLink(LinkRoleToModuleActionID, RoleID, ModuleActionID, UpdatedDT, IsActive)
 SELECT lrtma.LinkRoleToModuleActionID, lrtma.RoleID, lrtma.ModuleActionID, @TransactionDT, 1 
 FROM [APP].[LinkRoleToModuleAction] lrtma
 WHERE EXISTS (SELECT * FROM @RolesToLink rtl
					WHERE rtl.RoleID = lrtma.RoleId
					AND rtl.ModuleActionID = lrtma.ModuleActionID)
					AND lrtma.IsActive = 0 

--select * from @UpdateRolesToLink

UPDATE [APP].[LinkRoleToModuleAction]
	SET IsActive = 1, 
	UpdatedDT = @TransactionDT
	FROM @UpdateRolesToLink urtl
		left join [APP].[LinkRoleToModuleAction] lrtma
		ON urtl.LinkRoleToModuleActionID = lrtma.LinkRoleToModuleActionID
END
 



 If @TransactionAction = 'UnAssign'
 BEGIN
 --UNASSIGN ROLES
 --Declare temp table for the selected roles from powerapps that already exist in the table and must be updated to isactive 1
 DECLARE @RolesToUnLink Table 
 (
   LinkRoleToModuleActionID int,
   RoleID int,
   ModuleActionID int,
   UpdatedDT datetime2(7),
   IsActive bit
 )
 --populate @NewRolesToLink with the new roles to be added to the table
 INSERT INTO @RolesToUnLink(LinkRoleToModuleActionID, RoleID, ModuleActionID, UpdatedDT, IsActive)
 SELECT lrtma.LinkRoleToModuleActionID, lrtma.RoleID, lrtma.ModuleActionID, @TransactionDT, 1 
 FROM [APP].[LinkRoleToModuleAction] lrtma
 WHERE EXISTS (SELECT * FROM @RolesToLink rtl
					WHERE rtl.RoleID = lrtma.RoleId
					AND rtl.ModuleActionID = lrtma.ModuleActionID)
					AND lrtma.IsActive = 1 

--select * from @UpdateRolesToLink

UPDATE [APP].[LinkRoleToModuleAction]
	SET IsActive = 0, 
	UpdatedDT = @TransactionDT
	FROM @RolesToUnLink rtul
		left join [APP].[LinkRoleToModuleAction] lrtma
		ON rtul.LinkRoleToModuleActionID = lrtma.LinkRoleToModuleActionID
 END
END

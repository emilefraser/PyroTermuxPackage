﻿-- =============================================
-- Author:      RJ Oosthuizen
-- Create Date: 30/05/2019
-- Description: Manage hubs
-- =============================================
CREATE PROCEDURE [APP].[sp_CRUD_Hub]
(
	@HubID int, -- primary key of the selected hub
	@HubName varchar(200), -- name of the selected hub
    @TransactionAction nvarchar(20) = null -- type of transaction, "Create", "Delete"
)
AS
BEGIN

	DECLARE @TransactionDT datetime2(7) = getDate() -- date of transaction

	IF @TransactionAction = 'Create'
	
	
		BEGIN
			--insert new hub into hub table
			INSERT INTO [DMOD].[Hub] (HubName, CreatedDT, IsActive)
			VALUES(@HubName, @TransactionDT, 1)
		END

	IF @TransactionAction = 'Update'
	
	
		BEGIN
			--Set InActive
			UPDATE [DMOD].[Hub] 
			SET HubName = @HubName 
			WHERE HubID = @HubID
		END

	IF @TransactionAction = 'Delete'
	
	
		BEGIN
			--Set InActive
			UPDATE [DMOD].[Hub] 
			SET IsActive = 0
			WHERE HubID = @HubID
		END

END

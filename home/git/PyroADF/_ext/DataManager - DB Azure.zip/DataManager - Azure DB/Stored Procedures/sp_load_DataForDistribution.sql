﻿-- =============================================
-- Author:      Karl Dinkelmann
-- Create Date: 25 Oct 2018
-- Description: Loads data for distribution to on-prem reporting environments.
-- =============================================
CREATE PROCEDURE [INTEGRATION].sp_load_DataForDistribution
	--TODO Do we need to pass in something to know what we're transferring?
AS
/*
Pseudocode:
- Loop through a list of tables for distribution
- Compare the source view/table to the copy of the table stored in the cloud
- Any changes go to DataDistributionBatchData to be copied via ADF to on-prem

- First do manually with [LOCALACCESS].ReportingHierarchyAccess
	- What is the source view? [ACCESS].[vw_ReportingHierarchyAccess]

*/

/* Testing
SELECT * FROM INTEGRATION.DataDistributionBatch
SELECT * FROM [LOCALACCESS].[ReportingHierarchyAccess]
TRUNCATE TABLE INTEGRATION.DataDistributionBatch
TRUNCATE TABLE [LOCALACCESS].[ReportingHierarchyAccess]
*/

DECLARE @BatchID INT
DECLARE @Delimiter VARCHAR(1) = '|'

--Create a temp table copy of the source view, with a HashKey column
IF OBJECT_ID('tempdb..#Source') IS NOT NULL
    DROP TABLE #Source
CREATE TABLE #Source (
	[HashKey] [varchar](40) NOT NULL,
	--TODO Make field list dynamic based on input
	[ReportingHierarchyTypeCode] [varchar](10) NULL,
	[ReportingHierarchyTypeName] [varchar](100) NULL,
	[ItemCode] [varchar](50) NULL,
	[ItemName] [varchar](100) NULL,
	[ParentItemCode] [varchar](50) NULL,
	[ParentItemName] [varchar](100) NULL,
	[BusinessKey] [varchar](50) NULL,
	[LinkID] [int] NULL,
	[DataCatalogFieldID] [int] NULL,
	[FieldName] [varchar](1000) NULL,
	[IsDefaultHierarchyItem] [bit] NULL,
	[DomainAccount] [varchar](200) NULL
	--End of dynamic field list
)

INSERT INTO #Source (
	   [HashKey]
	  --TODO Make field list dynamic based on input
	  ,[ReportingHierarchyTypeCode]
      ,[ReportingHierarchyTypeName]
      ,[ItemCode]
      ,[ItemName]
      ,[ParentItemCode]
      ,[ParentItemName]
      ,[BusinessKey]
      ,[LinkID]
      ,[DataCatalogFieldID]
      ,[FieldName]
      ,[IsDefaultHierarchyItem]
      ,[DomainAccount]
	  --End of dynamic field list
)
SELECT HASHBYTES('SHA1',
		   --TODO Make hash key calculation dynamic based on input
		   ISNULL([ReportingHierarchyTypeCode], 'NULL') + @Delimiter +
		   ISNULL([ReportingHierarchyTypeName], 'NULL') + @Delimiter +
		   ISNULL([ItemCode], 'NULL') + @Delimiter +
		   ISNULL([ItemName], 'NULL') + @Delimiter +
		   ISNULL([ParentItemCode], 'NULL') + @Delimiter +
		   ISNULL([ParentItemName], 'NULL') + @Delimiter +
		   ISNULL([BusinessKey], 'NULL') + @Delimiter +
		   CONVERT(VARCHAR, ISNULL([LinkID], -9)) + @Delimiter +
		   CONVERT(VARCHAR, ISNULL([DataCatalogFieldID], -9)) + @Delimiter +
		   ISNULL([FieldName], 'NULL') + @Delimiter +
		   ISNULL(CONVERT(VARCHAR, [IsDefaultHierarchyItem]), 'NULL') + @Delimiter +
		   ISNULL([DomainAccount], 'NULL')
	   )
	  --TODO Make field list dynamic based on input
	  ,[ReportingHierarchyTypeCode]
      ,[ReportingHierarchyTypeName]
      ,[ItemCode]
      ,[ItemName]
      ,[ParentItemCode]
      ,[ParentItemName]
      ,[BusinessKey]
      ,[LinkID]
      ,[DataCatalogFieldID]
      ,[FieldName]
      ,[IsDefaultHierarchyItem]
      ,[DomainAccount]
	  --End of dynamic field list
  FROM [ACCESS].[vw_ReportingHierarchyAccess] [source]

--Compare [LOCALACCESS].ReportingHierarchyAccess with the source table
IF OBJECT_ID('tempdb..#DataVariancesToInsert') IS NOT NULL
    DROP TABLE #DataVariancesToInsert
CREATE TABLE #DataVariancesToInsert (
	[HashKey] [varchar](40) NOT NULL,
	--TODO Make field list dynamic based on input
	[ReportingHierarchyTypeCode] [varchar](10) NULL,
	[ReportingHierarchyTypeName] [varchar](100) NOT NULL,
	[ItemCode] [varchar](50) NULL,
	[ItemName] [varchar](100) NULL,
	[ParentItemCode] [varchar](50) NULL,
	[ParentItemName] [varchar](100) NULL,
	[BusinessKey] [varchar](50) NULL,
	[LinkID] [int] NULL,
	[DataCatalogFieldID] [int] NULL,
	[FieldName] [varchar](1000) NULL,
	[IsDefaultHierarchyItem] [bit] NULL,
	[DomainAccount] [varchar](200) NULL
	--End of dynamic field list
)

--Create table
IF OBJECT_ID('tempdb..#DataVariancesToDelete') IS NOT NULL
    DROP TABLE #DataVariancesToDelete
CREATE TABLE #DataVariancesToDelete (
	[HashKey] [varchar](40) NOT NULL
)

--Get new items to insert
INSERT INTO #DataVariancesToInsert (
	   [HashKey]
	  --TODO Make field list dynamic based on input
	  ,[ReportingHierarchyTypeCode]
      ,[ReportingHierarchyTypeName]
      ,[ItemCode]
      ,[ItemName]
      ,[ParentItemCode]
      ,[ParentItemName]
      ,[BusinessKey]
      ,[LinkID]
      ,[DataCatalogFieldID]
      ,[FieldName]
      ,[IsDefaultHierarchyItem]
      ,[DomainAccount]
	  --End of dynamic field list
)
SELECT [HashKey]
	  --TODO Make field list dynamic based on input
	  ,[ReportingHierarchyTypeCode]
      ,[ReportingHierarchyTypeName]
      ,[ItemCode]
      ,[ItemName]
      ,[ParentItemCode]
      ,[ParentItemName]
      ,[BusinessKey]
      ,[LinkID]
      ,[DataCatalogFieldID]
      ,[FieldName]
      ,[IsDefaultHierarchyItem]
      ,[DomainAccount]
	  --End of dynamic field list
  FROM #Source [source]
 WHERE NOT EXISTS (SELECT 1
					 FROM [LOCALACCESS].ReportingHierarchyAccess [target]
					WHERE [target].[HashKey] = [source].[HashKey]
					)

--Get items to delete (doesn’t exist at source)
INSERT INTO #DataVariancesToDelete (
	   [HashKey]
	)
SELECT [HashKey]
  FROM [LOCALACCESS].ReportingHierarchyAccess [target]
 WHERE NOT EXISTS (SELECT 1
					 FROM #Source [source]
					WHERE [target].[HashKey] = [source].[HashKey]
					)


IF ((SELECT COUNT(1) FROM #DataVariancesToInsert) > 0) OR ((SELECT COUNT(1) FROM #DataVariancesToDelete) > 0)
BEGIN

	--Convert Insert data variances to JSON
	DECLARE @InsertPayload VARCHAR(MAX)
	SET @InsertPayload = (
		SELECT [HashKey]
			  --TODO Make field list dynamic based on input
			  ,[ReportingHierarchyTypeCode]
			  ,[ReportingHierarchyTypeName]
			  ,[ItemCode]
			  ,[ItemName]
			  ,[ParentItemCode]
			  ,[ParentItemName]
			  ,[BusinessKey]
			  ,[LinkID]
			  ,[DataCatalogFieldID]
			  ,[FieldName]
			  ,[IsDefaultHierarchyItem]
			  ,[DomainAccount]
			  --End of dynamic field list
		  FROM #DataVariancesToInsert
		FOR JSON AUTO
		)

	--Convert Delete data variances to JSON
	DECLARE @DeletePayload VARCHAR(MAX)
	SET @DeletePayload = (
		SELECT [HashKey]
		  FROM #DataVariancesToDelete
		FOR JSON AUTO
		)

	--Create the batch for distribution
	INSERT INTO [INTEGRATION].[DataDistributionBatch] (
		DataEntityDDL,
		InsertPayload,
		DeletePayload,
		CreatedDT
	)
	VALUES (
		'', --TODO Insert DDL
		@InsertPayload,
		@DeletePayload,
		GETDATE()
	)

	--Load the data variances into the LOCALACCESS table

	--Delete
	DELETE FROM [LOCALACCESS].ReportingHierarchyAccess
	WHERE HashKey IN (SELECT HashKey
					    FROM #DataVariancesToDelete dv)

	--Insert
	INSERT INTO [LOCALACCESS].ReportingHierarchyAccess (
		   [HashKey]
		  --TODO Make field list dynamic based on input
		  ,[ReportingHierarchyTypeCode]
		  ,[ReportingHierarchyTypeName]
		  ,[ItemCode]
		  ,[ItemName]
		  ,[ParentItemCode]
		  ,[ParentItemName]
		  ,[BusinessKey]
		  ,[LinkID]
		  ,[DataCatalogFieldID]
		  ,[FieldName]
		  ,[IsDefaultHierarchyItem]
		  ,[DomainAccount]
		  --End of dynamic field list
	)
	SELECT [HashKey]
		  --TODO Make field list dynamic based on input
		  ,[ReportingHierarchyTypeCode]
		  ,[ReportingHierarchyTypeName]
		  ,[ItemCode]
		  ,[ItemName]
		  ,[ParentItemCode]
		  ,[ParentItemName]
		  ,[BusinessKey]
		  ,[LinkID]
		  ,[DataCatalogFieldID]
		  ,[FieldName]
		  ,[IsDefaultHierarchyItem]
		  ,[DomainAccount]
		  --End of dynamic field list
	  FROM #DataVariancesToInsert


END --Count of #DataVariances


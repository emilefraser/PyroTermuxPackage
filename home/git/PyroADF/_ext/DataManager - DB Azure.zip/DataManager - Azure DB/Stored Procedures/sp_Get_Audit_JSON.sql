﻿CREATE PROCEDURE [APP].[sp_Get_Audit_JSON] (
	@TableName varchar(40) = null, --identifier table name to capture record
    @TableBusinessKeyID int = null, --indentifier value to capture record (Primary key)
    @AppName VARCHAR(50) = null -- appname from which the record is captured
)
AS
BEGIN
	--TESTING
	--DECLARE @TableName varchar(40) = 'ETL.LoadConfig'
    --DECLARE @TableBusinessKeyID int = 136
    --DECLARE @AppName VARCHAR(50) = 'ODS Loader'

    --declare temp table to store multiple results of audit data
    DECLARE @AuditTable Table (
		AuditTrailID INT, -- audit trail primary key id, used later to order by for newest first
		AuditDataRecord VARCHAR(MAX) -- json data retrieved will be stored here
    )

    --get jsonfrom APP, TABLE and PRIMARY KEY
    INSERT INTO @AuditTable(AuditTrailID, AuditDataRecord)
        SELECT AuditTrailID, AuditData
        FROM AUDIT.AuditTrail
        WHERE MasterEntity = @AppName 
        AND TableName = @TableName 
        AND PrimaryKeyID = @TableBusinessKeyID

    --retrieve results from temp table
    SELECT AuditDataRecord FROM @AuditTable
	ORDER BY AuditTrailID DESC --get newest listed first

END

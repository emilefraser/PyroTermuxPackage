﻿/*
Proc for populating loadconfigs

SELECT * FROM DMOD.LoadType

SELECT * FROM DMOD.LoadConfig
WHERE LoadTypeID = 2


SELECT * FROM DMOD.LoadConfig
WHERE LoadTypeID = 3

UPDATE DMOD.LoadConfig
SET LoadTypeID = 7
WHERE LoadTypeID = 2


UPDATE DMOD.LoadConfig
SET LoadTypeID = 8
WHERE LoadTypeID = 3


EXEC DMOD.sp_load_LoadConfig 
            @LoadConfigID = JNULL
		   ,@LoadTypeID = 2 -- Static Load Template Type for Load
           ,@SourceDataEntityID = 12455 -- Source Data Entity
           ,@TargetDataEntityID = 40358 -- Target Data Entity
           ,@IsSetForReloadOnNextRun = 0 -- Not Used at the Moment
		   ,@IsActive=1
*/
CREATE PROCEDURE [DMOD].[sp_insert_LoadConfig] 
	@LoadConfigID INT = NULL
,	@LoadTypeID INT NULL
,	@SourceDataEntityID int = NULL
,	@TargetDataEntityID int = NULL
,	@IsSetForReloadOnNextRun bit = 0
,	@OffsetDays INT = NULL
,	@IsActive BIT = 1

AS 

	DECLARE @CreatedDT DATETIME2(7)  = (SELECT GETDATE())
	DECLARE @ModifiedDT DATETIME2(7)  = (SELECT GETDATE())
	
	-- If LoadTypeID IS NOT passed, get the LoadTypeID from the table based on LoadTypeCode
	IF(@LoadConfigID IS NULL)
	BEGIN

		SET @LoadConfigID =
		(
			SELECT 
				lc.LoadConfigID 
			FROM 
				DMOD.LoadConfig AS lc
			WHERE
				lc.LoadTypeID = @LoadTypeID
			AND
				lc.SourceDataEntityID = @SourceDataEntityID
			AND
				lc.TargetDataEntityID = @TargetDataEntityID
		)

	END

	IF(@LoadConfigID IS NOT NULL) -- If LoadConfig IS PASSED OR it already EXISTS based on LoadTypeID, SourceDataEntity, TargetData THEN UPDATE
	BEGIN

		UPDATE 
			lc
		SET
			lc.LoadTypeID = COALESCE(@LoadTypeID, lc.LoadTypeID)
		,	lc.SourceDataEntityID = COALESCE(@SourceDataEntityID, lc.SourceDataEntityID)
		,	lc.TargetDataEntityID = COALESCE(@TargetDataEntityID, lc.TargetDataEntityID)
		,	lc.IsSetForReloadOnNextRun = COALESCE(@IsSetForReloadOnNextRun, lc.IsSetForReloadOnNextRun)
		,	lc.OffsetDays = COALESCE(@OffsetDays, lc.OffsetDays)		
		,	lc.ModifiedDT = COALESCE(@ModifiedDT, lc.ModifiedDT)
		,	lc.IsActive = COALESCE(@IsActive, lc.IsActive)
		FROM 
			DMOD.LoadConfig AS lc
		WHERE
			lc.LoadConfigID = @LoadConfigID

	END
	ELSE
	BEGIN

		INSERT INTO [DMOD].[LoadConfig]
			   ([LoadTypeID]
			   ,[SourceDataEntityID]
			   ,[TargetDataEntityID]
			   ,[IsSetForReloadOnNextRun]
			   ,[OffsetDays]
			   ,[CreatedDT]
			   ,[IsActive])
		 VALUES
			   (
				@LoadTypeID
			   ,@SourceDataEntityID
			   ,@TargetDataEntityID
			   ,@IsSetForReloadOnNextRun
			   ,@OffsetDays
			   ,@CreatedDT
			   ,@IsActive
			   )

	END

﻿-- =============================================
-- Author:      <Matthew Falcao Pereira>
-- Create Date: <2019/06/27>
-- Description: <This stored proc will create links between >
-- =============================================
CREATE PROCEDURE [APP].[sp_Link_Person_With_Role_To_Data_Domain]
(
    --Parameters for the stored proc 
	@LinkPersonWithRoleToDataDomainID int,
    @PersonAccessControlIDString varchar (max),
	@RoleID int,
	@DataDomainID int,

	--Generic Parameters for stored proc
	@TransactionPerson varchar(max),	
	@TransactionAction nvarchar(max),	
	@MasterEntity varchar(max)

)
AS
BEGIN
 ----testing
 --Declare @PersonAccessControlID int = 1
 --declare @PersonAccessControlIDString varchar(max) = '1018,' 
 --Declare @DataDomainID int = 19
 --Declare @RoleID int = 1
 --declare @TransactionAction varchar(20) = 'UnAssign'

 --Declare @TransactionAction nvarchar(max)
 Declare @TransactionDT datetime2(7) = getdate()
 --Declare @JSONData varchar(max)

 --Declare temp table for the selected people from powerapps
 DECLARE @PeopleToLink Table 
 (
   PersonAccessControlID int,
   RoleID int,
   DataDomainID int
 )

 --insert into @PeopleToLink the people sent from powerapps
 INSERT INTO @PeopleToLink (PersonAccessControlID,RoleID,DataDomainID)
	SELECT 
	value, --value is the split up Person id's
	@RoleID,
	@DataDomainID--the node to which to assign to
	FROM  DC.tvf_Split_StringWithDelimiter(@PersonAccessControlIDString, ',') -- call split function

--delete role id 0 created by split function
 DELETE FROM @PeopleToLink 
 WHERE PersonAccessControlID = 0

--select * from @PeopleToLink
   
If @TransactionAction = 'Assign'
 BEGIN

 --NEW People
 --Declare temp table for the selected people from powerapps that do not exist in the table yet
 DECLARE @NewPeopleToLink Table 
  (
   RoleID int,
   DataDomainID int,
   PersonAccessControlID int,
   CreatedDT datetime2(7),
   IsActive bit
  )

--populate @NewRolesToLink with the new roles to be added to the table
INSERT INTO @NewPeopleToLink(RoleID,DataDomainID,PersonAccessControlID,CreatedDT,IsActive)
SELECT ptl.RoleID, ptl.DataDomainID,ptl.PersonAccessControlID, @TransactionDT, 1 
FROM @PeopleToLink ptl
WHERE NOT EXISTS (SELECT * FROM [GOV].[LinkPersonWithRoleToDataDomain] lpwrtdd
	 WHERE ptl.RoleID = lpwrtdd.RoleId
	 AND ptl.DataDomainID = lpwrtdd.DataDomainID
	 AND ptl.PersonAccessControlID = lpwrtdd.PersonAccessControlListID)

--select * from @NewPeopleToLink

--insert new roles into linking table
INSERT INTO [GOV].[LinkPersonWithRoleToDataDomain](RoleId, DataDomainID , PersonAccessControlListID , CreatedDT, IsActive)
SELECT RoleID, DataDomainID, PersonAccessControlID, @TransactionDT, 1
FROM @NewPeopleToLink 



--UPDATE ROLES
 --Declare temp table for the selected roles from powerapps that already exist in the table and must be updated to isactive 1
 DECLARE @UpdatePeopleToLink Table 
 (
   LinkPersonWithRoleToDataDomainID int,
   PersonAccesControlID int,
   RoleID int,
   DataDomainID int,
   UpdatedDT datetime2(7),
   IsActive bit
 )

 --populate @NewRolesToLink with the new roles to be added to the table
 INSERT INTO @UpdatePeopleToLink(LinkPersonWithRoleToDataDomainID,RoleID,DataDomainID,PersonAccesControlID,UpdatedDT,IsActive)
 SELECT lpwrtdd.[Link Person With Role To Data Domain ID], lpwrtdd.[Role ID], lpwrtdd.[Data Domain ID],lpwrtdd.[Person Access Control List ID], @TransactionDT, 1 
 FROM [GOV].[vw_mat_LinkPersonWithRoleToDataDomain] lpwrtdd
 WHERE EXISTS (SELECT * FROM @PeopleToLink ptl
					WHERE ptl.RoleID = lpwrtdd.[Role ID]
					AND ptl.DataDomainID = lpwrtdd.[Data Domain ID]
					AND ptl.PersonAccessControlID = lpwrtdd.[Person Access Control List ID])
					AND lpwrtdd.[Is Active] = 0 

--select * from @UpdatePeopleToLink

UPDATE [GOV].[LinkPersonWithRoleToDataDomain]
	SET IsActive = 1, 
	UpdatedDT = @TransactionDT
	FROM @UpdatePeopleToLink urtl
		left join [GOV].[LinkPersonWithRoleToDataDomain] lpwrtdd
		ON urtl.LinkPersonWithRoleToDataDomainID = lpwrtdd.LinkPersonWithRoleToDataDomainID
END



 If @TransactionAction = 'UnAssign'
 BEGIN
 --UNASSIGN ROLES
 --Declare temp table for the selected roles from powerapps that already exist in the table and must be updated to isactive 1
 DECLARE @PeopleToUnLink Table 
 (
   LinkPersonWithRoleToDataDomainID int,
   PersonAccessControlID int,
   RoleID int,
   DataDomainID int,
   UpdatedDT datetime2(7),
   IsActive bit
 )
 --populate @NewPeopleToLink with the new People to be added to the table
 INSERT INTO @PeopleToUnLink(LinkPersonWithRoleToDataDomainID, RoleID, DataDomainID,PersonAccessControlID,UpdatedDT,IsActive)
 SELECT lpwrtdd.LinkPersonWithRoleToDataDomainID, lpwrtdd.RoleID,lpwrtdd.DataDomainID,lpwrtdd.PersonAccessControlListID, @TransactionDT, 1 
 FROM [GOV].[LinkPersonWithRoleToDataDomain] lpwrtdd
 WHERE EXISTS (SELECT * FROM @PeopleToLink ptl
					WHERE ptl.RoleID = lpwrtdd.RoleId
					AND ptl.DataDomainID = lpwrtdd.DataDomainID
					AND ptl.PersonAccessControlID = lpwrtdd.PersonAccessControlListID)
					AND lpwrtdd.IsActive = 1 

select * from @PeopleToUnLink

--testing
--end

UPDATE [GOV].[LinkPersonWithRoleToDataDomain]
	SET IsActive = 0, 
	UpdatedDT = @TransactionDT
	FROM @PeopleToUnLink rtul
		left join [GOV].[LinkPersonWithRoleToDataDomain] lrtma
		ON rtul.LinkPersonWithRoleToDataDomainID = lrtma.LinkPersonWithRoleToDataDomainID
END
END

﻿
-- =============================================
-- Author:		Frans Germishuizen (AccTech)
-- Create date: 2018-09-11
-- Description:	Report Status for report status indicator
-- =============================================
CREATE PROCEDURE [REPREG].[sp_rpt_ReportInfo] 
	@ReportID as varchar(100)
AS

	--Variable Test Bench
	/*
	declare @ReportID as uniqueidentifier
	set		@ReportID = '8B879A08-310D-4314-A6A2-78179906021B'
	--*/

	select	@ReportID = CONVERT(uniqueidentifier, @ReportID)

	--Get Report Status
	select	 rr.ReportID
			, rr.[Name]
			, rr.[Description]
			, ISNULL(rlog.ErrorParagraph, rstat.DefaultErrorParagraph) as ErrorParagraph
			, rstat.ReportStatus
			, rstat.ReportStatusIndicator
			, '2018-09-10' as DataLastRefreshedOn
	from	REPREG.ReportRegister rr
		left join REPREG.ReportStatusLog rlog on rr.ReportID = rlog.ReportID
		left join REPREG.ReportStatus rstat on rstat.ReportStatusID = rlog.ReportStatusID
	where	rr.ReportID = @ReportID



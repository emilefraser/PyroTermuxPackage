﻿
--By Wium Swart 21 may 2019

CREATE PROCEDURE [FS].[sp_load_LoggingSteps]
@MaxID INT
AS

INSERT INTO FS.Logging_Steps
			( LogID
			 ,StepNo
			 ,Platform
			 ,Action
			 ,StartDT
			 ,FinishDT
			 ,Duration
			 ,IsError
			 )
SELECT        LogID
			 ,StepNo
			 ,Platform
			 ,Action
			 ,StartDT
			 ,FinishDT
			 ,ABS(Duration)
			 ,IsError 
			 FROM FS.Ingress_Logging_Steps
			 WHERE LogID = @MaxID



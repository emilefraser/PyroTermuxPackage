﻿-- =============================================
-- Author:      Francois Senekal
-- Create Date: 2019.06.06
-- Description: Starts Crawler Logging
-- =============================================
CREATE PROCEDURE FS.LogCrawlerStart

AS
BEGIN
INSERT INTO FS.Logging_Header( [LogTypeID]
							  ,[StartDT]
							  ,[Status]
							  ,[Description]
							  )
			VALUES (4,GETDATE(),'Pending','DC Crawler has started')

INSERT INTO FS.Logging_Steps ( LogID
							  ,StepNo
							  ,Platform
							  ,Action
							  ,StartDT
							  ,FinishDT
							  ,Duration
							  ,IsError
							  )
			VALUES ((SELECT MAX(LOGID) 
					 FROM FS.Logging_Header 
					 WHERE Description = 'DC Crawler has started')
					 ,1,'ADF','ADF is copying the InsancesToLoad to OnPrem',GETDATE(),NULL,NULL,0)

			
END

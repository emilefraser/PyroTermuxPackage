﻿

-- ====================================================================================================
-- Author:      Francois Senekal
-- Create Date: 24 January 2019
-- Description: Creates Satelite tables in DC and auto-creates relationships to Source/SAT
-- ====================================================================================================
-- Version Control
-- ====================================================================================================
/*
	Date		| Person				| Notes
	---------------------------------------------------------------------------------------------------
	2019-02-20	| Frans Germishuizen	| Reviewed and approved --> to be tested

*/
-- ====================================================================================================

CREATE PROCEDURE [DC].[sp_CreateSatelliteTableInDC_FS_TOBEDELETED] AS

/*--====================================================================================================
Test Case 1 :
1. Set @TargetSATDatabaseID to one that doesn't exist (9999)
2. Run the Proc
3. Check if new entries where created (TODO: Change CreatedDT to date proc ran)
	SELECT * FROM DC.[SCHEMA] WHERE CREATEDDT > '2019/01/31'
	SELECT * FROM DC.DATAENTITY WHERE CREATEDDT > '2019/01/31'
	SELECT * FROM DC.FIELD WHERE CREATEDDT > '2019/01/31'
	SELECT * FROM DC.FIELDRELATION WHERE CREATEDDT > '2019/01/31'
4. Delete test entries !!!(BEWARE OF DELETE STATEMENTS)!!!

Test Case 2 :
1. Set @TargetSATDatabaseID to one that already exists 
2. Run the Proc
3. Check if no new entries where created (TODO: Change CreatedDT to date proc ran)
	SELECT * FROM DC.[SCHEMA] WHERE CREATEDDT > '2019/01/31'
	SELECT * FROM DC.DATAENTITY WHERE CREATEDDT > '2019/01/31'
	SELECT * FROM DC.FIELD WHERE CREATEDDT > '2019/01/31'
	SELECT * FROM DC.FIELDRELATION WHERE CREATEDDT > '2019/01/31'
--====================================================================================================*/

--====================================================================================================
--	All Variables Declared Here
--====================================================================================================

DECLARE	@HubID INT
SET		@HubID = 2

DECLARE @TargetSATDatabaseID INT
SET		@TargetSATDatabaseID = 24

DECLARE @InitialSourceDataEntityID INT
SET		@InitialSourceDataEntityID = (	
										SELECT	SourceDataEntityID 
										FROM	[DMOD].[Hub_Working] 
										WHERE	HubID = @HubID
									 )

DECLARE @InitialSourceDataEntityName VARCHAR(50)
SET		@InitialSourceDataEntityName =	(
											SELECT	[DC].[udf_ConvertStringToCamelCase](DataEntityName) 
											FROM	dc.dataentity 
											WHERE	DataEntityID = @InitialSourceDataEntityID
										)
DECLARE @TargetSchemaID INT
DECLARE @TargetSchemaName VARCHAR(20)
--SET @TargetSchemaName = (SELECT schemaname FROM dc.[schema] WHERE databaseid = @TargetSATDatabaseID)
SET @TargetSchemaName = 'raw'



--====================================================================================================
--	Insert the SAT in TempTable
--====================================================================================================

DECLARE @SatDataEntity TABLE 
	   (
			HubID INT
		   , SatelliteFieldDataVelocityTypeID INT
		   , SatelliteDataEntityName VARCHAR(100)
		   , SatDataEntityID INT
	    )

INSERT INTO @SatDataEntity 
	(
		HubID
		, SatelliteFieldDataVelocityTypeID
		, SatelliteDataEntityName
		, SatDataEntityID
	)
SELECT DISTINCT hub.HubID
				, sat.SatelliteFieldDataVelocityTypeID
				, 'SAT_' 
				+ [DC].[udf_ConvertStringToCamelCase]([DC].[udf_GetDataEntityNameForDataEntityID](hub.SourceDataEntityID))
				+ '_'
				+ [DC].[udf_get_DataEntity_SourceSystemAbbreviation](hub.SourceDataEntityID)
				+ '_'
				+ vtype.SatelliteFieldDataVelocityTypeCode AS SatelliteDataEntityName
				, '' AS SatDataEntityID
FROM [DMOD].[SatelliteFieldDataVelocity_Working] sat
	INNER JOIN DMOD.Hub_Working hub ON 
		sat.HubID = hub.HubID
	INNER JOIN DMOD.SatelliteFieldDataVelocityType vtype ON 
		vtype.SatelliteFieldDataVelocityTypeID = sat.SatelliteFieldDataVelocityTypeID
WHERE	hub.HubID = @HubID
select * from @SatDataEntity
--====================================================================================================
--	Insert the Target Schema in DC (if it does not exist) - the SAT db schema is equal to the source system abbreviation,
--	accoarding to the naming convention
--====================================================================================================

-- Check if the schema already exists in the DC
SET @TargetSchemaID =	(
							SELECT	TOP 1 sc.SchemaID
							FROM	DC.[Schema] sc
							WHERE	DatabaseID = @TargetSATDatabaseID
								AND SchemaName = @TargetSchemaName
						 )

-- If the schema does not exists, create it in the DC.Schema table
IF @TargetSchemaID IS NULL 
	BEGIN
		INSERT INTO DC.[Schema] 
			(
				SchemaName
				, DatabaseID
				, DBSchemaID
				, CreatedDT
			)
		SELECT	@TargetSchemaName
				, @TargetSATDatabaseID
				, NULL
				, GETDATE()

		-- Get newly inserted SchemaID
		SET @TargetSchemaID = @@IDENTITY
	END
--====================================================================================================
--	Copy the structure of the Source Data Entity into DataEntity table in DC (if it does not exist)
--
--	Correct fields?  
--		Add IsActive field
--====================================================================================================

-- Check if the Data Entity for the Satellites exists, otherwise insert		
INSERT INTO DC.DataEntity
	(
		DataEntityName
		, SchemaID
		, CreatedDT
	)
SELECT	SatelliteDataEntityName
		, @TargetSchemaID
		, GETDATE()
FROM	@SatDataEntity
WHERE NOT EXISTS
	(
		SELECT	1
		FROM	@SatDataEntity sat
			INNER JOIN DC.DataEntity de ON
				sat.SatelliteDataEntityName = de.DataEntityName
					AND de.SchemaID = @TargetSchemaID
	)

--====================================================================================================
--	Copy the structure of the Source Data Entity into Fields table in DC (if it does not exist) and
--	insert the additional SAT Fields (if it does not exist) 
--====================================================================================================
UPDATE	sat
SET		SatDataEntityID = de.DataEntityID
FROM	@SatDataEntity sat
	INNER JOIN DC.DataEntity de ON sat.SatelliteDataEntityName = de.DataEntityName
		AND de.SchemaID = @TargetSchemaID
select * from @SatDataEntity
DECLARE @Fields TABLE
	(
		[SatFieldID] [int] NULL,
		[FieldOriginalID] [int] NOT NULL,
		[FieldName] [varchar](1000) NOT NULL,
		[FieldOriginalName] [varchar](100) NOT NULL,
		[FieldFriendlyName] [varchar](100) NULL,
		[DataType] [varchar](500) NULL,
		[MaxLength] [int] NULL,
		[Precision] [int] NULL,
		[Scale] [int] NULL,
		[DataEntityID] [int] NULL,
		[CreatedDT] [datetime2](7) NULL,
		[IsActive] [bit] NULL,
		[FieldSortOrder] [int] NULL
	)

INSERT @Fields VALUES
		(NULL,0,'HK_' + @InitialSourceDataEntityName,'HK_' + @InitialSourceDataEntityName,'','varchar',40,0,0,-1, GETDATE(), 1, 1),
		(NULL,0,'LoadDT','LoadDT','','datetime2',8,27,7,-1, GETDATE(), 1, 2),
		(NULL,0,'LoadEndDT','LoadEndDT','','datetime2',8,27,7,-1, GETDATE(), 1, 3),
		(NULL,0,'RecSrcDataEntityID','RecSrcDataEntityID','','int',4,0,0,-1, GETDATE(), 1, 4),
		(NULL,0,'HashDiff','HashDiff','','varchar',40,0,0,-1, GETDATE(), 1, 5)

INSERT INTO @Fields 
	(
		[SatFieldID]
		, [FieldOriginalID]
		, [FieldName]
		, [FieldOriginalName]
		, [FieldFriendlyName]
		, [DataType]
		, [MAXLENGTH]
		, [Precision]
		, [Scale]
		, [DataEntityID]
		, [CreatedDT]
		, [IsActive]
		, [FieldSortOrder]
	)
SELECT  NULL
		, 0
		,f.FieldName
		,f.FieldName AS FieldOriginalName
		,'' AS FieldFriendlyName
		,f.DataType
		,f.[MAXLENGTH]
		,f.[Precision]
		,f.[Scale]
		,sat.[SatDataEntityID]
		,GETDATE()
		,[IsActive]
		,[FieldSortOrder]			
FROM @Fields f
CROSS JOIN @SatDataEntity sat
----WHERE NOT EXISTS (
----					SELECT	1
----					FROM	DC.FIELD f1
----					WHERE	f1.FieldName = f.FieldName
----						AND sat.SatDataEntityID = f1.DataEntityID		  
----				  )

UNION ALL

SELECT	NULL
		, f.FieldID
		, ISNULL(satfield.SatelliteColumnName , f.FieldName) AS FieldName
		, f.FieldName as FieldOriginalName
		, satfield.SatelliteColumnName AS FieldFriendlyName
		, f.DataType
		, f.MAXLENGTH
		, f.PRECISION
		, f.Scale
		, de.DataEntityID AS DataEntityID
		, GETDATE()
		--, f.FieldSortOrder
		, 1
		, ROW_NUMBER() OVER (PARTITION BY sat.[SatDataEntityID] ORDER BY ISNULL(satfield.SatelliteColumnName , f.FieldName)) +5
FROM	@SatDataEntity sat
	INNER JOIN [DMOD].[SatelliteFieldDataVelocity_Working] satfield ON 
		sat.HubID = satfield.HubID 
		AND	satfield.SatelliteFieldDataVelocityTypeID = sat.SatelliteFieldDataVelocityTypeID
	INNER JOIN DC.Field f ON 
		f.FieldID = satfield.FieldID
	INNER JOIN DC.DataEntity de ON
		de.DataEntityID = sat.SatDataEntityID
----WHERE NOT EXISTS (
----					SELECT	1
----					FROM	DC.FIELD f1
----					WHERE	f1.FieldName = f.FieldName
----						AND sat.SatDataEntityID = f1.DataEntityID		  
----				  )

-- Remove template fields only used to facilitate the cross join
delete 
from	@Fields
where	DataEntityID = -1

-- Create field list in the DC
INSERT INTO [DC].[Field] 
	(
		[FieldName]
		,[DataType]
		,[MAXLENGTH]
		,[Precision]
		,[Scale]
		,[DataEntityID]
		,[CreatedDT]
		,[IsActive]
		,[FieldSortOrder] 
	)
select	[FieldName] 
		, [DataType] 
		, [MaxLength]
		, [Precision]
		, [Scale] 
		, [DataEntityID] 
		, [CreatedDT] 
		, [IsActive] 
		, [FieldSortOrder]
from	@Fields f
WHERE NOT EXISTS (
					SELECT	1
					FROM	DC.FIELD f1
					WHERE	f1.FieldName = f.FieldName
						AND f.DataEntityID = f1.DataEntityID		  
				  )
order by f.DataEntityID, f.FieldSortOrder
select * from @Fields
-- Get the new field id of the satallite fields (the descriptive information fields)
-- This does not get the DataVault added fields FieldID's (HK, LoadDT, LoadEndDT, RecSrcDataEntityID, HashDiff)
update	@Fields
set		SatFieldID = f.FieldID
from	DC.Field f
	inner join @Fields satf on f.DataEntityID = satf.DataEntityID
		and f.FieldName = satf.FieldOriginalName
		or f.FieldName = satf.FieldFriendlyName
	inner join @SatDataEntity sde on sde.SatDataEntityID = f.DataEntityID

INSERT INTO DC.FieldRelation
(SourceFieldID
,TargetFieldID
,FieldRelationTypeID
,CreatedDT)
-- Generate the STT mapping for the HashDiff columns for each DataEntityID
select	[DC].[udf_get_StageLevelBKFieldID_FromSourceBKFieldID] (sat_hashsource.FieldOriginalID, sat_hash.SatelliteFieldDataVelocityTypeID) AS SourceFieldID
		, sat_hash.SatFieldID AS TargetFieldID
		, 2 AS FieldRelationType -- STT Mapping type hard coded
		,GETDATE()
from	
		(	select	*
			from	@Fields f
			inner join @SatDataEntity sat ON
			sat.SatDataEntityID = f.DataEntityID
			where	FieldName = 'HashDiff' -- TODO: Is this ok for now, as this is the Naming Convention standard, do we need to make it more dynamic?
		) sat_hash
	inner join 
		(
			select	*
			from	@Fields
			where	FieldOriginalID <> 0
		) sat_hashsource on sat_hash.DataEntityID = sat_hashsource.DataEntityID
WHERE NOT EXISTS(SELECT 1 
				 FROM DC.FieldRelation fr
				 WHERE fr.SourceFieldID = [DC].[udf_get_StageLevelBKFieldID_FromSourceBKFieldID] (sat_hashsource.FieldOriginalID, sat_hash.SatelliteFieldDataVelocityTypeID)
				 AND fr.TargetFieldID = sat_hash.SatFieldID
				 AND fr.FieldRelationTypeID  = 2
				  )

UNION ALL

SELECT	[DC].[udf_get_StageLevelBKFieldID_FromSourceBKFieldID](sat_hashsource.FieldOriginalID,sat_hashsource.SatelliteFieldDataVelocityTypeID) AS SourceFieldID
		, sat_hashsource.SatFieldID AS TargetFieldID
		, 2 AS FieldRelationType -- STT Mapping type hard coded
		,GETDATE()
FROM	
		   (SELECT	*
			FROM	@Fields f
			inner join @SatDataEntity sat ON
			sat.SatDataEntityID = f.DataEntityID

			WHERE	FieldOriginalID <> 0
		     ) sat_hashsource 
WHERE NOT EXISTS(SELECT 1 
				 FROM DC.FieldRelation fr
				 WHERE fr.SourceFieldID = [DC].[udf_get_StageLevelBKFieldID_FromSourceBKFieldID](sat_hashsource.FieldOriginalID,sat_hashsource.SatelliteFieldDataVelocityTypeID)
				 AND fr.TargetFieldID = sat_hashsource.SatFieldID
				 AND fr.FieldRelationTypeID  = 2
				 )

union all


-- Generate the STT mapping for the HK columns for each DataEntityID
select	[DC].[udf_get_StageLevelBKFieldID_FromSourceBKFieldID] (hub.SourceFieldID, sat.SatelliteFieldDataVelocityTypeID) as SourceFieldID
		, field.SatFieldID as TargetFieldID
		, 2 AS FieldRelationType -- STT Mapping type hard coded
		,GETDATE()
from	@SatDataEntity sat
	inner join [DMOD].[HubBusinessKey_Working] hub on sat.HubID = hub.HubID
	inner join @Fields field on field.DataEntityID = sat.SatDataEntityID
WHERE  NOT EXISTS(SELECT 1 
				 FROM DC.FieldRelation fr
				 WHERE fr.SourceFieldID = [DC].[udf_get_StageLevelBKFieldID_FromSourceBKFieldID] (hub.SourceFieldID, sat.SatelliteFieldDataVelocityTypeID)
				 AND fr.TargetFieldID = field.SatFieldID
				 AND fr.FieldRelationTypeID  = 2
				 )
AND	FieldName like 'HK%'

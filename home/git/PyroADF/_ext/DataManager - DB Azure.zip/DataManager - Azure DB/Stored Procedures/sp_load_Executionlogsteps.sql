﻿
--By Wium Swart 21 may 2019

CREATE PROCEDURE [INTEGRATION].[sp_load_Executionlogsteps]
AS

INSERT INTO ETL.Executionlogsteps 
select * from INTEGRATION.ingress_Executionlogsteps



﻿CREATE procedure [dbo].[sp_TestingDDL]
as


DECLARE @RC varchar(max)
DECLARE @DDLScript varchar(max)
DECLARE @DataEntityID int


EXECUTE [DMOD].[sp_ddl_CreateTableFromDC] 
   @DDLScript OUTPUT
  ,@DataEntityID = 9881

DECLARE @SqlText varchar(max)
DECLARE @QueryDescription varchar(1000)
DECLARE @TargetDatabaseInstanceID int
DECLARE @DynamicKeyword varchar(1000)

-- TODO: Set parameter values here.

EXECUTE  [EXECUTION].[sp_ins_DDLExecutionItem] 
   @SqlText = @DDLScript
  ,@QueryDescription = 'Test Hub Table'
  ,@TargetDatabaseInstanceID = 3
  ,@DynamicKeyword = 'HUB'

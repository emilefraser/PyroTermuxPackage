﻿
CREATE PROCEDURE [DMOD].[sp_deploy_LoadMethodProc_TOBEDELETED] 
	@ProcText int
AS

declare @sqldyn varchar(max)
        , @TableName varchar(50) = 'Department'
        , @SourceSystemAbbr varchar(50) = 'XT'
        , @DropStatement varchar(max) = ''
		, @ProcStatement varchar(max)
		, @LoadMethodCode varchar(50) = 'stageLoad'
 
set @sqldyn = 
'CREATE PROCEDURE XT.sp_stageLoad_XT_Department AS
    BEGIN
    --Get Current Date Time
    DECLARE @Today DATETIME2(7) = CONVERT(datetime2(7),GETDATE())
 
    --Get MAX(LoadDT) FROM Sat - simulate
    DECLARE @DV_LastLoadDT DATETIME2(7) = (SELECT ISNULL(MAX(CONVERT(datetime2(7),LoadDT)),''1900-01-01 00:00:00.0000000'') FROM DataVaultTest.[raw].SAT_Department_XT_LVD)
END;' 
 
select    @sqldyn = REPLACE(@sqldyn, @TableName, '~@TableName~')
select    @sqldyn = REPLACE(@sqldyn, @SourceSystemAbbr, '~@SourceSystemAbbr~')
 
--select @sqldyn
 
/*
SELECT    *
into    #TableList
from    (
select 'EMPLOYEE' as TableName, 'XT' as SourceSystemAbbr
union
select 'DEPARTMENT' as TableName, 'XT' as SourceSystemAbbr) sq
*/

--select    @finalsql = @finalsql + 'IF EXISTS (select name from sys.procedures where name = ''TEST_sp_stage_XT_Stage' + TableName + ''' and schema_id = 5)' + CHAR(13) + CHAR(10) 
--        + 'DROP PROCEDURE ' +SourceSystemAbbr+ '.TEST_sp_stage_XT_Stage' + TableName + CHAR(13) + CHAR(10) + '' + CHAR(13) + CHAR(10) + REPLACE(REPLACE(@sqldyn, '~@TableName~', TableName),'~@SourceSystemAbbr~', SourceSystemAbbr) 
--        + CHAR(13) + CHAR(10) + ' '
--        + CHAR(13) + CHAR(10) +
--        + CHAR(13) + CHAR(10) 
--from    #TableList
 
--select    @finalsql 
 
--execute sp_executesql @finalsql
 
--exec (@finalsql)
 
DECLARE sqlcursor CURSOR FOR   
	select	DropStatement =
				CONVERT(varchar(max), 'IF EXISTS (select p.name from sys.procedures p inner join sys.schemas s on s.schema_id = p.schema_id where p.name = ''sp_' + @LoadMethodCode +'_'+ SourceSystemAbbr +'_' + TableName + ''' and s.name = '''+ SourceSystemAbbr +''')' + CHAR(13) + CHAR(10) 
				+ 'DROP PROCEDURE ' +SourceSystemAbbr+ '.sp_' + @LoadMethodCode +'_'+ SourceSystemAbbr +'_' + TableName ),
			ProcStatement = 
				REPLACE(REPLACE(@sqldyn, '~@TableName~', TableName),'~@SourceSystemAbbr~', SourceSystemAbbr)
	from    #TableList
		
	--where	TableName = 'EMPLOYEE'

OPEN sqlcursor  

FETCH NEXT FROM sqlcursor   
INTO @DropStatement, @ProcStatement 

WHILE @@FETCH_STATUS = 0  
BEGIN  
	--SELECT @DropStatement
	--SELECT @ProcStatement
	EXEC (@DropStatement)
	EXEC (@ProcStatement)

	FETCH NEXT FROM sqlcursor   
	INTO @DropStatement, @ProcStatement 
END   

CLOSE sqlcursor;  
DEALLOCATE sqlcursor;



﻿--===============================================================================================================================
--Stored Proc Version Control
--===============================================================================================================================
/*
	Create date:						| 2019-01-08
	Author:								| Frans Germishuizen
	Description:						| Create exectable stored proc from static template	
*/

--Sample execution

/*

EXEC [DMOD].[sp_generate_ddl_LoadStoredProcs] 30, 'Emile Fraser'


*/

CREATE   PROCEDURE [DMOD].[sp_generate_ddl_LoadStoredProcs] 
	@LoadConfigID int
,	@Author VARCHAR(250)

AS

BEGIN
--
/*\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\*/
--Stored Proc Management
	--===============================================================================================================================DMOD.udf_get_LoadTypeInfo
	--Variable workbench
	--===============================================================================================================================
	--Stored Proc Varialbles
	DECLARE   @SourceDataEntityID int = NULL
			, @TargetDataEntityID int = NULL
			, @SourceSystemAbbreviation varchar(50) = NULL
			, @LoadTypeID int = NULL
			, @DropStatement varchar(max) = NULL
			, @ProcStatement nvarchar(max)
			, @ParameterSearchValue varchar(max)
			, @ParameterReplacementValue varchar(max)
			, @ParameterReplacementSQLCode nvarchar(max)
	
	--Log Variables


	

/*\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\*/

	--======================================================================================================================
	--Get list of tables that are configured in DMOD.LoadConfig
	--======================================================================================================================

	SELECT 
		@SourceDataEntityID = SourceDataEntityID, 
		@TargetDataEntityID = TargetDataEntityID, 
		@LoadTypeID = conf.LoadTypeID, 
		@SourceSystemAbbreviation = DC.udf_get_TopLevelParentDataEntity_SourceSystemAbbr(TargetDataEntityID), 
		@ProcStatement = ltype.ParameterisedTemplateScript
	FROM 
		DMOD.LoadConfig conf
	INNER JOIN 
		DMOD.LoadType ltype 
		ON ltype.LoadTypeID = conf.LoadTypeID
	WHERE 
		LoadConfigID = @LoadConfigID

	-- DEVLOG
	SELECT 
		   @SourceDataEntityID, 
		   DC.udf_GetDataEntityNameForDataEntityID(@SourceDataEntityID) AS Source_DataEntityName,
		   @TargetDataEntityID, 
		   DC.udf_GetDataEntityNameForDataEntityID(@TargetDataEntityID),
		   @LoadTypeID, 
		   DMOD.udf_get_LoadTypeTargetDatabase_LoadTypeID(@LoadTypeID),
		   DMOD.udf_get_LoadType_LoadTypeID(@LoadTypeID) AS LoadType,
		   DMOD.udf_get_LoadTypeEntity_LoadTypeID(@LoadTypeID) AS LoadTypeEntity,
		   DMOD.udf_get_LoadTypeTargetDatabase_LoadTypeID(@LoadTypeID) AS LoadTypeTargetDatabase,
		   DMOD.udf_get_IsExternalTable_LoadTypeID(@LoadTypeID) AS IsExternalTable,
		   @SourceSystemAbbreviation, 
		   @ProcStatement

	--======================================================================================================================
	--
	--======================================================================================================================
	
	--select	DataEntityName
	--		, SystemAbbreviation
	--from	DC.vw_rpt_DatabaseFieldDetail
	--where	DataEntityID = @TargetDataEntityID

	--======================================================================================================================
	-- Generate drop statement for load proc
	--======================================================================================================================
	
	--DONE, commented out for testing purposes
	select	@DropStatement =
				CONVERT(varchar(max), 'IF EXISTS (select p.name from sys.procedures p inner join sys.schemas s on s.schema_id = p.schema_id where p.name = ''sp_' 
										+ ltype.LoadTypeCode + '_' 
										+ @SourceSystemAbbreviation + '_' 
										+ dctarget.DataEntityName + ''' and s.name = ''' 
										+ @SourceSystemAbbreviation +''')' + CHAR(13) + CHAR(10) 
										+ 'BEGIN' + CHAR(13) + CHAR(10)
										+ CHAR(9) + 'DROP PROCEDURE ' + @SourceSystemAbbreviation 
										+ '.sp_' + ltype.LoadTypeCode +'_'+ @SourceSystemAbbreviation +'_' + dctarget.DataEntityName + CHAR(13) + CHAR(10) 
										+ 'END' + CHAR(13) + CHAR(10))
	--select	dcsource.*
	from	DMOD.LoadConfig lconfig
		inner join DMOD.LoadType ltype on lconfig.LoadTypeID = ltype.LoadTypeID
		inner join 
					(
						select	distinct  DataEntityID, SystemAbbreviation, DataEntityName
						from	DC.vw_rpt_DatabaseFieldDetail 
						where	DataEntityID = @SourceDataEntityID
					) dcsource on lconfig.SourceDataEntityID = dcsource.DataEntityID
		inner join 
					(
						select	distinct  DataEntityID, SystemAbbreviation, DataEntityName
						from	DC.vw_rpt_DatabaseFieldDetail 
						where	DataEntityID = @TargetDataEntityID
					) dctarget on lconfig.TargetDataEntityID = dctarget.DataEntityID
	where	LoadConfigID = @LoadConfigID

	/************************************************************************************************************************************************************************
	DEV NOTE (ID: DLT_FunctionReplacementList):		
		If a new function is created and linked to a paramater in the DMOD.LoadTypeParameter table
		, this list needs to be updated with the new function and pass in the correct parameters to execute the function.
		This gets passed into a # table which is then matched with the parameter link table to make sure that replacements do not get done by accident 
		and for future functionality use
	************************************************************************************************************************************************************************/
	--======================================================================================================================
	--List of all functions that exists that can be linked to templates to replace dynamic porsions of code
	--======================================================================================================================
	--FUTURE: Make this managable and dynamic - move to table for front end configuration etc.?
	
	--TODO: Populate all function parameters with values that must be passed to the functions below

	DROP TABLE IF EXISTS #FunctionReplacements
	CREATE TABLE #FunctionReplacements
		(
			  [ReplacementOrder] int
			, [TemplateParameterName] varchar(200)
			, [FunctionReplacementValue] varchar(max)
		)

	INSERT INTO #FunctionReplacements([ReplacementOrder], [TemplateParameterName], [FunctionReplacementValue])
	--TODO: Replace all function parameters with dynamic lookup parameters that get done before hand
		
		select	1 AS [ReplacementOrder]
				, '~@FieldList_CreateTable_Stage~' AS [TemplateParameterName]
				, [DMOD].[udf_get_FieldList_Create_Table_Stage](@TargetDataEntityID) AS FunctionReplacementValue	
		union
		select	2 AS [ReplacementOrder]
				, '~@FieldList_WithAlias_BK_ODS~' AS [TemplateParameterName]
				, [DMOD].[udf_get_FieldList_WithAlias_BK_ODS](@LoadConfigID) AS FunctionReplacementValue
		union
		select	3 AS [ReplacementOrder]
				, '~@FieldList_WithAlias_HashKeys_ODS~' AS [TemplateParameterName]
				, [DMOD].[udf_get_FieldList_WithAlias_HashKeys_ODS](@LoadConfigID) AS FunctionReplacementValue	
		union
		select	4 AS [ReplacementOrder]
				, '~@FieldList_WithAlias_ODS~' AS [TemplateParameterName]
				, [DMOD].[udf_get_FieldList_WithAlias_ODS](@LoadConfigID) AS FunctionReplacementValue		
		union
		select	5 AS [ReplacementOrder]
				, '~@FieldList_WithAlias_Stage~' AS [TemplateParameterName]
				, [DMOD].[udf_get_FieldList_WithAlias_Stage] (@TargetDataEntityID)  AS FunctionReplacementValue
		union
		select	6 AS [ReplacementOrder]
				, '~@JoinList_WithAlias_ODS~' AS [TemplateParameterName]
				, [DMOD].[udf_get_JoinList_WithAlias_ODS](@LoadConfigID) AS FunctionReplacementValue
		union
		select	7 AS [ReplacementOrder]
				, '~@LoadConfigID~' AS [TemplateParameterName]
				, [DMOD].[udf_get_LoadConfigID](@LoadConfigID) AS FunctionReplacementValue	
		union
		select	8 AS [ReplacementOrder]
				, '~@LoadTypeInfo~' AS [TemplateParameterName]
				, [DMOD].[udf_get_LoadTypeInfo](@LoadConfigID, @Author) AS FunctionReplacementValue
		union
		select	9 AS [ReplacementOrder]
				, '~@LoggingConventionNotes~' AS [TemplateParameterName]
				, [DMOD].[udf_get_LoggingConventionNotes]('SP01') AS FunctionReplacementValue -- Hard coded parameter	
		union 
		select	10 AS [ReplacementOrder]
				, '~@FieldList_WithNoAlias_ODS~' AS [TemplateParameterName]
				, [DMOD].[udf_get_FieldList_WithNoAlias_ODS](@TargetDataEntityID) AS FunctionReplacementValue			
		union 
		select	11 AS [ReplacementOrder]
				, '~@FieldList_WithNoAlias_Stage~' AS [TemplateParameterName]
				, [DMOD].[udf_get_FieldList_WithNoAlias_Stage](@TargetDataEntityID) AS FunctionReplacementValue					
		union 
		select	12 AS [ReplacementOrder]
				, '~@StageAreaSchemaName~' AS [TemplateParameterName]
				, [DMOD].[udf_get_StageAreaSchemaName](@LoadConfigID) AS FunctionReplacementValue	
		union 
		select	13 AS [ReplacementOrder]
				, '~@LoadTypeCode~' AS [TemplateParameterName]
				, [DMOD].[udf_get_LoadTypeCode](@LoadConfigID) AS FunctionReplacementValue	
		union
		select	14 AS [ReplacementOrder]
				, '~@StageAreaTableName~' AS [TemplateParameterName]
				, [DMOD].[udf_get_StageAreaTableName](@LoadConfigID) AS FunctionReplacementValue	
		union 
		select	15 AS [ReplacementOrder]
				, '~@DataVaultTableName~' AS [TemplateParameterName]
				, [DMOD].[udf_get_DataVaultTableName](@LoadConfigID) AS FunctionReplacementValue	
		union 
		select	16 AS [ReplacementOrder]
				, '~@StageAreaVelocityTableName~' AS [TemplateParameterName]
				, [DMOD].[udf_get_StageAreaVelocityTableName](@LoadConfigID) AS FunctionReplacementValue	
		union 
		select	17 AS [ReplacementOrder]
				, '~@ODSDatabaseName~' AS [TemplateParameterName]
				, [DMOD].[udf_get_ODSDatabaseName](@LoadConfigID) AS FunctionReplacementValue	
		union 
		select	18 AS [ReplacementOrder]
				, '~@RecSrcDataEntityID~' AS [TemplateParameterName]
				, [DMOD].[udf_get_RecSrcDataEntityID](@LoadConfigID) AS FunctionReplacementValue	
		union 
		select	19 AS [ReplacementOrder]
				, '~@ODSDataEntityName~' AS [TemplateParameterName]
				, [DMOD].[udf_get_ODSDataEntityName](@LoadConfigID) AS FunctionReplacementValue		
		union 
		select	20 AS [ReplacementOrder]
				, '~@TargetDataEntity~' AS [TemplateParameterName]
				, [DMOD].[udf_get_TargetDataEntity](@LoadConfigID) AS FunctionReplacementValue		
		union
		select	21 AS [ReplacementOrder]
				, '~@StageAreaHistTableName~' AS [TemplateParameterName]
				, [DMOD].[udf_get_StageAreaHistoryTableName](@LoadConfigID) AS FunctionReplacementValue	
		union
		select	22 AS [ReplacementOrder]
				, '~@StageAreaProcName~' AS [TemplateParameterName]
				, [DMOD].[udf_get_StageAreaProcName](@LoadConfigID) AS FunctionReplacementValue	
		union
		select	23 AS [ReplacementOrder]
				, '~@HashDiffForSatellite~' AS [TemplateParameterName]
				, [DMOD].[udf_get_FieldList_WithAlias_HashDiff](@SourceDataEntityID) AS FunctionReplacementValue	
		union
		select	24 AS [ReplacementOrder]
				, '~@LoadEntity_PKName~' AS [TemplateParameterName]
				, [DMOD].[udf_get_LoadEntity_PKName](@LoadConfigID) AS FunctionReplacementValue
		union
		select	25 AS [ReplacementOrder]
				, '~@LoadEntity_NonClusteredIndex~' AS [TemplateParameterName]
				, [DMOD].[udf_get_LoadEntity_NonClusteredIndex](@LoadConfigID) AS FunctionReplacementValue
		union
		select	26 AS [ReplacementOrder]
				, '~@LoadSets_TempTableName~' AS [TemplateParameterName]
				, [DMOD].[udf_get_LoadSets_TempTableName](@LoadConfigID) AS FunctionReplacementValue
		union
		select	27 AS [ReplacementOrder]
				, '~@LoadComparison_TempTableName~' AS [TemplateParameterName]
				, [DMOD].[udf_get_LoadComparison_TempTableName](@LoadConfigID) AS FunctionReplacementValue
		union
		select	28 AS [ReplacementOrder]
				, '~@LoadEntity_TempTableName~' AS [TemplateParameterName]
				, [DMOD].[udf_get_LoadEntity_TempTableName](@LoadConfigID) AS FunctionReplacementValue
		union
		select	29 AS [ReplacementOrder]
				, '~@DataVaultSchemaName~' AS [TemplateParameterName]
				, [DMOD].[udf_get_DataVaultSchemaName](@LoadConfigID) AS FunctionReplacementValue
		union
		select	30 AS [ReplacementOrder]
				, '~@DataVaultDatabaseName~' AS [TemplateParameterName]
				, [DMOD].[udf_get_DataVaultDatabaseName](@LoadConfigID) AS FunctionReplacementValue
		union
		select	31 AS [ReplacementOrder]
				, '~@StageAreaDatabaseName~' AS [TemplateParameterName]
				, [DMOD].[udf_get_StageAreaDatabaseName](@LoadConfigID) AS FunctionReplacementValue
		union
		select	32 AS [ReplacementOrder]
				, '~@ODSSchemaName~' AS [TemplateParameterName]
				, [DMOD].[udf_get_ODSSchemaName](@LoadConfigID) AS FunctionReplacementValue
		union
		select	33 AS [ReplacementOrder]
				, '~@StageAreaHistVelocityTableName~' AS [TemplateParameterName]
				, [DMOD].[udf_get_StageAreaVelocityHistoryTableName](@LoadConfigID) AS FunctionReplacementValue	
		union
		select	34 AS [ReplacementOrder]
				, '~@Where_IncrementalLoadWithHistoryUpdate~' AS [TemplateParameterName]
				, [DMOD].[udf_get_Where_IncrementalLoadWithHistoryUpdate](@LoadConfigID) AS FunctionReplacementValue	
		union
		select	35 AS [ReplacementOrder]
				, '~@SatelliteCreateDT_Last~' AS [TemplateParameterName]
				, [DMOD].[udf_get_SatelliteCreateDT_Last_Field](@LoadConfigID) AS FunctionReplacementValue	
		union
		select	36 AS [ReplacementOrder]
				, '~@SatelliteUpdateDT_Last~' AS [TemplateParameterName]
				, [DMOD].[udf_get_SatelliteUpdateDT_Last_Field](@LoadConfigID) AS FunctionReplacementValue	


	
	--======================================================================================================================
	-- Check if the parameter is linked to the load type template
	--======================================================================================================================
	--Commented out for now, cannot see why this will be needed. Will only be needed in future when the front end is built	
	
	-- DEVLOG
	SELECT	
		*
	FROM	
		#FunctionReplacements funcparm

	--select * from DMOD.LoadTypeParameter parm
	--inner join DMOD.LinkLoadTypeToLoadTypeParameter parmlink on parmlink.LoadTypeParameterID = parm.LoadTypeParameterID
	--where parmlink.LoadTypeID = 2
	--and parm.ParameterValueReplacementSQLCode IS NOT NULL


	--select	*
	--from	#FunctionReplacements funcparm
	--	inner join DMOD.LoadTypeParameter parm on parm.ParameterName = funcparm.TemplateParameterName
	--	inner join DMOD.LinkLoadTypeToLoadTypeParameter parmlink on parmlink.LoadTypeParameterID = parm.LoadTypeParameterID
	--where	parmlink.LoadTypeID = @LoadTypeID
	--	and parm.IsStaticReplacementValue = 0
	--	and parm.ParameterValueReplacementSQLCode IS NOT NULL



	--======================================================================================================================
	-- Generate CREATE OR ALTER PROCEDURE statement
	--======================================================================================================================
	
	--Loop through the function replacement parameters and values. Replace the parameter placeholder with the function result set
	DECLARE ParameterCursor_FunctionValue CURSOR FOR
		SELECT	ParameterSearchValue = [TemplateParameterName]
				, ParameterReplacementValue = [FunctionReplacementValue]
		FROM	#FunctionReplacements
		WHERE	[FunctionReplacementValue] IS NOT NULL
			OR [FunctionReplacementValue] IS NOT NULL
		ORDER BY ReplacementOrder


		--		SELECT	 [TemplateParameterName]
		--		,  [FunctionReplacementValue]
		--FROM	#FunctionReplacements
		--WHERE	[FunctionReplacementValue] IS NOT NULL
		--	OR [FunctionReplacementValue] IS NOT NULL
		--ORDER BY ReplacementOrder


	OPEN ParameterCursor_FunctionValue

	FETCH NEXT FROM ParameterCursor_FunctionValue INTO @ParameterSearchValue, @ParameterReplacementValue 

	WHILE @@FETCH_STATUS = 0
	BEGIN
		-- Replace parameter placeholders with function result sets
		WHILE CHARINDEX(@ParameterSearchValue, @ProcStatement, 0) > 0
		BEGIN	
		
			SELECT	@ProcStatement = REPLACE(@ProcStatement, @ParameterSearchValue, @ParameterReplacementValue)
			
		END

		--Fetch next from cursor
		FETCH NEXT FROM ParameterCursor_FunctionValue INTO @ParameterSearchValue, @ParameterReplacementValue

	END

	CLOSE ParameterCursor_FunctionValue
	DEALLOCATE ParameterCursor_FunctionValue
	

	--select	@ProcStatement

	--truncate table DMOD.ParameterScriptTest

	IF NOT EXISTS (select name from sys.tables where name = N'LoadProcExports')
	CREATE TABLE [DMOD].[LoadProcExports](
		[TableName] [varchar](100) NULL,
		[PScript] [varchar](max) NULL,
		[Author] [varchar](100) NULL,
		[CreatedDT] [datetime2](7) NULL,
		[Status] [varchar](100) NULL
	) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]


	
	INSERT INTO 
		 DMOD.[LoadProcExports] (TableName, PScript, Author, CreatedDT, [Status], LoadConfigID)
	SELECT	
		[DMOD].[udf_get_StageAreaTableName](@LoadConfigID), @ProcStatement, @Author, GETDATE(), 'Generated, Not Deployed', @LoadConfigID

END

﻿--===============================================================================================================================
--Stored Proc Version Control
--===============================================================================================================================
/*
	Create date:						| 2019-01-08
	Author:								| Frans Germishuizen
	Description:						| Create exectable stored proc from static template	
*/

--Sample execution

/*

exec [DMOD].[zz_sp_generate_ddl_LoadStoredProcs] 1


*/

CREATE PROCEDURE [DMOD].[zz_sp_generate_ddl_LoadStoredProcs] 
	@LoadConfigID int

AS
--
/*\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\*/
--Stored Proc Management
	--===============================================================================================================================
	--Variable workbench
	--===============================================================================================================================
	--Stored Proc Varialbles
	declare @SourceDataEntityID int = NULL
			, @TargetDataEntityID int = NULL
			, @SourceSystemAbbreviation varchar(50) = NULL
			, @LoadTypeID int = NULL
			, @DropStatement varchar(max) = NULL
			, @ProcStatement nvarchar(max)
			, @ParameterSearchValue varchar(max)
			, @ParameterReplacementValue varchar(max)
			, @ParameterReplacementSQLCode nvarchar(max)
	
	--Log Variables

	--Testing variables (COMMENT OUT BEFORE ALTERING THE PROC)
	/*
	
	declare	@LoadConfigID int

	set		@LoadConfigID = 1

	--*/

/*\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\*/

	--======================================================================================================================
	--Get list of tables that are configured in DMOD.LoadConfig
	--======================================================================================================================

	select	@SourceDataEntityID = SourceDataEntityID
			, @TargetDataEntityID = TargetDataEntityID
			, @LoadTypeID = conf.LoadTypeID
			, @SourceSystemAbbreviation = DC.udf_get_TopLevelParentDataEntity_SourceSystemAbbr(TargetDataEntityID)
			, @ProcStatement = ltype.ParameterisedTemplateScript
	from	DMOD.LoadConfig conf
		inner join DMOD.LoadType ltype on ltype.LoadTypeID = conf.LoadTypeID
	where	LoadConfigID = @LoadConfigID

	--select @SourceDataEntityID, @TargetDataEntityID, @LoadTypeID, @SourceSystemAbbreviation
	
	--======================================================================================================================
	--
	--======================================================================================================================
	
	--select	DataEntityName
	--		, SystemAbbreviation
	--from	DC.vw_rpt_DatabaseFieldDetail
	--where	DataEntityID = @TargetDataEntityID

	--======================================================================================================================
	-- Generate drop statement for load proc
	--======================================================================================================================
	
	--DONE, commented out for testing purposes
	/*

	select	@DropStatement =
				CONVERT(varchar(max), 'IF EXISTS (select p.name from sys.procedures p inner join sys.schemas s on s.schema_id = p.schema_id where p.name = ''sp_' 
										+ ltype.LoadTypeCode + '_' 
										+ @SourceSystemAbbreviation + '_' 
										+ dctarget.DataEntityName + ''' and s.name = ''' 
										+ @SourceSystemAbbreviation +''')' + CHAR(13) + CHAR(10) 
										+ 'BEGIN' + CHAR(13) + CHAR(10)
										+ CHAR(9) + 'DROP PROCEDURE ' + @SourceSystemAbbreviation 
										+ '.sp_' + ltype.LoadTypeCode +'_'+ @SourceSystemAbbreviation +'_' + dctarget.DataEntityName + CHAR(13) + CHAR(10) 
										+ 'END' + CHAR(13) + CHAR(10))
	--select	dcsource.*
	from	DMOD.LoadConfig lconfig
		inner join DMOD.LoadType ltype on lconfig.LoadTypeID = ltype.LoadTypeID
		inner join 
					(
						select	distinct  DataEntityID, SystemAbbreviation, DataEntityName
						from	DC.vw_rpt_DatabaseFieldDetail 
						where	DataEntityID = @SourceDataEntityID
					) dcsource on lconfig.SourceDataEntityID = dcsource.DataEntityID
		inner join 
					(
						select	distinct  DataEntityID, SystemAbbreviation, DataEntityName
						from	DC.vw_rpt_DatabaseFieldDetail 
						where	DataEntityID = @TargetDataEntityID
					) dctarget on lconfig.TargetDataEntityID = dctarget.DataEntityID
	where	LoadConfigID = @LoadConfigID
	--*/

	/************************************************************************************************************************************************************************
	DEV NOTE (ID: DLT_FunctionReplacementList):		
		If a new function is created and linked to a paramater in the DMOD.LoadTypeParameter table
		, this list needs to be updated with the new function and pass in the correct parameters to execute the function.
		This gets passed into a # table which is then matched with the parameter link table to make sure that replacements do not get done by accident 
		and for future functionality use
	************************************************************************************************************************************************************************/
	--======================================================================================================================
	--List of all functions that exists that can be linked to templates to replace dynamic porsions of code
	--======================================================================================================================
	--FUTURE: Make this managable and dynamic - move to table for front end configuration etc.?
	
	--TODO: Populate all function parameters with values that must be passed to the functions below

	DROP TABLE IF EXISTS #FunctionReplacements
	CREATE TABLE #FunctionReplacements
		(
			  [ReplacementOrder] int
			, [TemplateParameterName] varchar(200)
			, [FunctionReplacementValue] varchar(max)
		)

	INSERT INTO #FunctionReplacements([ReplacementOrder], [TemplateParameterName], [FunctionReplacementValue])
	--TODO: Replace all function parameters with dynamic lookup parameters that get done before hand
		
		select	1 AS [ReplacementOrder]
				, '~@FieldList_CreateTable_Stage~' AS [TemplateParameterName]
				, [DMOD].[udf_get_FieldList_Create_Table_Stage](9619) AS FunctionReplacementValue		
		union
		select	2 AS [ReplacementOrder]
				, '~@FieldList_WithAlias_BK_ODS~' AS [TemplateParameterName]
				, [DMOD].[udf_get_FieldList_WithAlias_BK_ODS](249) AS FunctionReplacementValue
		union
		select	3 AS [ReplacementOrder]
				, '~@FieldList_WithAlias_HashKeys_ODS~' AS [TemplateParameterName]
				, [DMOD].[udf_get_FieldList_WithAlias_HashKeys_ODS](249) AS FunctionReplacementValue	
		union
		select	4 AS [ReplacementOrder]
				, '~@FieldList_WithAlias_ODS~' AS [TemplateParameterName]
				, [DMOD].[udf_get_FieldList_WithAlias_ODS](249) AS FunctionReplacementValue		
		union
		select	5 AS [ReplacementOrder]
				, '~@FieldList_WithAlias_Stage~' AS [TemplateParameterName]
				, [DMOD].[udf_get_FieldList_WithAlias_Stage] (249)  AS FunctionReplacementValue
		union
		select	6 AS [ReplacementOrder]
				, '~@JoinList_WithAlias_ODS~' AS [TemplateParameterName]
				, [DMOD].[udf_get_JoinList_WithAlias_ODS](90) AS FunctionReplacementValue
		union
		select	7 AS [ReplacementOrder]
				, '~@LoadConfigID~' AS [TemplateParameterName]
				, [DMOD].[udf_get_LoadConfigID](1) AS FunctionReplacementValue	
		union
		select	8 AS [ReplacementOrder]
				, '~@LoadTypeInfo~' AS [TemplateParameterName]
				, [DMOD].[udf_get_LoadTypeInfo]('Frans Germishuizen') AS FunctionReplacementValue
		union
		select	9 AS [ReplacementOrder]
				, '~@LoggingConventionNotes~' AS [TemplateParameterName]
				, [DMOD].[udf_get_LoggingConventionNotes]('SP01') AS FunctionReplacementValue -- Hard coded parameter	
		union 
		select	10 AS [ReplacementOrder]
				, '~@FieldList_WithNoAlias_ODS~' AS [TemplateParameterName]
				, [DMOD].[udf_get_FieldList_WithNoAlias_ODS](249) AS FunctionReplacementValue	
		union 
		select	11 AS [ReplacementOrder]
				, '~@FieldList_WithNoAlias_Stage~' AS [TemplateParameterName]
				, [DMOD].[udf_get_FieldList_WithNoAlias_Stage](249) AS FunctionReplacementValue	
		union 
		select	12 AS [ReplacementOrder]
				, '~@StageAreaSchemaName~' AS [TemplateParameterName]
				, [DMOD].[udf_get_StageAreaSchemeName](249) AS FunctionReplacementValue	
		union 
		select	13 AS [ReplacementOrder]
				, '~@LoadTypeCode~' AS [TemplateParameterName]
				, [DMOD].[udf_get_LoadTypeCode](249) AS FunctionReplacementValue	
					union 
		select	14 AS [ReplacementOrder]
				, '~@StageAreaTableName~' AS [TemplateParameterName]
				, [DMOD].[udf_get_StageAreaTableName](249) AS FunctionReplacementValue	
		union 
		select	15 AS [ReplacementOrder]
				, '~@DataVaultTableName~' AS [TemplateParameterName]
				, [DMOD].[udf_get_DataVaultTableName](249) AS FunctionReplacementValue	
		union 
		select	16 AS [ReplacementOrder]
				, '~@DataVaultTableName~' AS [TemplateParameterName]
				, [DMOD].[udf_get_StageAreaVelocityTableName](249) AS FunctionReplacementValue	
		union 
		select	16 AS [ReplacementOrder]
				, '~@RecSrcDataEntityID~' AS [TemplateParameterName]
				, [DMOD].[udf_get_RecSrcDataEntityID](249) AS FunctionReplacementValue	
		union 
		select	16 AS [ReplacementOrder]
				, '~@ODSDatabaseName~' AS [TemplateParameterName]
				, [DMOD].[udf_get_ODSDatabaseName](249) AS FunctionReplacementValue	

	--======================================================================================================================
	-- Check if the parameter is linked to the load type template
	--======================================================================================================================
	--Commented out for now, cannot see why this will be needed. Will only be needed in future when the front end is built
		
	--select	*
	--from	#FunctionReplacements funcparm
	--	inner join DMOD.LoadTypeParameter parm on parm.ParameterName = funcparm.TemplateParameterName
	--	inner join DMOD.LinkLoadTypeToLoadTypeParameter parmlink on parmlink.LoadTypeParameterID = parm.LoadTypeParameterID
	--where	parmlink.LoadTypeID = 1 --@LoadTypeID
	--	and parm.IsStaticReplacementValue = 0
	--	and parm.ParameterValueReplacementSQLCode IS NOT NULL

	--======================================================================================================================
	-- Generate create procedure statement
	--======================================================================================================================
	
	--Loop through the function replacement parameters and values. Replace the parameter placeholder with the function result set
	DECLARE ParameterCursor_FunctionValue CURSOR FOR
		SELECT	ParameterSearchValue = [TemplateParameterName]
				, ParameterReplacementValue = [FunctionReplacementValue]
		FROM	#FunctionReplacements
		WHERE	[FunctionReplacementValue] IS NOT NULL
			OR [FunctionReplacementValue] IS NOT NULL
		ORDER BY ReplacementOrder


		--		SELECT	 [TemplateParameterName]
		--		,  [FunctionReplacementValue]
		--FROM	#FunctionReplacements
		--WHERE	[FunctionReplacementValue] IS NOT NULL
		--	OR [FunctionReplacementValue] IS NOT NULL
		--ORDER BY ReplacementOrder


	OPEN ParameterCursor_FunctionValue

	FETCH NEXT FROM ParameterCursor_FunctionValue INTO @ParameterSearchValue, @ParameterReplacementValue 

	WHILE @@FETCH_STATUS = 0
	BEGIN
		-- Replace parameter placeholders with function result sets
		WHILE CHARINDEX(@ParameterSearchValue, @ProcStatement, 0) > 0
		BEGIN	
			
			select	@ProcStatement = REPLACE(@ProcStatement, @ParameterSearchValue, @ParameterReplacementValue)
			
		END

		--Fetch next from cursor
		FETCH NEXT FROM ParameterCursor_FunctionValue INTO @ParameterSearchValue, @ParameterReplacementValue

	END

	CLOSE ParameterCursor_FunctionValue
	DEALLOCATE ParameterCursor_FunctionValue
	
	truncate table DMOD.ParameterScriptTest

	insert into DMOD.ParameterScriptTest
	select	@ProcStatement

	select	*
	from	DMOD.ParameterScriptTest

	
	----Replace relevant parameters with values
	--DECLARE FunctionParameterCursor_Replacement CURSOR FOR
	--	SELECT	ParameterName = ParameterName#TemplateParameters				, ParameterValueReplacementSQLCode = ParameterValueReplacementSQLCode
	--	FROM	#TemplateParameters
	
	--OPEN FunctionParameterCursor_Replacement

	--FETCH NEXT FROM FunctionParameterCursor_Replacement INTO @ParameterSearchValue, @ParameterReplacementSQLCode

	--WHILE @@FETCH_STATUS = 0
	--BEGIN
	--	-- Replace Field Lists with alias
	--	WHILE CHARINDEX(@ParameterSearchValue, @ProcStatement, 0) > 0
	--	BEGIN
	--		--Generate replacement value by executing the replacement value SQL code
	--		exec	sp_sqlexec @ParameterReplacementSQLCode

	--		--Replace the parameter with the generated replacement string from the above SQL code execution
	--		select	@ProcStatement = REPLACE(@ProcStatement, @ParameterSearchValue, @ParameterReplacementValue)
			
	--		END

	--	--Fetch next from cursor
	--	FETCH NEXT FROM FunctionParameterCursor_Replacement INTO @ParameterSearchValue, @ParameterReplacementValue

	--END

	--CLOSE FunctionParameterCursor_Replacement
	--DEALLOCATE FunctionParameterCursor_Replacement

	----Get load type paramatarised load template
	--select	@ProcStatement = ParameterisedTemplateScript
	--from	DMOD.LoadType
	--where	LoadTypeID = @LoadTypeID

	----Get all parameters that are linked to this load template
	--DROP TABLE IF EXISTS #TemplateParameters
	--select	ParameterName, ParameterValueReplacementSQLCode
	--into	#TemplateParameters
	--from	DMOD.LoadTypeParameter parm
	--	inner join DMOD.LinkLoadTypeToLoadTypeParameter parmlink on parmlink.LoadTypeParameterID = parm.LoadTypeParameterID
	--where	parmlink.LoadTypeID = @LoadTypeID
	--	and parm.IsStaticReplacementValue = 0
	--	and parm.ParameterValueReplacementSQLCode IS NOT NULL

	--select	*
	--from	#TemplateParameters
	
	
	----Loop through the replacement parameters and replace the parameter text with the SQL Function result
	--DECLARE ParameterCursor_Replacement CURSOR FOR
	--	SELECT	ParameterName = ParameterName
	--			, ParameterValueReplacementSQLCode = ParameterValueReplacementSQLCode
	--	FROM	#TemplateParameters
	
	--OPEN ParameterCursor_Replacement

	--FETCH NEXT FROM ParameterCursor_Replacement INTO @ParameterSearchValue, @ParameterReplacementSQLCode

	--WHILE @@FETCH_STATUS = 0
	--BEGIN
	--	-- Replace Field Lists with alias
	--	WHILE CHARINDEX(@ParameterSearchValue, @ProcStatement, 0) > 0
	--	BEGIN
	--		--Generate replacement value by executing the replacement value SQL code
	--		exec	sp_sqlexec @ParameterReplacementSQLCode

	--		--Replace the parameter with the generated replacement string from the above SQL code execution
	--		select	@ProcStatement = REPLACE(@ProcStatement, @ParameterSearchValue, @ParameterReplacementValue)
			
	--		END

	--	--Fetch next from cursor
	--	FETCH NEXT FROM ParameterCursor_Replacement INTO @ParameterSearchValue, @ParameterReplacementValue

	--END

	--CLOSE ParameterCursor_Replacement
	--DEALLOCATE ParameterCursor_Replacement



	--select	*
	--from    DMOD.LoadConfig lconfig
	--	inner join DMOD.LoadType ltype on ltype.LoadTypeID = lconfig.LoadConfigID
	--	inner join 
	--				(
	--					select	distinct  DataEntityID, SystemAbbreviation, DataEntityName
	--					from	DC.vw_rpt_DatabaseFieldDetail 
	--					where	DataEntityID = @SourceDataEntityID
	--				) dcsource on lconfig.SourceDataEntityID = dcsource.DataEntityID
	--	inner join 
	--				(
	--					select	distinct  DataEntityID, SystemAbbreviation, DataEntityName
	--					from	DC.vw_rpt_DatabaseFieldDetail 
	--					where	DataEntityID = @TargetDataEntityID
	--				) dctarget on lconfig.TargetDataEntityID = dctarget.DataEntityID
	--where	LoadConfigID = @LoadConfigID

	
	--select	
	--			REPLACE(
	--				REPLACE(
	--					REPLACE(
	--						REPLACE(
	--							REPLACE(ParameterisedTemplateScript, '~@TableName~', dcsource.DataEntityName)
	--											,'~@SourceSystemAbbr~', dcsource.SystemAbbreviation)
	--											, '~@CreateTableFieldList~', (select [DC].[udf_FieldListForCreateTable](SourceDataEntityID)))
	--											, '~@FieldListNoAlias~', (select [DC].[udf_FieldListForSelect](SourceDataEntityID)))
	--											, '~@FieldListWithAlias~', (select [DC].[udf_FieldListForSelectWithAlias](SourceDataEntityID)))
	--from    DMOD.LoadConfig lconfig
	--	inner join DMOD.LoadType ltype on ltype.LoadTypeID = lconfig.LoadConfigID
	--	inner join 
	--				(
	--					select	distinct  DataEntityID, SystemAbbreviation, DataEntityName
	--					from	DC.vw_rpt_DatabaseFieldDetail 
	--					where	DataEntityID = @SourceDataEntityID
	--				) dcsource on lconfig.SourceDataEntityID = dcsource.DataEntityID
	--	inner join 
	--				(
	--					select	distinct  DataEntityID, SystemAbbreviation, DataEntityName
	--					from	DC.vw_rpt_DatabaseFieldDetail 
	--					where	DataEntityID = @TargetDataEntityID
	--				) dctarget on lconfig.TargetDataEntityID = dctarget.DataEntityID
	--where	LoadConfigID = @LoadConfigID

	/*
	DECLARE sqlcursor CURSOR FOR   
		select	
				REPLACE(
					REPLACE(
						REPLACE(
							REPLACE(
								REPLACE(ParameterisedTemplateScript, '~@TableName~', dcsource.DataEntityName)
												,'~@SourceSystemAbbr~', @SourceSystemAbbreviation)
												, '~@CreateTableFieldList~', (select [DC].[udf_FieldListForCreateTable](SourceDataEntityID)))
												, '~@FieldListNoAlias~', (select [DC].[udf_FieldListForSelect](SourceDataEntityID)))
												, '~@FieldListWithAlias~', (select [DC].[udf_FieldListForSelectWithAlias](SourceDataEntityID)))
		from    DMOD.LoadConfig lconfig
			inner join DMOD.LoadType ltype on ltype.LoadTypeID = lconfig.LoadConfigID
			inner join 
						(
							select	distinct  DataEntityID, SystemAbbreviation, DataEntityName
							from	DC.vw_rpt_DatabaseFieldDetail 
							where	DataEntityID = @SourceDataEntityID
						) dcsource on lconfig.SourceDataEntityID = dcsource.DataEntityID
			inner join 
						(
							select	distinct  DataEntityID, SystemAbbreviation, DataEntityName
							from	DC.vw_rpt_DatabaseFieldDetail 
							where	DataEntityID = @TargetDataEntityID
						) dctarget on lconfig.TargetDataEntityID = dctarget.DataEntityID
		where	LoadConfigID = @LoadConfigID
		
		--where	TableName = 'DEPARTMENT'

	OPEN sqlcursor  

	FETCH NEXT FROM sqlcursor   
	INTO  @ProcStatement 

	declare @i int = 0

	WHILE @@FETCH_STATUS = 0  
	BEGIN  
		--SELECT @DropStatement
		SELECT @ProcStatement
		--EXEC (@DropStatement)
		--EXEC (@ProcStatement)
	
		WHILE @i < LEN(@ProcStatement)
		BEGIN
			SELECT SUBSTRING(@ProcStatement, @i, @i + 8000)
			select @i += 8000
		END

		FETCH NEXT FROM sqlcursor   
		INTO @ProcStatement 
	END   

	CLOSE sqlcursor;  
	DEALLOCATE sqlcursor;

	--*/

	--======================================================================================================================
	--
	--======================================================================================================================

	
    



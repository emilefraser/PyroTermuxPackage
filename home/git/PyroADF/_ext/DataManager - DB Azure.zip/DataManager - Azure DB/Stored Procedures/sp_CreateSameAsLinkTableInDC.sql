﻿
-- ====================================================================================================
-- Author:      Francois Senekal
-- Create Date: 6 February 2019
-- Description: Creates SAL tables and CLSAT in DC and auto-creates relationships to Source/SAL
-- ==============================================================

CREATE PROCEDURE [DC].[sp_CreateSameAsLinkTableInDC] AS
/*--====================================================================================================
Test Case 1:

--====================================================================================================*/

--====================================================================================================
--TempTable CreatedHere for SAL
--====================================================================================================
DECLARE @HubID INT
SET @HubID = 14
DECLARE @SALTemp TABLE
						(SameAsLinkName VARCHAR(100)
						,HubID INT
						,HubName VARCHAR(100)
						,InitialSourceDataEntityName VARCHAR(100)
						,BKFieldID INT
						,FieldName VARCHAR(100)
						,SameAsLinkDEID int
					)
INSERT INTO	@SALTemp
select sameaslinkname
	  ,h.hubid
	  ,hubname
	  ,right(HubName,LEN(hubname)-4) 
	  ,f.FieldID 
	  ,f.Fieldname
	  ,NULL
from dmod.sameaslink sal 
inner join dmod.sameaslinkfield salf ON
sal.SameAsLinkID = salf.SameAsLinkID
inner join DMOD.Hub h on 
h.hubid = sal.hubid
inner join DMOD.HubBusinessKey hbk on 
hbk.hubid = h.hubid
inner join dmod.hubbusinesskeyfield hbkf on
hbkf.HubBusinessKeyID = hbk.HubBusinessKeyID
inner join DC.Field f on 
f.FieldID = hbkf.Fieldid
WHERE sal.HubID = @HubID
select * from @SALTemp
----====================================================================================================
----TempTable CreatedHere for CLSAL
----====================================================================================================

DECLARE @CLSATTemp TABLE
						(SameAsLinkName VARCHAR(100)
						,HubID INT
						,HubName VARCHAR(100)
						,InitialSourceDataEntityName VARCHAR(100)
						,BKFieldID INT
						,FieldName VARCHAR(100)
						,CLSATDEID int
					)
INSERT INTO	@CLSATTemp
select sameaslinkname
	  ,h.hubid
	  ,hubname
	  ,right(HubName,LEN(hubname)-4) 
	  ,f.FieldID 
	  ,f.Fieldname
	  ,NULL
from dmod.sameaslink sal 
inner join dmod.sameaslinkfield salf ON
sal.SameAsLinkID = salf.SameAsLinkID
inner join DMOD.Hub h on 
h.hubid = sal.hubid
inner join DMOD.HubBusinessKey hbk on 
hbk.hubid = h.hubid
inner join dmod.hubbusinesskeyfield hbkf on
hbkf.HubBusinessKeyID = hbk.HubBusinessKeyID
inner join DC.Field f on 
f.FieldID = hbkf.Fieldid
WHERE sal.HubID = @HubID
select * from @CLSATTemp

--====================================================================================================
--	All Variables Declared Here
--====================================================================================================


DECLARE @TargetSchemaID INT
	--TODO :Replace with dynamic SQL
SET @TargetSchemaID = 31
		--(select distinct de.schemaid 
		-- from dc.[schema] s 
		-- join dc.dataentity de on 
		-- de.schemaid = de.schemaid 
		-- where dataentityname = @SATname )
DECLARE @TargetSALDatabaseID INT
SET @TargetSALDatabaseID = 24
DECLARE @TargetSchemaName VARCHAR(20)
SET @TargetSchemaName = 'RAW'

--====================================================================================================
--	Insert the Target Schema in DC (if it does not exist) - the M2MLink db schema is equal to the source system abbreviation,
--	accoarding to the naming convention
--====================================================================================================

SET @TargetSchemaID =
						(
						SELECT	TOP 1 sc.SchemaID
						FROM	DC.[Schema] sc
						WHERE	DatabaseID = @TargetSALDatabaseID
							and SchemaName = @TargetSchemaName
						)

if @TargetSchemaID IS NULL 
	--INSERT INTO DC.[Schema] 
	--(SchemaName
	--,DatabaseID
	--,DBSchemaID
	--,CreatedDT
	--)
	(SELECT @TargetSchemaName
		   ,@TargetSALDatabaseID
		   ,NULL
		   ,GETDATE()
	)

if @TargetSchemaID IS NULL
set @TargetSchemaID = @@IDENTITY

--====================================================================================================
--	Copy the structure of the Source Data Entity into DataEntity table in DC (if it does not exist)
--
--	Correct fields?  
--		Add IsActive field
--====================================================================================================
		
--INSERT INTO DC.DataEntity
--(DataEntityName
--,SchemaID
--,CreatedDT
--)
SELECT DISTINCT  SameAsLinkName
				,@TargetSchemaID
				,GETDATE()
FROM	@SALTemp
WHERE NOT EXISTS
	 (SELECT 1
	  FROM	@SALTemp salt
	  INNER JOIN DC.DataEntity de ON
	  salt.SameAsLinkName = de.DataEntityName
		 AND de.SchemaID = @TargetSchemaID
	  )

--Create DataEntity for the CLSAT
--INSERT INTO DC.DataEntity
--(DataEntityName
--,SchemaID
--,CreatedDT
--)
SELECT DISTINCT  'CLSAT_'+SameAsLinkName
				,@TargetSchemaID
				,GETDATE()
FROM	@CLSATTemp
WHERE NOT EXISTS
	 (SELECT 1
	  FROM	@CLSATTemp cls
	  INNER JOIN DC.DataEntity de ON
	  cls.initialSourceDataEntityName = de.DataEntityName
		 AND de.SchemaID = @TargetSchemaID
	  )


--====================================================================================================
--	Updates DataEntityID
--====================================================================================================
--UPDATE	salt
--SET		TargetDataEntityID = de.DataEntityID
--FROM	@SALTemp salt
--INNER JOIN DC.DataEntity de ON salt.SameAsLinkName = de.DataEntityName
--	AND de.SchemaID = @TargetSchemaID

----Update DataEntity for the CLSAT
--UPDATE	cls
--SET		SATDataEntityID = de.DataEntityID
--FROM	@CLSATTemp cls
--INNER JOIN DC.DataEntity de ON cls.SATDataEntityName = de.DataEntityName
--	AND de.SchemaID = @TargetSchemaID
--DECLARE @StageDEID INT = (SELECT DISTINCT TargetDataEntityID FROM @SALTemp)
--DECLARE @StageDEIDCL INT = (SELECT DISTINCT SATDataEntityID FROM @CLSATTemp)

----====================================================================================================
----Inserts HK LoadDT Resource fields
----====================================================================================================
	
--DECLARE @Fields TABLE
--		([FieldName] [varchar](1000) NOT NULL,
--		 [DataType] [varchar](500) NULL,
--		 [MaxLength] [int] NULL,
--		 [Precision] [int] NULL,
--		 [Scale] [int] NULL,
--		 [DataEntityID] [int] NULL,
--		 [CreatedDT] [datetime2](7) NULL,
--		 [FieldSortOrder] [int] NULL,
--		 [IsActive] [bit] NULL
--		 )
--DECLARE @InitialSourceDataEntityName VARCHAR(100) = (SELECT DISTINCT InitialSourceDataEntityName FROM @SALTemp)
--	INSERT @Fields VALUES
--		  ('HK_'+@InitialSourceDataEntityName,'varchar',40,0,0,-1, GETDATE(), 1, 1),
--		  ('LoadDT','datetime2',8,27,7,-1, GETDATE(), 2, 1),
--		  ('RecSrcDataEntityID','int',4,0,0,-1, GETDATE(), 3, 1),
--		  ('HK_MasterRecord_'+@InitialSourceDataEntityName,'int',4,0,0,-1, GETDATE(), 3, 1),
--		  ('HK_SameAsRecord_'+@InitialSourceDataEntityName,'int',4,0,0,-1, GETDATE(), 3, 1)


--DECLARE @TargetDEID int
--SET @TargetDEID = (Select distinct TargetDataEntityID from @SALTemp)
--INSERT INTO [DC].[Field] 
--	   ([FieldName],[DataType],[MAXLENGTH],[Precision],[Scale],[DataEntityID],[CreatedDT],[IsActive],[FieldSortOrder] )

--SELECT	   f.FieldName
--		  ,f.DataType
--		  ,f.[MAXLENGTH]
--		  ,f.[Precision]
--		  ,f.[Scale]
--		  ,@TargetDEID
--		  ,GETDATE()
--		  ,[IsActive]
--		  ,f.[FieldSortOrder]		
--FROM @Fields f
--WHERE NOT EXISTS (SELECT 1
--				  FROM DC.FIELD f1
--				  WHERE f1.FieldName = f.FieldName
--					AND @TargetDEID = f1.DataEntityID		  
--				  )

----Update Fields for the CLSAT
--DECLARE @FieldsCL TABLE
--		([FieldName] [varchar](1000) NOT NULL,
--		 [DataType] [varchar](500) NULL,
--		 [MaxLength] [int] NULL,
--		 [Precision] [int] NULL,
--		 [Scale] [int] NULL,
--		 [DataEntityID] [int] NULL,
--		 [CreatedDT] [datetime2](7) NULL,
--		 [FieldSortOrder] [int] NULL,
--		 [IsActive] [bit] NULL
--		 )
--DECLARE @InitialSourceDataEntityNameCL VARCHAR(100) = (SELECT DISTINCT InitialSourceDataEntityName FROM @CLSATTemp)
--	INSERT @FieldsCL VALUES
--		  ('HK_'+@InitialSourceDataEntityName,'varchar',40,0,0,-1, GETDATE(), 1, 1),
--		  ('LoadDT','datetime2',8,27,7,-1, GETDATE(), 2, 1),
--		  ('LoadEndDT','datetime2',8,27,7,-1, GETDATE(), 3, 1),
--		  ('RecSrcDataEntityID','int',4,0,0,-1, GETDATE(), 4, 1),
--		  ('ConfidenceLevel','decimal',38,6,3,-1, GETDATE(), 5, 1)


--DECLARE @TargetDEIDCL int
--SET @TargetDEIDCL = (Select distinct SATDataEntityID from @CLSATTemp)
--INSERT INTO [DC].[Field] 
--	   ([FieldName],[DataType],[MAXLENGTH],[Precision],[Scale],[DataEntityID],[CreatedDT],[IsActive],[FieldSortOrder] )

--SELECT	   f.FieldName
--		  ,f.DataType
--		  ,f.[MAXLENGTH]
--		  ,f.[Precision]
--		  ,f.[Scale]
--		  ,@TargetDEIDCL
--		  ,GETDATE()
--		  ,[IsActive]
--		  ,f.[FieldSortOrder]		
--FROM @FieldsCL f
--WHERE NOT EXISTS (SELECT 1
--				  FROM DC.FIELD f1
--				  WHERE f1.FieldName = f.FieldName
--					AND @TargetDEIDCL = f1.DataEntityID		  
--				  )



	

------====================================================================================================
------	Insert the entries into the DC.FieldRelation table (type = 2) for the Data Entity
------====================================================================================================

--DECLARE @TempLeft TABLE
--(FieldName VARCHAR(100)
--,FieldID INT)
--INSERT INTO @TempLeft
--SELECT LEFT(FieldName,8)
--	  ,FieldID
--FROM DC.Field f 
--WHERE dataentityid = @TargetDEID
--AND f.FieldName like '%HK%'

--INSERT INTO [DC].[FieldRelation]
--	([SourceFieldID],
--		[TargetFieldID],
--		[FieldRelationTypeID],
--		[CreatedDT],
--		[IsActive]
--		)
--SELECT F1.SFieldID 
--	  ,FieldID 
--	  ,2
--	  ,GETDATE()
--	  ,1
--FROM @TempLeft tl
--INNER JOIN (SELECT LEFT(fieldname,8) AS SFieldName
--				  ,FieldID AS SFieldID
--			FROM dc.field
--			WHERE dataentityid = @TargetDEID
--			AND FieldName like '%HK%'
--			) F1 ON
--F1.SFieldName = tl.FieldName
--WHERE NOT EXISTS (SELECT 1 
--				  FROM DC.FieldRelation fr 
--				  INNER JOIN @TempLeft tl ON
--				  F1.SfieldID = fr.SourceFieldID
--				  AND tl.FieldId = TargetFieldID				  
--				   )

--select * from dmod.Hub_Working hw
--inner join dmod.HubBusinessKey_Working hkw on
--hw.HubID = hkw.HubID


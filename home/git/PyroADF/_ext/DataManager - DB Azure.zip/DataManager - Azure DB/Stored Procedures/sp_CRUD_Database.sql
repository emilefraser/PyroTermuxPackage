﻿
CREATE PROCEDURE [APP].[sp_CRUD_Database](

--all table fields, remove the ones you dont need
@DatabaseID int,
@DatabaseName varchar(100),
@AccessInstructions varchar(500), 
@ExternalDatasourceName varchar(100),
@DatabaseInstanceID int,
@SystemID int,
@DatabasePurposeID int,
@DBDatabaseID int,
@Size decimal(19,6),
@IsActive bit,
-- required params, please do not remove
@TransactionPerson varchar(80), -- who actioned
@MasterEntity varchar(50), -- from where actioned
@TransactionAction nvarchar(20) = null -- type of transaction, "Create", "Update", "Delete"
)

AS

BEGIN

DECLARE @TransactionDT datetime2(7) = getdate() -- date of transaction

DECLARE @JSONData varchar(max) = null -- to store in audit table

DECLARE @PrimaryKeyID int = null -- primary key value for the table

DECLARE @TableName VARCHAR(50) = 'DC.[Database]' -- table name


SET @Size = nullif(@Size, 0)
SET @DBDatabaseID = nullif(@DBDatabaseID, 0)
SET @AccessInstructions = nullif(@AccessInstructions, 'NULL')
SET @ExternalDatasourceName = nullif(@ExternalDatasourceName, 'NULL')
--create record

IF @TransactionAction = 'Create'


BEGIN

--Insert new record

--remove fields not needed, keep CreatedDT and IsActive

INSERT INTO [DC].[Database] (DatabaseName,
							AccessInstructions, 
							Size,  
							DatabaseInstanceID,
							SystemID,
							ExternalDatasourceName,
							DatabasePurposeID,
							DBDatabaseID,
							IsActive,
							CreatedDT)
VALUES(@DatabaseName,
	   @AccessInstructions,
	   @Size,  
	   @DatabaseInstanceID,
	   @SystemID,
	   @ExternalDatasourceName,
	   @DatabasePurposeID,
	   @DBDatabaseID,
	   @IsActive,
	   @TransactionDT)

SET @PrimaryKeyID = @@IDENTITY --for auditing
END

--update record

IF @TransactionAction = 'Update'

BEGIN

--update existing record

UPDATE [DC].[Database]
SET 
DatabaseName = @DatabaseName,
AccessInstructions = @AccessInstructions,
DatabaseInstanceID = @DatabaseInstanceID,
ExternalDatasourceName = @ExternalDatasourceName,
Size = @Size,
SystemID = @SystemID,
IsActive = @IsActive,
DatabasePurposeID = @DatabasePurposeID,
DBDatabaseID = @DBDatabaseID,
UpdatedDT = @TransactionDT
WHERE DatabaseID = @DatabaseID

SET @PrimaryKeyID = @DatabaseID --for auditing

END

--delete record

IF @TransactionAction = 'Delete'

BEGIN

--set record status inactive = 0 (soft delete record)

Update [DC].[Database]
SET IsActive = 0, 
UpdatedDT = @TransactionDT
WHERE DatabaseID = @DatabaseID

SET @PrimaryKeyID = @DatabaseID --for auditing

END

--capture json data (get primary key value to store in audit table)

--correct audit data
SET @JSONData = (SELECT db.DatabaseName,
						db.AccessInstructions,
						db.Size,
						dbi.DataBaseInstanceName,
						s.SystemName,
						db.ExternalDatasourceName,
						db.DBDatabaseID,
						db.LastSeenDT, 
						db.CreatedDT, 
						db.UpdatedDT, 
						db.IsActive
FROM [DC].[Database] db
LEFT JOIN DC.DatabaseInstance as dbi
ON db.DataBaseInstanceID = dbi.DataBaseInstanceID
LEFT JOIN DC.System s
ON db.SystemID = s.SystemID
WHERE DatabaseID = @PrimaryKeyID
FOR JSON PATH, WITHOUT_ARRAY_WRAPPER )

--call sp to store json audit data in table

EXEC [APP].sp_Audit_Trail_Insert @TransactionPerson = @TransactionPerson,
@TransactionAction = @TransactionAction,
@MasterEntity = @MasterEntity,
@JSONData = @JSONData,
@TransactionDT = @TransactionDT,
@PrimaryKeyID = @PrimaryKeyID,
@TableName = @TableName

END

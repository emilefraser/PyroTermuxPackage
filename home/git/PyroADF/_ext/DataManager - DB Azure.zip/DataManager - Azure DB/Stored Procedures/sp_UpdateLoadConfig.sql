﻿/*
EXEC [DMOD].[sp_UpdateLoadConfig] 'DMgrDEV_DataEnvDEV_StageArea'
-- Created by Peet Horn, Updated by Emile Fraser
-- Changes made... Included ODS - Source Field relations mapping in order to pick up the modelling
-- SELECT * FROM DC.[Database] AS db

	SELECT * FROM DMOD.LoadConfig
	SELECT * FROM DMOD.vw_LoadConfig
	EXEC DMOD.sp_UpdateLoadConfig 'DMgrDEV_DataEnvDEV_StageArea'

*/
CREATE PROCEDURE [DMOD].[sp_UpdateLoadConfig]
	@StageAreaDBName varchar(50)
AS



INSERT INTO [DMOD].[LoadConfig]
	(
	LoadTypeID
	, SourceDataEntityID
	, TargetDataEntityID
	, IsSetForReloadOnNextRun
	, IsActive
	, CreatedDT 
	)
SELECT DISTINCT
		 CASE REPLACE(SUBSTRING(targetde.DataEntityName, LEN(targetde.DataEntityName) - 3, 4), '_', '')
			WHEN 'KEYS' THEN 1 --KEYS
			WHEN 'LVD'	THEN 4 --Velocity
			WHEN 'MVD'	THEN 4 --Velocity
			WHEN 'HVD'	THEN 4 --Velocity
			ELSE -1
		 END AS LoadType
	   , ods_de.DataEntityID AS SourceDataEntityID
	   --, ods_de.DatabaseName AS SourceDatabaseName
	   --, ods_de.SchemaName AS SourceSchemaName
	   --, ods_de.DataEntityName AS SourceDataEntityName
	   , targetde.DataEntityID AS TargetDataEntityID
	   --, targetde.SchemaName AS TargetSchemaName
	   --, targetde.DataEntityName AS TargetDataEntityName
	   --, hub.HubName
	   --, REPLACE(SUBSTRING(targetde.DataEntityName, LEN(targetde.DataEntityName) - 3, 4), '_', '') AS Type
	   , 0 AS IsSetForReloadOnNextRun
	   , 1 AS IsActive
	   , GetDate() AS CreatedDT
  FROM (
		SELECT DISTINCT DataEntityID, SchemaName, DataEntityName, FieldID
			   , CASE
					WHEN LEN(DataEntityName) - LEN(REPLACE(DataEntityName, '_', '')) > 2 THEN SUBSTRING(DataEntityName, CHARINDEX('_', DataEntityName) + 1, CHARINDEX('_', DataEntityName, CHARINDEX('_', DataEntityName) + 1) - CHARINDEX('_', DataEntityName) - 1)
					ELSE SUBSTRING(DataEntityName, 1, CHARINDEX('_',DataEntityName)-1)
				 END AS BusinessEntity
		  FROM DC.vw_rpt_DatabaseFieldDetail
		 WHERE DatabaseName = @StageAreaDBName /*@StageAreaDBName  */AND
			   DataEntityName IS NOT NULL
		) AS targetde
	   INNER JOIN DC.FieldRelation ods_fr ON
			ods_fr.TargetFieldID = targetde.FieldID
	   INNER JOIN DC.vw_rpt_DatabaseFieldDetail ods_de ON
			ods_de.FieldID = ods_fr.SourceFieldID
	   INNER JOIN DC.FieldRelation source_fr ON
			source_fr.TargetFieldID = ods_de.FieldID
	   INNER JOIN DC.vw_rpt_DatabaseFieldDetail source_de ON
			source_de.FieldID = source_fr.SourceFieldID
	   INNER JOIN DMOD.HubBusinessKeyField hub_bkf ON
			hub_bkf.FieldID = source_de.FieldID
	   INNER JOIN DMOD.HubBusinessKey hub_bk ON
			hub_bk.HubBusinessKeyID = hub_bkf.HubBusinessKeyID
	   INNER JOIN DMOD.Hub hub ON
			hub.HubID = hub_bk.HubID
	   LEFT JOIN [DMOD].[LoadConfig] lc ON
			ods_de.DataEntityID = lc.SourceDataEntityID AND targetde.DataEntityID = lc.TargetDataEntityID
 WHERE 
	targetde.BusinessEntity = SUBSTRING(hub.HubName, 5, 1000)
	   AND lc.LoadConfigID is null

SELECT 'Load config records that are not valid'

SELECT lc.*
FROM
	[DMOD].[LoadConfig] lc
		LEFT OUTER JOIN (
SELECT DISTINCT
		 ods_de.DataEntityID AS SourceDataEntityID
	   , targetde.DataEntityID AS TargetDataEntityID
  FROM (
		SELECT DISTINCT DataEntityID, SchemaName, DataEntityName, FieldID
			   , CASE
					WHEN LEN(DataEntityName) - LEN(REPLACE(DataEntityName, '_', '')) > 2 THEN SUBSTRING(DataEntityName, CHARINDEX('_', DataEntityName) + 1, CHARINDEX('_', DataEntityName, CHARINDEX('_', DataEntityName) + 1) - CHARINDEX('_', DataEntityName) - 1)
					ELSE SUBSTRING(DataEntityName, 1, CHARINDEX('_',DataEntityName)-1)
				 END AS BusinessEntity
		  FROM DC.vw_rpt_DatabaseFieldDetail
		 WHERE DatabaseName = @StageAreaDBName  AND
			   DataEntityName IS NOT NULL
		) AS targetde
	  INNER JOIN DC.FieldRelation ods_fr ON
			ods_fr.TargetFieldID = targetde.FieldID
	   INNER JOIN DC.vw_rpt_DatabaseFieldDetail ods_de ON
			ods_de.FieldID = ods_fr.SourceFieldID
	   INNER JOIN DC.FieldRelation source_fr ON
			source_fr.TargetFieldID = ods_de.FieldID
	   INNER JOIN DC.vw_rpt_DatabaseFieldDetail source_de ON
			source_de.FieldID = source_fr.SourceFieldID
	   INNER JOIN DMOD.HubBusinessKeyField hub_bkf ON
			hub_bkf.FieldID = source_de.FieldID
	   INNER JOIN DMOD.HubBusinessKey hub_bk ON
			hub_bk.HubBusinessKeyID = hub_bkf.HubBusinessKeyID
	   INNER JOIN DMOD.Hub hub ON
			hub.HubID = hub_bk.HubID
 WHERE --targetde.DataEntityID = 47563 AND
	   BusinessEntity
			= SUBSTRING(hub.HubName, 5, 1000)
			) vlc
		ON lc.SourceDataEntityID = vlc.SourceDataEntityID 
		AND lc.TargetDataEntityID = vlc.TargetDataEntityID 
WHERE vlc.SourceDataEntityID is null

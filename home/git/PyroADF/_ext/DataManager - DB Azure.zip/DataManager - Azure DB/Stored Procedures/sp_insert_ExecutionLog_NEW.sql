﻿

-- =============================================
-- Author:		Emile Fraser
-- Create date: 2019-07-19
-- Description:	Insert a log entry into the ETL.ExecutionLog_StoredProcedures table
-- =============================================
CREATE PROCEDURE [ETL].[sp_insert_ExecutionLog_NEW] 
			@DatabaseName VARCHAR(100)
		,	@SchemaName VARCHAR(100)
		,	@swStart_FinishLogEntry INT
		,	@ExecutionLogID_In INT 
		,	@LoadConfigID INT
		,	@QueuedForProcessingDT datetime2(7)
		,	@IsReload bit
		,	@ErrorMessage VARCHAR(500) 
		,	@DataEntityName VARCHAR(100)
		,	@NewRowCount INT 
		,	@IsError INT 
		,	@LastProcessingKeyValue VARCHAR(max)
		,	@DeletedRowCount INT 
		,	@SourceRowCount INT 
		,	@SourceTableSizeBytes INT
		,	@TargetRowCount INT
		,	@TargetTableSizeBytes INT 
		,	@UpdatedRowBytes INT 
		,	@UpdatedRowCount INT 
		,	@NewRowsBytes INT
		,	@RowsTransferred INT 
		,	@InitialTargetRowCount INT 
		,	@InitialTargetTableSizeBytes INT


AS
BEGIN
	SET NOCOUNT ON;

	SELECT ''
	/*
	
	BEGIN TRANSACTION

--WS: Code to log when a load failed
DECLARE @ERRORVAR INT
DECLARE @ERRORSTRING VARCHAR(50)

DECLARE @LoadType VARCHAR(50)

SET @ERRORVAR = (SELECT COUNT(*) 
				 FROM etl.vw_mat_ExecutionLogSteps
				 where [Action] LIKE '%error%' 
				 --and [Execution Log ID] = @ExecutionLogID_Out 
				 /*stick dynamic here*/ 
				 )

--SET @LoadType = (SELECT LoadType FROM ETL.LoadConfig WHERE LoadConfigID = @LoadConfigID)

IF @ERRORVAR != 0 OR @IsError = 1
BEGIN
  SET @ERRORSTRING = 'Execution Failed'
END
ELSE IF @swStart_FinishLogEntry = 1	
BEGIN
 SET @ERRORSTRING = 'Execution In Progress'
END
ELSE 
BEGIN
 SET @ERRORSTRING = 'Execution Finished'
END
--END OF WS CODE

	--SELECT @swStart_FinishLogEntry

	IF @swStart_FinishLogEntry = 1
		BEGIN
			DECLARE @StartDT datetime2(7) = CONVERT(datetime2(7), GETDATE())

			--Insert entry to start the execution of the stored procedure and to generate the ExecutionLogID
			INSERT INTO [ETL].[ExecutionLog]
					      (
						   [LoadConfigID]
						  ,[DatabaseName]
						  ,[SchemaName]
						 -- ,[StoredProcedureName]
						  ,[QueuedForProcessingDT]
						  ,[StartDT]
						  ,[LastProcessingKeyValue]
						  ,[IsReload]
						  ,[Result]
						  ,[ErrorMessage]
						  ,[DataEntityname])
						 -- ,[LoadType])
				 VALUES
					   (   
						   @LoadConfigID  -- replace with what was orignally here
						  ,@DatabaseName
						  ,@SchemaName
						 -- ,@StoredProcedureName
						  ,@QueuedForProcessingDT
						  ,@StartDT
						  ,@LastProcessingKeyValue
						  ,@IsReload
						  ,@ERRORSTRING --ws
						  ,@ErrorMessage
						  ,@DataEntityName)
						 -- ,@LoadType)
	
	
			--Get the ExecutionLogID to be used in the [ETL].[ExecutionLogStep_StoredProcedure] sp
			--SELECT @ExecutionLogID_Out = @@IDENTITY

			--SELECT @ExecutionLogID_Out

			--Insert log entry into the Analytics table
			INSERT INTO [ETL].[ExecutionLogAnalysis]
			   ([ExecutionLogID])
			SELECT 
				@@IDENTITY

		END
		ELSE 
			BEGIN

				DECLARE @FinishDT datetime2(7) = CONVERT(datetime2(7), GETDATE())

				UPDATE	[ETL].[ExecutionLog]
				SET		FinishDT = @FinishDT
						, Result = @ERRORSTRING --ws
						, RowsTransferred = @RowsTransferred
						, SourceRowCount = @SourceRowCount
						, TargetRowCount = @TargetRowCount
	                    , NewRowCount  = @NewRowCount
                        , DeletedRowCount  = @DeletedRowCount
                        , SourceTableSizeBytes  = @SourceTableSizeBytes
                        , IsError  = @IsError
                        , TargetTableSizeBytes  = @TargetTableSizeBytes
                        , UpdatedRowBytes  = @UpdatedRowBytes
                        , UpdatedRowCount  = @UpdatedRowCount
                        , NewRowsBytes  = @NewRowsBytes
	                    ,InitialTargetRowCount = @InitialTargetRowCount 
	                    ,InitialTargetTableSizeBytes = @InitialTargetTableSizeBytes 
				WHERE	ExecutionLogID = @ExecutionLogID_In --Wrong code: (Select MAX(ExecutionLogID) from  [ETL].[ExecutionLog])

				--Calculate Analysis for this log entry
				UPDATE	a
				SET		[DurationSeconds] = DATEDIFF(SECOND, [log].StartDT, [log].FinishDT)
						,[QueueSeconds] = DATEDIFF(SECOND, [log].QueuedForProcessingDT, [log].StartDT)
						,[TotalExecutionTime] = DATEDIFF(SECOND, [log].QueuedForProcessingDT, [log].FinishDT)
						,[IsDataIntegrityError] = CASE WHEN [log].SourceRowCount != [log].TargetRowCount THEN 1 ELSE 0 END
				FROM	[ETL].[ExecutionLogAnalysis] a
						INNER JOIN [ETL].[ExecutionLog] AS [log] ON
							[log].ExecutionLogID = a.ExecutionLogID
				WHERE	[log].ExecutionLogID = @ExecutionLogID_In

			
			
			END
			
			

	COMMIT TRANSACTION

	*/

END


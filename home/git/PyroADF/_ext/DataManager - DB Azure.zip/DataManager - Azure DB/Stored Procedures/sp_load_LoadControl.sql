﻿
-- =============================================
-- Author:		Karl Dinkelmann
-- Create date: 25 Oct 2018
-- Description: Loads Employee Detail into the Employee table.
-- =============================================
CREATE PROCEDURE [INTEGRATION].[sp_load_LoadControl]
AS

  INSERT INTO ETL.LoadControl
  SELECT 
       ilc.[LoadControlID]
      ,ilc.[LoadConfigID]
      ,ilc.[CreatedDT]
      ,ilc.[QueuedForProcessingDT]
      ,ilc.[ProcessingStartDT]
      ,ilc.[ProcessingFinishedDT]
      ,ilc.[LastProcessingPrimaryKey]
      ,ilc.[LastProcessingTransactionNo]
      ,ilc.[NewRecordDDL]
      ,ilc.[UpdatedRecordDDL]
      ,ilc.[CreateTempTableDDL]
      ,ilc.[TempTableName]
      ,ilc.[UpdateStatementDDL]
      ,ilc.[GetLastProcessingKeyValueDDL]
      ,ilc.[DeleteStatementDDL]
      ,ilc.[IsLastRunFailed]
      ,ilc.[ProcessingState]
      ,ilc.[NextScheduledRunTime]
  FROM [INTEGRATION].[ingress_LoadControl] ilc
  LEFT JOIN  ETL.LoadControl lc
  ON lc.LoadControlID = ilc.LoadControlID
  WHERE lc.LoadControlID is NULL


  UPDATE ETL.LoadControl
  SET                
       [LoadConfigID] = ilc.[LoadConfigID]
      ,[CreatedDT] = ilc.[CreatedDT]
      ,[QueuedForProcessingDT] = ilc.[QueuedForProcessingDT]
      ,[ProcessingStartDT] = ilc.[ProcessingStartDT]
      ,[ProcessingFinishedDT] = ilc.[ProcessingFinishedDT]
      ,[LastProcessingPrimaryKey] = ilc.[LastProcessingPrimaryKey]
      ,[LastProcessingTransactionNo] = ilc.[LastProcessingTransactionNo]
      ,[NewRecordDDL] = ilc.[NewRecordDDL]
      ,[UpdatedRecordDDL] = ilc.[UpdatedRecordDDL]
      ,[CreateTempTableDDL] = ilc.[CreateTempTableDDL]
      ,[TempTableName] = ilc.[TempTableName]
      ,[UpdateStatementDDL] = ilc.[UpdateStatementDDL]
      ,[GetLastProcessingKeyValueDDL] = ilc.[GetLastProcessingKeyValueDDL]
      ,[DeleteStatementDDL] = ilc.[DeleteStatementDDL]
      ,[IsLastRunFailed] = ilc.[IsLastRunFailed]
      ,[ProcessingState] = ilc.[ProcessingState]
      ,[NextScheduledRunTime] = ilc.[NextScheduledRunTime]
	  FROM ETL.LoadControl lc
	  LEFT JOIN [INTEGRATION].[ingress_LoadControl] ilc
	  ON ilc.LoadControlID = lc.LoadControlID
	  WHERE
       lc.[LoadConfigID] != ilc.[LoadConfigID]
      OR lc.[CreatedDT] != ilc.[CreatedDT]
      OR lc.[QueuedForProcessingDT] != ilc.[QueuedForProcessingDT]
      OR lc.[ProcessingStartDT] != ilc.[ProcessingStartDT]
      OR lc.[ProcessingFinishedDT] != ilc.[ProcessingFinishedDT]
      OR lc.[LastProcessingPrimaryKey] != ilc.[LastProcessingPrimaryKey]
      OR lc.[LastProcessingTransactionNo] != ilc.[LastProcessingTransactionNo]
      OR lc.[NewRecordDDL] != ilc.[NewRecordDDL]
      OR lc.[UpdatedRecordDDL] != ilc.[UpdatedRecordDDL]
      OR lc.[CreateTempTableDDL] != ilc.[CreateTempTableDDL]
      OR lc.[TempTableName] != ilc.[TempTableName]
      OR lc.[UpdateStatementDDL] != ilc.[UpdateStatementDDL]
      OR lc.[GetLastProcessingKeyValueDDL] != ilc.[GetLastProcessingKeyValueDDL]
      OR lc.[DeleteStatementDDL] != ilc.[DeleteStatementDDL]
      OR lc.[IsLastRunFailed] != ilc.[IsLastRunFailed]
      OR lc.[ProcessingState] != ilc.[ProcessingState]
      OR lc.[NextScheduledRunTime] != ilc.[NextScheduledRunTime]


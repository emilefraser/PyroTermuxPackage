<#
.SYNOPSIS
	AzureRm.AcceleratedNIC.CoreHelper.psm1 - Contains helper functions.
.DESCRIPTION
	Contains helper functions.
#>
function GetParameterNameFromValue
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory=$true)]
        [string]$VMName,
        [Parameter(Mandatory=$true)]
        $parameterSection
    )

    foreach ($prop in $parameterSection.psobject.Properties)
    {
        if ($prop.value.defaultValue -ieq $VMName.ToLower())
        {
            return $prop.Name
        }
    }
}



function Add-AzureRmAcceleratedNIC
{
    <#
    .SYNOPSIS
        Add-AzureRmAcceleratedNIC - This sample cmdlet enabled the NIC acceleration by exporting, deleting the original VM & NIC and importing it back.
    .DESCRIPTION
        Add-AzureRmAcceleratedNIC - This sample cmdlet enables the NIC acceleration by exporting, deleting the original VM & NIC and importing it back.
    .PARAMETER ResourceGroup
        Name of the resource group where the VM resides
    .PARAMETER VMName
        VM to add Accelerated Networking function to.
    .PARAMETER OsType
        Which OS type are those VMs, Windows or Linux, this is required when attached an existing OS Disk to a newly created VM.
        Setting up the wrong OS Name may leave the VM in an unsupported state and unpredictable issues may happen.
    .EXAMPLE
        Add-AzureRmAcceleratedNIC -ResourceGroupName rg-avset-test -VMName vm1 -OsType windows
    .NOTES
        * Export-AzureRmResourceGroup will export the VM resources whitout any Extension and Diagnostics, so when it is imported back those items will need to be manually added back.
        * This script deletes the original VM configuration to import it back, a backup of the template is always made and can be used to reinstantiate the VM as they were before. 
        * It is strongly recommended to have a full backup of the VM and test it before allowing the script to delete the VM.
        * Execution of this script is at your own risk.
    #>
	[CmdletBinding(SupportsShouldProcess=$true, ConfirmImpact="High")]
	param
	(
		[Parameter(Mandatory=$true)]
		[string]$ResourceGroupName,
    
		[Parameter(Mandatory=$true)]
		[string[]]$VMName,

		[Parameter(Mandatory=$true)]
		[validateSet("windows","linux",IgnoreCase=$true)]
		[string]$OsType
	)
    
    $ErrorActionPreference = [System.Management.Automation.ActionPreference]::Stop

	$ExecutionTimeStamp = Get-Date -Format 'yyyy-MM-dd_hhmmss'

	#$originalTemplateFile = [System.IO.Path]::Combine('c:\scripts',[string]::Format("{0}-{1}.json","OriginalTemplate",$ExecutionTimeStamp))
    $originalTemplateFile = [System.IO.Path]::Combine($PSScriptRoot,[string]::Format("{0}-{1}.json","OriginalTemplate",$ExecutionTimeStamp))
    Write-Verbose "Original resource group ARM template file name: $originalTemplateFile" -Verbose

    #$newTemplateFile = [System.IO.Path]::Combine('c:\scripts',[string]::Format("{0}-{1}.json","NewTemplate",$ExecutionTimeStamp))
    $newTemplateFile = [System.IO.Path]::Combine($PSScriptRoot,[string]::Format("{0}-{1}.json","NewTemplate",$ExecutionTimeStamp))
	Write-Verbose "New resource group ARM template file name: $newTemplateFile" -Verbose

	try
	{
		# Exporting resource group
		Write-Verbose "Exporting resource group" -Verbose
		Export-AzureRmResourceGroup -ResourceGroupName $ResourceGroupName -Path $originalTemplateFile -IncludeParameterDefaultValue -force

		# Reading original template file
		$rgdef = Get-Content $originalTemplateFile | ConvertFrom-Json

		# Removing AdminPassword parameters that are not used when importing an existing Os Disk
		foreach ($prop in $rgdef.parameters.psobject.Properties)
		{
			if ($prop.name.contains("adminPassword") -or $prop.name.contains("primary") -or $prop.name.contains("extensions_Microsoft.") -or $prop.name.contains("extensions_"))
			{
				$rgdef.parameters.psobject.Properties.Remove($prop.Name)
			}
		}

		# Filtering resources for only VMs that will be included 
		$resources = @()
		foreach ($vm in $VMName)
		{
            $vmNameParameterName = GetParameterNameFromValue -VMName $vm -parameterSection $rgdef.parameters
			$resources += $rgdef.resources | ? {$_.type -eq "Microsoft.Compute/virtualMachines" -and $_.name.Contains($vmNameParameterName)}
			$resources += $rgdef.resources | ? {$_.type -eq "Microsoft.Network/networkInterfaces"}
		}
		#Added all VM's and ALL NIC's - need to filter the NIC's
		$rgdef.resources = $resources

        #RESULT OF THIS IS THE ACTUAL SIZE OF THE VM: $vmsize.vmsize == Standard_D8s_v3
        #NEED TO RUN AN DOES MATCH ((SIZES OF VMs))

		[array]$SupportedVMSizes="Standard_DS4_v2","Standard_DS5_v2","Standard_DS13-2_v2","Standard_DS13-4_v2","Standard_DS13_v2","Standard_DS14-4_v2","Standard_DS14-8_v2","Standard_DS14_v2","Standard_DS15_v2","Standard_DS4_v2_Promo","Standard_DS5_v2_Promo","Standard_DS13_v2_Promo","Standard_DS14_v2_Promo","Standard_F8s","Standard_F16s","Standard_D8s_v3","Standard_D16s_v3","Standard_D32s_v3","Standard_D4_v2","Standard_D5_v2","Standard_D13_v2","Standard_D14_v2","Standard_D4_v2_Promo","Standard_D5_v2_Promo","Standard_D13_v2_Promo","Standard_D14_v2_Promo","Standard_F8","Standard_F16","Standard_A8m_v2","Standard_A8_v2","Standard_D8_v3","Standard_D16_v3","Standard_D32_v3","Standard_D64_v3","Standard_D64s_v3","Standard_E8_v3","Standard_E16_v3","Standard_E32_v3","Standard_E64i_v3","Standard_E64_v3","Standard_E8-2s_v3","Standard_E8-4s_v3","Standard_E8s_v3","Standard_E16-4s_v3","Standard_E16-8s_v3","Standard_E16s_v3","Standard_E32-8s_v3","Standard_E32-16s_v3","Standard_E32s_v3","Standard_E64-16s_v3","Standard_E64-32s_v3","Standard_E64is_v3","Standard_E64s_v3","Standard_D15_v2","Standard_D4","Standard_D13","Standard_D14","Standard_NV6","Standard_NV12","Standard_NV24","Standard_NC6","Standard_NC12","Standard_NC24","Standard_NC24r","Standard_DS4","Standard_DS13","Standard_DS14","Standard_H8","Standard_H16","Standard_H8m","Standard_H16m","Standard_H16r","Standard_H16mr","Standard_DS3_v2","Standard_DS12-1_v2","Standard_DS12-2_v2","Standard_DS12_v2","Standard_D3_v2","Standard_D12_v2","Standard_D3","Standard_D12","Standard_DS3","Standard_DS12"
        If ($SupportedVMSizes -notcontains $rgdef.resources.properties.hardwareprofile.vmSize | where {$rgdef.resources.type -eq 'Microsoft.Compute/virtualMachines'} ){
            throw "VM Size $vmsize.vmsize not supported for Accelerated Networking. Please resize to a supported VM size"
        }

		# Changing original VM resources to attach disks and add to the availability set
		foreach ($vmResource in ($rgdef.resources | where {$_.type -eq 'Microsoft.Compute/virtualMachines'}))
		{
			#removing the NIC's we do not need
			$NicName=($vmResource.properties.networkProfile.networkInterfaces.id.split(", ")[2].replace("))",")")).replace("parameters","[parameters")
			$NICID = @()
			$NICID += $vmResource.properties.networkProfile.networkInterfaces.id
			
			# Removing any other dependencies since they already exists, except new network interface (which will be re-created)
			$vmResource.dependsOn = $NICID

			# Changing OS Disk to attach insted of using FromImage since this VM was already deployed
			$vmResource.properties.storageProfile.osDisk.createOption = "Attach"
        
			# Nullifying osProfile since this is used during a new deployment only
			if ($vmResource.properties.psobject.Properties["osProfile"] -ne $null)
			{
				$vmResource.properties.osProfile = $null
			}

			# Required by the Platform, adding the OsType parameter
			if ([string]::IsNullOrEmpty($vmResource.properties.storageProfile.osDisk.osType))
			{
				$vmResource.properties.storageProfile.osDisk | Add-Member -Type NoteProperty -Name "osType" -Value $osType.ToLower()
			}
        
			# Nullifying ImageReference since this is only for new VMs
			if ($vmResource.properties.storageProfile.psobject.Properties["imageReference"] -ne $null)
			{
				$vmResource.properties.storageProfile.imageReference = $null
			}

			# Changing creation option of data disks to Attach instead of new
			if ($vmResource.properties.storageProfile.dataDisks.Count -gt 0)
			{
				foreach ($datadisk in $vmResource.properties.storageProfile.dataDisks)
				{
					$datadisk.createOption = "Attach"
				}
			}
		}
		#removing all NIC's not related to the VM
		$rgdef.resources = $resources | where {$_.type -eq 'Microsoft.Compute/virtualMachines' -or $_.Name -eq $NICName}
		
		#Set the accelerated networking to true on existing config
		foreach ($vmResourceNIC in ($rgdef.resources | where {$_.type -eq 'Microsoft.Network/networkInterfaces'})) {
			#Validating if VM already uses Accel.NIC's
			If ($vmResourceNIC.properties.enableAcceleratedNetworking -eq $True) {
				$NICshortName = ($vmResourceNIC.name.split("('"))[2].replace("networkInterfaces_","").replace("_name","")
				throw "VM $VMName already uses NIC Acceleration"
			}

			#enable accelerated networking
			If ($vmResourceNIC.properties.enableAcceleratedNetworking -eq $False) {
				$vmResourceNIC.properties.enableAcceleratedNetworking='True'
			}

			#removing non-required attributes from NIC deployment template
			if ($vmResourceNIC.properties.macAddress -ne $null) {
				$vmResourceNIC.properties.macAddress = $null
			}
			if ($vmResourceNIC.properties.provisioningState -ne $null) {
				$vmResourceNIC.properties.provisioningState = $null
			}
			if ($vmResourceNIC.properties.resourceGuid -ne $null) {
				$vmResourceNIC.properties.resourceGuid = $null
			}
			if ($vmResourceNIC.properties.virtualMachine -ne $null) {
				$vmResourceNIC.properties.virtualMachine = $null
			}
			if ($vmResourceNIC.dependsOn -ne $null) {
				$vmResourceNIC.dependsOn = $null
			}

			#removing ipconfigurations properties that are not required
			foreach ($config in $vmResourceNIC.properties.ipConfigurations) {
				if ($config.etag -ne $null) {
					$config.psobject.members.remove('etag')
				}
				if ($config.properties.provisioningState -ne $null) {
					$config.properties.provisioningState = $null
				}

				#if a dynamic IP is assigned, no need to specify privateIP
				If ($config.properties.privateIPAllocationMethod.toLower() -eq 'Dynamic') {
					$config.properties.privateIPAddress = $null
				}
			}
		}

		# Generating the new JSON Template to be executed to import the VMs back.
		Write-Verbose "Generating the new JSON Template to be executed to import the VMs back." -Verbose

        if ($rgdef.resources.count -gt 0)
        {

		    $rgdef | ConvertTo-Json -Depth 100 | % {$_.replace("\u0027","`'")} | Out-File $newTemplateFile

		    if ($PSCmdlet.ShouldProcess($VMName,"Confirm that VM you want to add Network Acceleration"))
		    {

				Test-AzureRmResourceGroupDeployment -ResourceGroupName $ResourceGroupName `
													-Mode Incremental `
													-TemplateFile $newTemplateFile `
													-Verbose

			    foreach ($item in $VMName)
			    {
				    # Stopping VMs and removing their deployment
					Write-Verbose "Stopping VM $item" -Verbose
					
					$vm = Get-AzureRmVM -ResourceGroupName $ResourceGroupName -Name $item -Status
					
					if ($vm -ne $null)
					{
						if ($vm.statuses[1].Code -ne "PowerState/deallocated")
						{
							Stop-AzureRmVM -ResourceGroupName $ResourceGroupName -Name $item -Force
						}
						
						Write-Verbose "Deleting VM $item from Resource Group $ResourceGroupName (VHDs are preserved and VMs will be imported in the next steps)" -Verbose
						Remove-AzureRmVM -ResourceGroupName $ResourceGroupName -Name $item -Force
						$ShortedNicName=$rgdef.parameters.($NicName.Split("(,'")[2]).defaultValue
						Write-Verbose "Deleting NIC $ShortedNicName from Resource Group $ResourceGroupName (VHDs are preserved and VMs will be imported in the next steps)" -Verbose
						Remove-AzureRmNetworkInterface -Name $ShortedNicName -ResourceGroupName $ResourceGroupName -Force
					}

			    }

			    Write-Verbose "Deploying the new template." -Verbose
			    New-AzureRmResourceGroupDeployment -Name "SettingUpAccellNic-$ExecutionTimeStamp" `
												       -ResourceGroupName $ResourceGroupName `
												       -Mode Incremental `
												       -TemplateFile $newTemplateFile `
												       -Force -Verbose  
		    }
        }
        else
        {
            throw "Resouces section of template is empty after transformations, aborting operation."
        }
	}
	catch
	{
		Write-Error "An error ocurred: $_"
    
	}
}

function Remove-AzureRmAcceleratedNIC
{
    <#
    .SYNOPSIS
        Remove-AzureRmAcceleratedNIC - This sample cmdlet removes the NIC acceleration by exporting, deleting the original VM & NIC and importing it back.
    .DESCRIPTION
        Remove-AzureRmAcceleratedNIC - This sample cmdlet removes the NIC acceleration by exporting, deleting the original VM & NIC and importing it back.
    .PARAMETER ResourceGroup
        Name of the resource group where the VM resides
    .PARAMETER VMName
        VM to have Accelerated Networking removed
        e.g. "vm1"
    .PARAMETER OsType
        Which OS type are those VMs, Windows or Linux, this is required when attached an existing OS Disk to a newly created VM.
        Setting up the wrong OS Name may leave the VM in an unsupported state and unpredictable issues may happen.
    .EXAMPLE
            Remove-AzureRmAcceleratedNIC -ResourceGroupName rg-avset-test -VMName vm1 -OsType windows
    .NOTES
        * Export-AzureRmResourceGroup will export the VM resources whitout any Extension and Diagnostics, so when it is imported back those items will need to be manually added back.
        * This script deletes the original VM configuration to import it back, a backup of the template is always made and can be used to reinstantiate the VM as they were before. 
        * It is strongly recommended to have a full backup of the VM and test it before allowing the script to delete the VM.
        * Execution of this script is at your own risk.
    #>
	[CmdletBinding(SupportsShouldProcess=$true, ConfirmImpact="High")]
	param
	(
		[Parameter(Mandatory=$true)]
		[string]$ResourceGroupName,
    
		[Parameter(Mandatory=$true)]
		[string[]]$VMName,

		[Parameter(Mandatory=$true)]
		[validateSet("windows","linux",IgnoreCase=$true)]
		[string]$OsType
	)
    
    $ErrorActionPreference = [System.Management.Automation.ActionPreference]::Stop

	$ExecutionTimeStamp = Get-Date -Format 'yyyy-MM-dd_hhmmss'
    $originalTemplateFile = [System.IO.Path]::Combine($PSScriptRoot,[string]::Format("{0}-{1}.json","OriginalTemplate",$ExecutionTimeStamp))
    Write-Verbose "Original resource group ARM template file name: $originalTemplateFile" -Verbose
    $newTemplateFile = [System.IO.Path]::Combine($PSScriptRoot,[string]::Format("{0}-{1}.json","NewTemplate",$ExecutionTimeStamp))
	Write-Verbose "New resource group ARM template file name: $newTemplateFile" -Verbose

	try
	{
		# Exporting resource group
		Write-Verbose "Exporting resource group" -Verbose
		Export-AzureRmResourceGroup -ResourceGroupName $ResourceGroupName -Path $originalTemplateFile -IncludeParameterDefaultValue -force

		# Reading original template file
		$rgdef = Get-Content $originalTemplateFile | ConvertFrom-Json

		# Removing AdminPassword parameters that are not used when importing an existing Os Disk
		foreach ($prop in $rgdef.parameters.psobject.Properties)
		{
			if ($prop.name.contains("adminPassword") -or $prop.name.contains("primary") -or $prop.name.contains("extensions_Microsoft."))
			{
				$rgdef.parameters.psobject.Properties.Remove($prop.Name)
			}
		}

		# Filtering resources for only VMs that will be included 
		$resources = @()
		foreach ($vm in $VMName)
		{
            $vmNameParameterName = GetParameterNameFromValue -VMName $vm -parameterSection $rgdef.parameters
			$resources += $rgdef.resources | ? {$_.type -eq "Microsoft.Compute/virtualMachines" -and $_.name.Contains($vmNameParameterName)}
			$resources += $rgdef.resources | ? {$_.type -eq "Microsoft.Network/networkInterfaces"}
		}
		#Added all VM's and ALL NIC's - need to filter the NIC's
		$rgdef.resources = $resources

        # Changing original VM resources to attach disks and add to the availability set
		foreach ($vmResource in ($rgdef.resources | where {$_.type -eq 'Microsoft.Compute/virtualMachines'}))
		{
			#removing the NIC's we do not need
			$NicName=($vmResource.properties.networkProfile.networkInterfaces.id.split(", ")[2].replace("))",")")).replace("parameters","[parameters")
			$NICID = @()
			$NICID += $vmResource.properties.networkProfile.networkInterfaces.id
			
			# Removing any other dependencies since they already exists, except new network interface (which will be re-created)
			$vmResource.dependsOn = $NICID

			# Changing OS Disk to attach insted of using FromImage since this VM was already deployed
			$vmResource.properties.storageProfile.osDisk.createOption = "Attach"
        
			# Nullifying osProfile since this is used during a new deployment only
			if ($vmResource.properties.psobject.Properties["osProfile"] -ne $null)
			{
				$vmResource.properties.osProfile = $null
			}

			# Required by the Platform, adding the OsType parameter
			if ([string]::IsNullOrEmpty($vmResource.properties.storageProfile.osDisk.osType))
			{
				$vmResource.properties.storageProfile.osDisk | Add-Member -Type NoteProperty -Name "osType" -Value $osType.ToLower()
			}
        
			# Nullifying ImageReference since this is only for new VMs
			if ($vmResource.properties.storageProfile.psobject.Properties["imageReference"] -ne $null)
			{
				$vmResource.properties.storageProfile.imageReference = $null
			}

			# Changing creation option of data disks to Attach instead of new
			if ($vmResource.properties.storageProfile.dataDisks.Count -gt 0)
			{
				foreach ($datadisk in $vmResource.properties.storageProfile.dataDisks)
				{
					$datadisk.createOption = "Attach"
				}
			}
		}
		#removing all NIC's not related to the VM and cleaning up the rgdef
		$rgdef.resources = $resources | where {$_.type -eq 'Microsoft.Compute/virtualMachines' -or $_.Name -eq $NICName}
		
		#Set the accelerated networking to true on existing config
		foreach ($vmResourceNIC in ($rgdef.resources | where {$_.type -eq 'Microsoft.Network/networkInterfaces'})) {
			#Validating if VM already uses Accel.NIC's
			If ($vmResourceNIC.properties.enableAcceleratedNetworking -eq $False) {
				$NICshortName = ($vmResourceNIC.name.split("('"))[2].replace("networkInterfaces_","").replace("_name","")
				throw "VM $VMName does not use NIC Acceleration"
			}

			#enable accelerated networking
			If ($vmResourceNIC.properties.enableAcceleratedNetworking -eq $True) {
				$vmResourceNIC.properties.enableAcceleratedNetworking='False'
			}

			#removing non-required attributes from NIC deployment template
			if ($vmResourceNIC.properties.macAddress -ne $null) {
				$vmResourceNIC.properties.macAddress = $null
			}
			if ($vmResourceNIC.properties.provisioningState -ne $null) {
				$vmResourceNIC.properties.provisioningState = $null
			}
			if ($vmResourceNIC.properties.resourceGuid -ne $null) {
				$vmResourceNIC.properties.resourceGuid = $null
			}
			if ($vmResourceNIC.properties.virtualMachine -ne $null) {
				$vmResourceNIC.properties.virtualMachine = $null
			}
			if ($vmResourceNIC.dependsOn -ne $null) {
				$vmResourceNIC.dependsOn = $null
			}

			#removing ipconfigurations properties that are not required
			foreach ($config in $vmResourceNIC.properties.ipConfigurations) {
				if ($config.etag -ne $null) {
					$config.psobject.members.remove('etag')
				}
				if ($config.properties.provisioningState -ne $null) {
					$config.properties.provisioningState = $null
				}

				#if a dynamic IP is assigned, no need to specify privateIP
				If ($config.properties.privateIPAllocationMethod.toLower() -eq 'Dynamic') {
					$config.properties.privateIPAddress = $null
				}
			}
		}

		# Generating the new JSON Template to be executed to import the VMs back.
		Write-Verbose "Generating the new JSON Template to be executed to import the VMs back." -Verbose

        if ($rgdef.resources.count -gt 0)
        {

		    $rgdef | ConvertTo-Json -Depth 100 | % {$_.replace("\u0027","`'")} | Out-File $newTemplateFile

		    if ($PSCmdlet.ShouldProcess($VMName,"Confirm that VM you want to remove the Network Acceleration"))
		    {

				Test-AzureRmResourceGroupDeployment -ResourceGroupName $ResourceGroupName `
													-Mode Incremental `
													-TemplateFile $newTemplateFile `
													-Verbose

			    foreach ($item in $VMName)
			    {
				    # Stopping VMs and removing their deployment
					Write-Verbose "Stopping VM $item" -Verbose
					
					$vm = Get-AzureRmVM -ResourceGroupName $ResourceGroupName -Name $item -Status
					
					if ($vm -ne $null)
					{
						if ($vm.statuses[1].Code -ne "PowerState/deallocated")
						{
							Stop-AzureRmVM -ResourceGroupName $ResourceGroupName -Name $item -Force
						}
						
						Write-Verbose "Deleting VM $item from Resource Group $ResourceGroupName (VHDs are preserved and VMs will be imported in the next steps)" -Verbose
						Remove-AzureRmVM -ResourceGroupName $ResourceGroupName -Name $item -Force
						$ShortedNicName=$rgdef.parameters.($NicName.Split("(,'")[2]).defaultValue
						Write-Verbose "Deleting NIC $ShortedNicName from Resource Group $ResourceGroupName (VHDs are preserved and VMs will be imported in the next steps)" -Verbose
						Remove-AzureRmNetworkInterface -Name $ShortedNicName -ResourceGroupName $ResourceGroupName -Force
					}

			    }

			    Write-Verbose "Deploying the new template." -Verbose
			    New-AzureRmResourceGroupDeployment -Name "SettingUpAccellNic-$ExecutionTimeStamp" `
												       -ResourceGroupName $ResourceGroupName `
												       -Mode Incremental `
												       -TemplateFile $newTemplateFile `
												       -Force -Verbose  
		    }
        }
        else
        {
            throw "Resouces section of template is empty after transformations, aborting operation."
        }
	}
	catch
	{
		Write-Error "An error ocurred: $_"
    
	}
}



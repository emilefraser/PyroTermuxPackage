﻿namespace Microsoft.ADF.DotNetActivityRunner.Models
{
    internal class ActivityOutput : ActivityData
    {
    }
}
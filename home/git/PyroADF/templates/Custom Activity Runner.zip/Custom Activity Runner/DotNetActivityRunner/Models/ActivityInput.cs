﻿namespace Microsoft.ADF.DotNetActivityRunner.Models
{
    internal class ActivityInput : ActivityData
    {
    }
}
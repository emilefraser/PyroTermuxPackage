﻿namespace Microsoft.ADF.DotNetActivityRunner.Models
{
    internal class ComputeService : LinkedService
    {
    }
}
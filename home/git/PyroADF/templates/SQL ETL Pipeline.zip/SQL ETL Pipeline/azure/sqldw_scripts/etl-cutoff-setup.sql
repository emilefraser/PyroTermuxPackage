INSERT INTO [Integration].[ETLCutoff] values ('[Dimension].[City]','1-1-1900')
INSERT INTO [Integration].[ETLCutoff] values ('[Fact].[Sale]','1-1-1900')
INSERT INTO [Integration].[ETLCutoff] values ('[Dimension].[Customer]','1-1-1900')
INSERT INTO [Integration].[ETLCutoff] values ('[Dimension].[Employee]','1-1-1900')
INSERT INTO [Integration].[ETLCutoff] values ('[Dimension].[StockItem]','1-1-1900')



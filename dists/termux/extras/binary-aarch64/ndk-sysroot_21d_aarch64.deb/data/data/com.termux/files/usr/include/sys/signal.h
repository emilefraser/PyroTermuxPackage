#pragma once

/**
 * @file sys/signal.h
 * @brief Historical synonym for `<signal.h>`.
 *
 * New code should use `<signal.h>` directly.
 */

#include <signal.h>
